#![forbid(unsafe_code)]

mod app_config;
mod control_server;
mod supervisor;

use app_config::ApplicationConfig;
use control_server::{ControlServer, WorkerCommands};
use rand::distr::{Alphanumeric, SampleString};
use serde::{Deserialize, Serialize};
use std::net::{TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};
use supervisor::{LifecycleSnapshot, ResourceSnapshot, Supervisor, WorkerCommand};
use sysinfo::System;
use tauri::{Manager, State};
use uuid::Uuid;

#[derive(Clone, Serialize)]
struct BackendConnection {
    port: u16,
    token: String,
}

#[derive(Clone, Serialize)]
struct HardwareSnapshot {
    total_memory_bytes: u64,
    available_memory_bytes: u64,
    logical_cpus: usize,
    recommended_threads: usize,
    recommended_context_length: u32,
}

struct BackendProcess {
    child: Option<Child>,
}

impl Drop for BackendProcess {
    fn drop(&mut self) {
        if let Some(child) = self.child.as_mut() {
            let _ = child.kill();
            let _ = child.wait();
        }
    }
}

struct ApplicationState {
    connection: BackendConnection,
    supervisor: Arc<Mutex<Supervisor>>,
    configuration: Mutex<ApplicationConfig>,
    configuration_path: PathBuf,
    _backend: BackendProcess,
    _control_server: ControlServer,
}

fn allocate_loopback_port() -> Result<u16, String> {
    let listener = TcpListener::bind(("127.0.0.1", 0))
        .map_err(|error| format!("Could not allocate a loopback port: {error}"))?;
    listener
        .local_addr()
        .map(|address| address.port())
        .map_err(|error| format!("Could not inspect the loopback port: {error}"))
}

fn project_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../..")
}

fn runtime_executable(root: &Path, config: &ApplicationConfig) -> PathBuf {
    if let Some(path) = &config.llama_runtime {
        return path.clone();
    }
    std::env::var_os("Q_LLAMA_SERVER_EXECUTABLE").map_or_else(
        || {
            if cfg!(debug_assertions) && cfg!(target_os = "windows") {
                root.join("runtimes/model/llama_cpp/llama-server.exe")
            } else if cfg!(debug_assertions) {
                root.join("runtimes/model/llama_cpp/llama-server")
            } else {
                root.join("bin/llama_cpp/llama-server.exe")
            }
        },
        PathBuf::from,
    )
}

fn python_interpreter(root: &Path) -> PathBuf {
    if cfg!(target_os = "windows") {
        root.join(".venv/Scripts/python.exe")
    } else {
        root.join(".venv/bin/python")
    }
}

fn python_worker_command(
    root: &Path,
    environment_key: &str,
    relative_script: &str,
    packaged_name: &str,
) -> WorkerCommand {
    if let Some(program) = std::env::var_os(environment_key) {
        return WorkerCommand {
            program: PathBuf::from(program),
            fixed_args: Vec::new(),
        };
    }
    if cfg!(debug_assertions) {
        WorkerCommand {
            program: python_interpreter(root),
            fixed_args: vec![root.join(relative_script).into_os_string()],
        }
    } else {
        WorkerCommand {
            program: root.join(packaged_name),
            fixed_args: Vec::new(),
        }
    }
}

fn worker_commands(root: &Path, config: &ApplicationConfig) -> WorkerCommands {
    let r_program = std::env::var_os("Q_RSCRIPT_EXECUTABLE")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("Rscript"));
    WorkerCommands {
        python: python_worker_command(
            root,
            "Q_PYTHON_WORKER_EXECUTABLE",
            "runtimes/python_worker/main.py",
            "bin/q-python-worker.exe",
        ),
        sql: python_worker_command(
            root,
            "Q_SQL_WORKER_EXECUTABLE",
            "runtimes/sql_worker/main.py",
            "bin/q-sql-worker.exe",
        ),
        package: python_worker_command(
            root,
            "Q_PACKAGE_WORKER_EXECUTABLE",
            "runtimes/package_worker/main.py",
            "bin/q-package-worker.exe",
        ),
        r: WorkerCommand {
            program: r_program,
            fixed_args: vec![root.join("runtimes/r_worker/worker.R").into_os_string()],
        },
        audio: audio_worker_command(root, config),
    }
}

fn audio_worker_command(root: &Path, config: &ApplicationConfig) -> WorkerCommand {
    let whisper = config
        .whisper_runtime
        .clone()
        .or_else(|| std::env::var_os("Q_WHISPER_EXECUTABLE").map(PathBuf::from))
        .unwrap_or_else(|| {
            if cfg!(debug_assertions) {
                root.join("runtimes/audio/whisper-cli.exe")
            } else {
                root.join("bin/whisper_cpp/whisper-cli.exe")
            }
        });
    let model = config
        .whisper_model
        .clone()
        .or_else(|| std::env::var_os("Q_WHISPER_MODEL").map(PathBuf::from))
        .unwrap_or_else(|| root.join("models/ggml-base.bin"));
    let mut command = python_worker_command(
        root,
        "Q_AUDIO_WORKER_EXECUTABLE",
        "runtimes/audio_worker/main.py",
        "bin/q-audio-worker.exe",
    );
    command.fixed_args.extend([
        "--whisper".into(),
        whisper.into_os_string(),
        "--model".into(),
        model.into_os_string(),
    ]);
    command
}

fn start_backend(
    control_server: &ControlServer,
    workspace: &Path,
    runtime_root: &Path,
    mode: &str,
) -> Result<(BackendProcess, BackendConnection), String> {
    let port = allocate_loopback_port()?;
    let token = Alphanumeric.sample_string(&mut rand::rng(), 64);
    let development_root = project_root();
    let explicit_executable = std::env::var_os("Q_BACKEND_EXECUTABLE");
    let mut command = if let Some(executable) = explicit_executable {
        Command::new(executable)
    } else if cfg!(debug_assertions) {
        let interpreter = python_interpreter(&development_root);
        let mut development = Command::new(interpreter);
        development.arg("-m").arg("q_backend.main");
        development
    } else {
        Command::new(runtime_root.join("bin/q-backend.exe"))
    };
    command
        .env("Q_BACKEND_HOST", "127.0.0.1")
        .env("Q_BACKEND_PORT", port.to_string())
        .env("Q_SESSION_TOKEN", &token)
        .env("Q_SUPERVISOR_PORT", control_server.port().to_string())
        .env("Q_SUPERVISOR_TOKEN", control_server.token())
        .env("Q_WORKSPACE", workspace)
        .env("Q_MODE", mode)
        .env("Q_RESOURCE_ROOT", runtime_root)
        .env(
            "Q_ENV",
            if cfg!(debug_assertions) {
                "development"
            } else {
                "production"
            },
        )
        .env("PYTHONPATH", development_root.join("apps/backend"))
        .current_dir(runtime_root)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    let mut child = command
        .spawn()
        .map_err(|error| format!("Could not start the packaged backend sidecar: {error}"))?;

    let started = Instant::now();
    while started.elapsed() < Duration::from_secs(15) {
        if let Some(status) = child
            .try_wait()
            .map_err(|error| format!("Could not inspect backend sidecar: {error}"))?
        {
            return Err(format!(
                "Backend sidecar exited during startup with {status}."
            ));
        }
        if TcpStream::connect(("127.0.0.1", port)).is_ok() {
            return Ok((
                BackendProcess { child: Some(child) },
                BackendConnection { port, token },
            ));
        }
        thread::sleep(Duration::from_millis(80));
    }
    let _ = child.kill();
    let _ = child.wait();
    Err("Backend sidecar did not become reachable before timeout.".to_owned())
}

#[tauri::command]
fn get_backend_connection(state: State<'_, ApplicationState>) -> BackendConnection {
    state.connection.clone()
}

#[tauri::command]
fn get_system_state(state: State<'_, ApplicationState>) -> Result<LifecycleSnapshot, String> {
    state
        .supervisor
        .lock()
        .map_err(|_| "Supervisor state is unavailable.".to_owned())
        .map(|supervisor| supervisor.snapshot())
}

#[tauri::command]
fn get_resource_snapshot(state: State<'_, ApplicationState>) -> Result<ResourceSnapshot, String> {
    state
        .supervisor
        .lock()
        .map_err(|_| "Supervisor state is unavailable.".to_owned())
        .map(|supervisor| supervisor.resources())
}

#[tauri::command]
fn get_hardware_snapshot() -> HardwareSnapshot {
    let mut system = System::new_all();
    system.refresh_memory();
    let total = system.total_memory();
    let logical_cpus = std::thread::available_parallelism().map_or(1, usize::from);
    let recommended_threads = logical_cpus.saturating_sub(1).clamp(1, 32);
    let recommended_context_length = if total >= 32 * 1024 * 1024 * 1024 {
        32_768
    } else if total >= 16 * 1024 * 1024 * 1024 {
        16_384
    } else {
        8_192
    };
    HardwareSnapshot {
        total_memory_bytes: total,
        available_memory_bytes: system.available_memory(),
        logical_cpus,
        recommended_threads,
        recommended_context_length,
    }
}

#[tauri::command]
fn store_credential(secret: String) -> Result<String, String> {
    let reference = Uuid::new_v4().to_string();
    supervisor::store_credential(&reference, &secret).map_err(|error| error.to_string())?;
    Ok(reference)
}

#[tauri::command]
fn delete_credential(credential_ref: String) -> Result<(), String> {
    supervisor::delete_credential(&credential_ref).map_err(|error| error.to_string())
}

#[derive(Debug, Serialize)]
struct FirstRunStatus {
    completed: bool,
    workspace: String,
    mode: String,
    llama_runtime: Option<String>,
    model_path: Option<String>,
    whisper_runtime: Option<String>,
    whisper_model: Option<String>,
}

#[derive(Debug, Deserialize)]
struct FirstRunRequest {
    workspace: String,
    mode: String,
    llama_runtime: Option<String>,
    model_path: Option<String>,
    whisper_runtime: Option<String>,
    whisper_model: Option<String>,
}

#[tauri::command]
fn get_first_run_status(state: State<'_, ApplicationState>) -> Result<FirstRunStatus, String> {
    state
        .configuration
        .lock()
        .map_err(|_| "Application configuration is unavailable.".to_owned())
        .map(|config| FirstRunStatus {
            completed: config.first_run_complete,
            workspace: config.workspace.to_string_lossy().into_owned(),
            mode: config.mode.clone(),
            llama_runtime: display_optional_path(&config.llama_runtime),
            model_path: display_optional_path(&config.model_path),
            whisper_runtime: display_optional_path(&config.whisper_runtime),
            whisper_model: display_optional_path(&config.whisper_model),
        })
}

#[tauri::command]
fn complete_first_run(
    app: tauri::AppHandle,
    state: State<'_, ApplicationState>,
    request: FirstRunRequest,
) -> Result<(), String> {
    let config = ApplicationConfig {
        first_run_complete: true,
        workspace: PathBuf::from(request.workspace),
        mode: request.mode,
        llama_runtime: optional_path(request.llama_runtime),
        model_path: optional_path(request.model_path),
        whisper_runtime: optional_path(request.whisper_runtime),
        whisper_model: optional_path(request.whisper_model),
    };
    config.save(&state.configuration_path)?;
    app.restart()
}

fn optional_path(value: Option<String>) -> Option<PathBuf> {
    value.and_then(|item| {
        let trimmed = item.trim();
        (!trimmed.is_empty()).then(|| PathBuf::from(trimmed))
    })
}

fn display_optional_path(value: &Option<PathBuf>) -> Option<String> {
    value
        .as_ref()
        .map(|path| path.to_string_lossy().into_owned())
}

pub fn run() {
    tracing_subscriber::fmt().json().with_target(false).init();
    tauri::Builder::default()
        .setup(|app| {
            let configuration_dir = app.path().app_config_dir()?;
            let configuration_path = configuration_dir.join("config.json");
            let default_base = app
                .path()
                .document_dir()
                .or_else(|_| app.path().app_data_dir())?;
            let default_workspace = default_base.join("ExperimentalQ");
            let defaults = ApplicationConfig::defaults(default_workspace);
            let mut configuration = ApplicationConfig::load(&configuration_path, defaults)
                .map_err(std::io::Error::other)?;
            let runtime_root = if cfg!(debug_assertions) {
                project_root()
            } else {
                app.path().resource_dir()?.join("resources")
            };
            configuration
                .apply_packaged_defaults(&runtime_root)
                .map_err(std::io::Error::other)?;
            let workspace = std::env::var_os("Q_WORKSPACE")
                .map(PathBuf::from)
                .unwrap_or_else(|| configuration.workspace.clone());
            let cache_root = workspace.join("Cache");
            std::fs::create_dir_all(&cache_root)?;
            let supervisor = Arc::new(Mutex::new(Supervisor::new(cache_root, workspace.clone())));
            let control_token = Alphanumeric.sample_string(&mut rand::rng(), 64);
            let control_server = ControlServer::start(
                Arc::clone(&supervisor),
                control_token,
                runtime_executable(&runtime_root, &configuration),
                worker_commands(&runtime_root, &configuration),
            )
            .map_err(std::io::Error::other)?;
            let (backend, connection) = start_backend(
                &control_server,
                &workspace,
                &runtime_root,
                &configuration.mode,
            )
            .map_err(std::io::Error::other)?;
            if let Ok(mut locked) = supervisor.lock() {
                if let Some(child) = backend.child.as_ref() {
                    locked.set_backend_pid(child.id());
                }
            }
            app.manage(ApplicationState {
                connection,
                supervisor,
                configuration: Mutex::new(configuration),
                configuration_path,
                _backend: backend,
                _control_server: control_server,
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_backend_connection,
            get_system_state,
            get_resource_snapshot,
            get_hardware_snapshot,
            store_credential,
            delete_credential,
            get_first_run_status,
            complete_first_run
        ])
        .run(tauri::generate_context!())
        .unwrap_or_else(|error| {
            tracing::error!(%error, "Experimental Q desktop failed");
        });
}
