# Experimental Q 0.3.0

Experimental Q es una estación científica de IA local para Windows. El modelo
GGUF es un componente de inferencia sin privilegios: puede razonar sobre el
contexto permitido, pero cualquier acción debe emitir un `ToolRequest`, pasar
por validación, política, confirmación y auditoría, y ejecutarse en un
controlador registrado.

## Estado de esta entrega

El árbol fuente cubre M1–M14 de Arquitectura 3.0 y contiene un pipeline
reproducible para generar y probar instaladores NSIS y MSI de un clic en un
runner nativo `windows-2022`. La compilación fija por commit llama.cpp y
whisper.cpp, fija por SHA-256 ambos modelos locales y no publica artefactos si
fallan las pruebas de instalación, arranque en OFF o desinstalación.

## Capacidades implementadas

| Hito | Implementación |
|---|---|
| M1–M2 | Supervisor Rust, estados exactos, procesos y recursos; llama.cpp/GGUF con carga, inferencia, streaming, cancelación, SLEEP y OFF. |
| M3–M4 | Contrato canónico de herramientas, registro, JSON Schema, política, retos de un uso, grants revocables, auditoría encadenada y procedencia. |
| M5–M6 | Proyectos aislados, raíces autorizadas, defensa de traversal/symlink/UNC y chat persistente con bucle de una acción por iteración. |
| M7–M8 | Perfilado CSV/XLSX/Parquet, DuckDB, ciencia determinista, visualización, DOCX/Markdown/PDF y artefactos con hash. |
| M9–M10 | Memoria local Qdrant, preferencias explícitas, RAG por proyecto, investigación HTTPS con política y bloqueo SSRF/Local Only. |
| M11–M13 | Workers Rust-owned para Python restringido, SQL, R y paquetes; Git HTTPS con referencias de credencial; Q Notebook. |
| M14 | Micrófono PCM local con whisper.cpp, GGUF Qwen2.5 local incluido, asistente inicial preconfigurado, NSIS/MSI, WebView2 offline, desinstalación conservadora y firma opcional obligable. |

La interfaz incluye Chat, Proyectos, exploración recursiva autorizada, Datos,
Conocimiento, Notebook, Modelos, Herramientas, Memoria, artefactos y una paleta
`Ctrl+K`. No muestra ni persiste cadena de pensamiento interna; presenta
respuestas y acciones controladas.

## Seguridad por diseño

- No existe herramienta de shell, registro, control arbitrario de procesos ni
  filesystem irrestricto para Q.
- Backend y llama.cpp usan puertos aleatorios en `127.0.0.1` y tokens por
  lanzamiento que no se escriben a disco.
- `Local Only` bloquea red externa antes de invocar un cliente HTTP.
- Los secretos se referencian por identificador opaco y, en Windows, se guardan
  mediante el almacén nativo de credenciales; nunca entran al prompt o auditoría.
- Q inicia `OFF`, queda descargado en `SLEEP` y nunca se registra en el inicio de
  Windows.
- La memoria sensible se rechaza mientras no exista una bóveda cifrada. El seed
  personal incluido contiene únicamente preferencias profesionales no sensibles
  autorizadas expresamente para esta entrega.

## Desarrollo

Requisitos: Python 3.12+, Node.js 22+, pnpm y Rust estable 1.88+.

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -e ".[dev]"
corepack pnpm install --frozen-lockfile
corepack pnpm dev
```

En desarrollo, Tauri ejecuta `.venv/Scripts/python.exe`; el paquete final usa
`q-backend.exe`. La distribución Windows incluye
Qwen2.5-1.5B-Instruct Q4_K_M como `experimental-q.gguf`; el usuario puede
sustituirlo por otro GGUF desde el asistente o **Modelos**. Q nunca descarga un
modelo durante la ejecución y siempre inicia `OFF`.

## Verificación local

```powershell
python -m ruff check .
python -m mypy apps/backend runtimes tests
python -m pytest -q
corepack pnpm typecheck
corepack pnpm test
corepack pnpm --filter @experimental-q/desktop build
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace
python scripts/verify_packaging.py
```

## Generar NSIS y MSI en Windows

El build exige directorios revisados de llama.cpp y whisper.cpp, manifiestos de
todos sus archivos y hashes SHA-256. También exige un modelo local de whisper;
el modelo Q GGUF no se empaqueta silenciosamente.

```powershell
$env:Q_LLAMA_RUNTIME_DIR = "C:\reviewed\llama"
$env:Q_LLAMA_RUNTIME_MANIFEST = "C:\reviewed\llama-manifest.json"
$env:Q_WHISPER_RUNTIME_DIR = "C:\reviewed\whisper"
$env:Q_WHISPER_RUNTIME_MANIFEST = "C:\reviewed\whisper-manifest.json"
$env:Q_WHISPER_MODEL_PATH = "C:\reviewed\ggml-base.bin"
$env:Q_WHISPER_MODEL_SHA256 = "<sha256>"
$env:Q_MODEL_PATH = "C:\reviewed\experimental-q.gguf"
$env:Q_MODEL_SHA256 = "<sha256>"
./scripts/build_windows.ps1
```

`scripts/prepare_windows_dependencies.ps1` puede producir todos esos insumos
desde `installer/runtime-sources.lock.json`. La salida es `release/*.exe`,
`release/*.msi`, `release/release-manifest.json` y evidencia del smoke test.
Para exigir firma Authenticode, configura
`WINDOWS_CERTIFICATE_THUMBPRINT` y ejecuta
`./scripts/build_windows.ps1 -RequireSigning`. El workflow
`.github/workflows/release-windows.yml` ejecuta todo el proceso sin entradas
manuales; usa secretos de GitHub únicamente si se proporciona un PFX real.

Consulta `installer/README.md`, `docs/IMPLEMENTATION_MANIFEST.md` y
`docs/COMPATIBILITY_REPORT.md` antes de publicar una versión.
