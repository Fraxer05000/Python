"""Static and staged-resource smoke checks for Windows packaging."""

from __future__ import annotations

import argparse
import json
import re
import sys
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TAURI_CONFIG = ROOT / "apps" / "desktop" / "src-tauri" / "tauri.conf.json"
NSIS_HOOKS = ROOT / "installer" / "nsis" / "installer-hooks.nsh"
BUILD_SCRIPT = ROOT / "scripts" / "build_windows.ps1"
PREPARE_SCRIPT = ROOT / "scripts" / "prepare_windows_dependencies.ps1"
SMOKE_SCRIPT = ROOT / "scripts" / "smoke_test_windows_installers.ps1"
RELEASE_WORKFLOW = ROOT / ".github" / "workflows" / "release-windows.yml"
RUNTIME_LOCK = ROOT / "installer" / "runtime-sources.lock.json"
VERSION = "0.3.0"


class PackagingFailure(RuntimeError):
    """Packaging configuration failed a release invariant."""


def _json_object(path: Path) -> dict[str, object]:
    value: object = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not all(isinstance(key, str) for key in value):
        raise PackagingFailure(f"{path.name} must contain a JSON object")
    return value


def _object(parent: dict[str, object], key: str) -> dict[str, object]:
    value = parent.get(key)
    if not isinstance(value, dict) or not all(isinstance(item, str) for item in value):
        raise PackagingFailure(f"missing object: {key}")
    return value


def verify_configuration() -> list[str]:
    checks: list[str] = []
    tauri = _json_object(TAURI_CONFIG)
    if tauri.get("version") != VERSION:
        raise PackagingFailure("Tauri version is not synchronized")
    bundle = _object(tauri, "bundle")
    targets = bundle.get("targets")
    if not isinstance(targets, list) or set(targets) != {"nsis", "msi"}:
        raise PackagingFailure("both NSIS and MSI targets are required")
    windows = _object(bundle, "windows")
    webview = _object(windows, "webviewInstallMode")
    if webview.get("type") != "offlineInstaller":
        raise PackagingFailure("WebView2 must use the offline installer")
    nsis = _object(windows, "nsis")
    if nsis.get("installMode") != "currentUser":
        raise PackagingFailure("NSIS must default to current-user installation")
    if nsis.get("installerHooks") != "../../../installer/nsis/installer-hooks.nsh":
        raise PackagingFailure("NSIS safety hooks are not configured")
    wix = _object(windows, "wix")
    if not isinstance(wix.get("upgradeCode"), str):
        raise PackagingFailure("MSI upgrade code must be stable")
    checks.extend(["nsis_target", "msi_target", "offline_webview2", "stable_upgrade"])

    root_package = _json_object(ROOT / "package.json")
    desktop_package = _json_object(ROOT / "apps" / "desktop" / "package.json")
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    cargo = tomllib.loads(
        (ROOT / "apps" / "desktop" / "src-tauri" / "Cargo.toml").read_text(
            encoding="utf-8"
        )
    )
    versions = {
        root_package.get("version"),
        desktop_package.get("version"),
        pyproject["project"]["version"],
        cargo["package"]["version"],
        tauri.get("version"),
    }
    if versions != {VERSION}:
        raise PackagingFailure(f"release versions differ: {sorted(str(item) for item in versions)}")
    checks.append("synchronized_versions")

    hooks = NSIS_HOOKS.read_text(encoding="utf-8")
    for required in ("CurrentBuildNumber", "DriveSpace", "NSIS_HOOK_PREUNINSTALL"):
        if required not in hooks:
            raise PackagingFailure(f"NSIS hooks lack {required}")
    build_script = BUILD_SCRIPT.read_text(encoding="utf-8")
    prepare_script = PREPARE_SCRIPT.read_text(encoding="utf-8")
    smoke_script = SMOKE_SCRIPT.read_text(encoding="utf-8")
    release_workflow = RELEASE_WORKFLOW.read_text(encoding="utf-8")
    write_surface = "\n".join((hooks, build_script, prepare_script, release_workflow))
    forbidden = (
        r"CurrentVersion\\Run(?:Once)?",
        r"\\Start Menu\\Programs\\Startup",
        r"\bschtasks(?:\.exe)?\b",
    )
    for pattern in forbidden:
        if re.search(pattern, write_surface, flags=re.IGNORECASE):
            raise PackagingFailure(f"startup registration is forbidden: {pattern}")
    required_build_controls = {
        "runtime_file_hashes": "Copy-VerifiedRuntime",
        "whisper_model_hash": "Q_WHISPER_MODEL_SHA256",
        "q_model_hash": "Q_MODEL_SHA256",
        "python_sidecars": "PyInstaller",
        "native_runtime_smoke": "Test-NativeRuntimes",
        "native_test_gate": 'cargo @("test", "--workspace")',
        "both_bundle_outputs": '"tauri", "build", "--bundles", "nsis,msi"',
        "signature_verification": 'signtool.exe @("verify", "/pa"',
        "release_manifest": "release-manifest.json",
    }
    for check, marker in required_build_controls.items():
        if marker not in build_script:
            raise PackagingFailure(f"Windows build script lacks {check}")
        checks.append(check)
    runtime_lock = _json_object(RUNTIME_LOCK)
    if runtime_lock.get("format_version") != 1 or runtime_lock.get("target") != "windows-x86_64":
        raise PackagingFailure("runtime source lock is invalid")
    if "curl.exe" not in prepare_script or "Get-FileHash" not in prepare_script:
        raise PackagingFailure("model downloads are not hash-gated")
    action_uses = re.findall(r"^\s*uses:\s*([^\s]+)\s*$", release_workflow, re.MULTILINE)
    if not action_uses or any(
        "@" not in item or not re.fullmatch(r"[^@]+@[0-9a-f]{40}", item)
        for item in action_uses
    ):
        raise PackagingFailure("release workflow actions must use full commit SHAs")
    if "if-no-files-found: error" not in release_workflow:
        raise PackagingFailure("release workflow can silently publish no installers")
    if "smoke_test_windows_installers.ps1" not in release_workflow:
        raise PackagingFailure("release workflow does not execute installer smoke tests")
    if (
        "Test-ApplicationStartsOff" not in smoke_script
        or "Assert-NoExperimentalQAutostart" not in smoke_script
    ):
        raise PackagingFailure("installer smoke test lacks lifecycle or autostart checks")
    checks.extend(
        [
            "windows_version_gate",
            "disk_space_gate",
            "no_autostart",
            "workflow_download_hashes",
            "workflow_action_pins",
            "installer_smoke_gate",
            "artifact_required",
        ]
    )
    return checks


def verify_staged_resources(resource_root: Path) -> list[str]:
    required = (
        "bin/q-backend.exe",
        "bin/q-python-worker.exe",
        "bin/q-sql-worker.exe",
        "bin/q-package-worker.exe",
        "bin/q-audio-worker.exe",
        "bin/llama_cpp/llama-server.exe",
        "bin/whisper_cpp/whisper-cli.exe",
        "models/experimental-q.gguf",
        "models/ggml-base.bin",
        "config/tool_registry.json",
        "config/permission_policy.yaml",
        "config/personal_context.seed.json",
        "runtimes/r_worker/worker.R",
        "THIRD_PARTY_NOTICES.md",
        "licenses/Apache-2.0.txt",
        "licenses/MIT-ggml-runtimes.txt",
    )
    missing = [item for item in required if not (resource_root / item).is_file()]
    if missing:
        raise PackagingFailure(f"staged release resources are missing: {', '.join(missing)}")
    names = {path.name.lower() for path in resource_root.rglob("*") if path.is_file()}
    gguf_files = sorted(name for name in names if name.endswith(".gguf"))
    if gguf_files != ["experimental-q.gguf"]:
        raise PackagingFailure("release must contain exactly the reviewed Experimental Q GGUF")
    suspicious = {".env", "credentials.json", "secrets.json", "id_rsa", "id_ed25519"}
    found = sorted(names & suspicious)
    if found:
        raise PackagingFailure(f"secret-like release resources found: {', '.join(found)}")
    return [
        "sidecars_present",
        "runtimes_present",
        "contracts_present",
        "reviewed_q_model_present",
        "third_party_licenses_present",
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--resource-root", type=Path)
    options = parser.parse_args()
    try:
        checks = verify_configuration()
        if options.resource_root is not None:
            checks.extend(verify_staged_resources(options.resource_root.resolve(strict=True)))
    except (
        OSError,
        KeyError,
        json.JSONDecodeError,
        tomllib.TOMLDecodeError,
        PackagingFailure,
    ) as exc:
        sys.stderr.write(json.dumps({"status": "failed", "error": str(exc)}) + "\n")
        return 1
    sys.stdout.write(json.dumps({"status": "ok", "checks": checks}, sort_keys=True) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
