# Experimental Q third-party notices

The Windows installer contains the following reviewed local components. Their
source revisions and binary/model hashes are recorded in
`installer/runtime-sources.lock.json` and in the generated release manifest.

## Qwen2.5-1.5B-Instruct-GGUF

- Copyright: Qwen Team / Alibaba Cloud contributors.
- Variant: Q4_K_M GGUF.
- License: Apache License 2.0.
- Source: https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF
- License copy: `licenses/Apache-2.0.txt`.

## llama.cpp and whisper.cpp

- Copyright (c) 2023-2026 The ggml authors.
- License: MIT.
- Sources: https://github.com/ggml-org/llama.cpp and
  https://github.com/ggml-org/whisper.cpp.
- License copy: `licenses/MIT-ggml-runtimes.txt`.

## Whisper base multilingual model

- Converted model distributed by the whisper.cpp project.
- Source: https://huggingface.co/ggerganov/whisper.cpp
- Runtime/model notices are provided by the upstream whisper.cpp project.

Experimental Q does not send prompts, microphone recordings, personal memory,
or telemetry to these projects. All included inference executes locally.
