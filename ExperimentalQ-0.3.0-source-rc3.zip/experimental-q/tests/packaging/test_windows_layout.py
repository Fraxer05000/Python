from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_windows_packaging_configuration_smoke() -> None:
    result = subprocess.run(  # noqa: S603 - fixed repository validation entry point
        [sys.executable, str(ROOT / "scripts" / "verify_packaging.py")],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
        timeout=10,
    )
    assert result.returncode == 0, result.stderr
    assert '"status": "ok"' in result.stdout
    assert "workflow_action_pins" in result.stdout
    assert "installer_smoke_gate" in result.stdout
    assert "q_model_hash" in result.stdout
