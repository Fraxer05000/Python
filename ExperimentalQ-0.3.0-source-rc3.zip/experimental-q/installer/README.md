# Windows packaging

`scripts/build_windows.ps1` produces both supported one-click artifacts:

- an NSIS current-user `.exe` installer;
- an MSI package with a stable upgrade code.

The packages embed WebView2's offline installer, the FastAPI sidecar, all
supervisor-owned Python workers, reviewed `llama.cpp` and `whisper.cpp`
runtimes, a local whisper model, and the reviewed
Qwen2.5-1.5B-Instruct Q4_K_M GGUF. The first-run wizard is prefilled with the
installed paths but Q remains OFF until the user selects **Start Q**.

## Trusted runtime inputs

The build accepts runtime directories only with reviewed JSON manifests. Each
manifest has the shape shown in `runtime-manifest.example.json`; every copied
file is path-contained and SHA-256 verified. Set these variables before the
build:

```powershell
$env:Q_LLAMA_RUNTIME_DIR = "C:\reviewed\llama"
$env:Q_LLAMA_RUNTIME_MANIFEST = "C:\reviewed\llama-manifest.json"
$env:Q_WHISPER_RUNTIME_DIR = "C:\reviewed\whisper"
$env:Q_WHISPER_RUNTIME_MANIFEST = "C:\reviewed\whisper-manifest.json"
$env:Q_WHISPER_MODEL_PATH = "C:\reviewed\ggml-base.bin"
$env:Q_WHISPER_MODEL_SHA256 = "<64 hexadecimal characters>"
$env:Q_MODEL_PATH = "C:\reviewed\experimental-q.gguf"
$env:Q_MODEL_SHA256 = "<64 hexadecimal characters>"
./scripts/build_windows.ps1
```

For the reproducible release inputs used by CI, run
`./scripts/prepare_windows_dependencies.ps1`. It checks out the two native
runtimes at full commit SHAs, builds generic Windows x64 CPU binaries, downloads
the two models over HTTPS, verifies their SHA-256 values, and emits per-file
runtime manifests. `scripts/smoke_test_windows_installers.ps1` then installs,
launches with Q OFF, and uninstalls NSIS and MSI while verifying that no startup
entry exists and the user workspace is preserved.

For signed output, import the code-signing certificate into the current user's
certificate store, set `WINDOWS_CERTIFICATE_THUMBPRINT`, and run with
`-RequireSigning`. The script verifies each signature before copying the
installers to `release/`.

The installer never creates a startup entry. Uninstall preserves workspaces,
projects, datasets, model files, and personal memory by default. NSIS offers to
remove only the shell cache; MSI preserves all user data for manual cleanup.
