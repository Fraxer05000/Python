# Experimental Q third-party notices

The Windows installer contains the following reviewed local components. Their
source revisions and binary/model hashes are recorded in
`installer/runtime-sources.lock.json` and in the generated release manifest.

## Qwen2.5-1.5B-Instruct-GGUF

- Copyright: Qwen Team / Alibaba Cloud contributors.
- Variant: Q4_K_M GGUF.
- License: Apache License 2.0.
- Source: https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF
- License copy: `licenses/Apache-2.0.txt`.

## llama.cpp and whisper.cpp

- Copyright (c) 2023-2026 The ggml authors.
- License: MIT.
- Sources: https://github.com/ggml-org/llama.cpp and
  https://github.com/ggml-org/whisper.cpp.
- License copy: `licenses/MIT-ggml-runtimes.txt`.

## Whisper base multilingual model

- Converted model distributed by the whisper.cpp project.
- Source: https://huggingface.co/ggerganov/whisper.cpp
- Runtime/model notices are provided by the upstream whisper.cpp project.

## process-wrap

- Copyright (c) the process-wrap contributors.
- Version: 9.1.0.
- License: Apache License 2.0 or MIT.
- Source: https://github.com/watchexec/process-wrap.
- Used only by the Rust supervisor to atomically contain Windows child process
  trees in Job Objects.
- Apache license copy: `licenses/Apache-2.0.txt`.

Experimental Q does not send prompts, microphone recordings, personal memory,
or telemetry to these projects. All included inference executes locally.
