use std::io;
use std::process::{ChildStderr, ChildStdin, ChildStdout, Command, ExitStatus};

#[cfg(not(target_os = "windows"))]
use std::process::Child;

#[cfg(target_os = "windows")]
type InnerChild = Box<dyn process_wrap::std::ChildWrapper>;
#[cfg(not(target_os = "windows"))]
type InnerChild = Child;

/// A process owned exclusively by the desktop supervisor.
///
/// On Windows the process is created suspended, assigned to a Job Object, and
/// only then resumed. Termination therefore applies to the complete descendant
/// tree, including the parent/child pair produced by PyInstaller one-file
/// executables. This type is never exposed through a Tauri command or tool
/// contract.
pub struct ManagedChild {
    inner: InnerChild,
    reaped: bool,
}

impl ManagedChild {
    pub fn spawn(command: Command) -> io::Result<Self> {
        #[cfg(target_os = "windows")]
        let inner = {
            use process_wrap::std::{CommandWrap, JobObject};

            let mut command = CommandWrap::from(command);
            command.wrap(JobObject);
            command.spawn()?
        };

        #[cfg(not(target_os = "windows"))]
        let inner = {
            let mut command = command;
            command.spawn()?
        };

        let child = Self {
            inner,
            reaped: false,
        };
        tracing::info!(
            pid = child.id(),
            containment = containment_name(),
            "supervisor started managed process"
        );
        Ok(child)
    }

    pub fn id(&self) -> u32 {
        #[cfg(target_os = "windows")]
        {
            self.inner.id()
        }
        #[cfg(not(target_os = "windows"))]
        {
            self.inner.id()
        }
    }

    pub fn take_stdin(&mut self) -> Option<ChildStdin> {
        #[cfg(target_os = "windows")]
        {
            self.inner.stdin().take()
        }
        #[cfg(not(target_os = "windows"))]
        {
            self.inner.stdin.take()
        }
    }

    pub fn take_stdout(&mut self) -> Option<ChildStdout> {
        #[cfg(target_os = "windows")]
        {
            self.inner.stdout().take()
        }
        #[cfg(not(target_os = "windows"))]
        {
            self.inner.stdout.take()
        }
    }

    pub fn take_stderr(&mut self) -> Option<ChildStderr> {
        #[cfg(target_os = "windows")]
        {
            self.inner.stderr().take()
        }
        #[cfg(not(target_os = "windows"))]
        {
            self.inner.stderr.take()
        }
    }

    pub fn try_wait(&mut self) -> io::Result<Option<ExitStatus>> {
        self.inner.try_wait()
    }

    pub fn wait(&mut self) -> io::Result<ExitStatus> {
        let status = self.inner.wait()?;
        self.reaped = true;
        tracing::info!(pid = self.id(), %status, "managed process tree exited");
        Ok(status)
    }

    pub fn terminate_and_wait(&mut self) -> io::Result<()> {
        if self.reaped {
            return Ok(());
        }

        #[cfg(target_os = "windows")]
        self.inner.kill()?;

        #[cfg(not(target_os = "windows"))]
        {
            self.inner.kill()?;
            let _ = self.inner.wait()?;
        }

        self.reaped = true;
        tracing::info!(
            pid = self.id(),
            containment = containment_name(),
            "supervisor terminated managed process tree"
        );
        Ok(())
    }
}

impl Drop for ManagedChild {
    fn drop(&mut self) {
        if let Err(error) = self.terminate_and_wait() {
            tracing::warn!(
                pid = self.id(),
                %error,
                "managed process tree cleanup returned an error"
            );
        }
    }
}

const fn containment_name() -> &'static str {
    if cfg!(target_os = "windows") {
        "windows_job_object"
    } else {
        "direct_child"
    }
}

#[cfg(all(test, target_os = "windows"))]
mod tests {
    use super::ManagedChild;
    use std::error::Error;
    use std::process::{Command, Stdio};
    use std::thread;
    use std::time::{Duration, Instant};
    use sysinfo::{Pid, System};
    use uuid::Uuid;

    #[test]
    fn windows_job_terminates_descendants() -> Result<(), Box<dyn Error>> {
        let pid_path = std::env::temp_dir().join(format!(
            "experimental-q-managed-child-{}.pid",
            Uuid::new_v4()
        ));
        let quoted_path = pid_path.to_string_lossy().replace('\'', "''");
        let script = format!(
            "$child = Start-Process -FilePath $env:ComSpec \
             -ArgumentList '/D','/C','ping -n 120 127.0.0.1 >NUL' \
             -WindowStyle Hidden -PassThru; \
             [IO.File]::WriteAllText('{quoted_path}', [string]$child.Id); \
             Start-Sleep -Seconds 120"
        );
        let mut command = Command::new("powershell.exe");
        command
            .args([
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                &script,
            ])
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null());
        let mut managed = ManagedChild::spawn(command)?;

        let deadline = Instant::now() + Duration::from_secs(10);
        while !pid_path.is_file() && Instant::now() < deadline {
            thread::sleep(Duration::from_millis(50));
        }
        let descendant_pid: u32 = std::fs::read_to_string(&pid_path)?.trim().parse()?;
        managed.terminate_and_wait()?;
        thread::sleep(Duration::from_millis(250));

        let mut system = System::new_all();
        system.refresh_all();
        assert!(system.process(Pid::from_u32(descendant_pid)).is_none());
        std::fs::remove_file(pid_path)?;
        Ok(())
    }
}
