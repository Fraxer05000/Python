[CmdletBinding()]
param(
  [string]$OutputDirectory = "release",
  [switch]$RequireSigning
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$RepositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ResourceRoot = Join-Path $RepositoryRoot "apps\desktop\src-tauri\resources"
$BinaryRoot = Join-Path $ResourceRoot "bin"
$PyInstallerRoot = Join-Path $RepositoryRoot "build\pyinstaller"
$ReleaseRoot = [IO.Path]::GetFullPath((Join-Path $RepositoryRoot $OutputDirectory))

function Assert-Command {
  param([Parameter(Mandatory)][string]$Name)
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    throw "Required build command is unavailable: $Name"
  }
}

function Assert-WindowsHost {
  if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw "NSIS/MSI packages must be built on Windows."
  }
  $Build = [Environment]::OSVersion.Version.Build
  if ($Build -lt 19041) {
    throw "Windows build 19041 or later is required; detected $Build."
  }
  $Root = [IO.Path]::GetPathRoot($RepositoryRoot)
  $DriveName = $Root.TrimEnd("\").TrimEnd(":")
  $Drive = Get-PSDrive -Name $DriveName
  if ($Drive.Free -lt 10GB) {
    throw "At least 10 GB of free build space is required."
  }
}

function Get-RequiredEnvironmentPath {
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][ValidateSet("Leaf", "Container")][string]$PathType
  )
  $Value = [Environment]::GetEnvironmentVariable($Name)
  if ([string]::IsNullOrWhiteSpace($Value)) {
    throw "Required environment variable is missing: $Name"
  }
  $Resolved = (Resolve-Path -LiteralPath $Value).Path
  if (-not (Test-Path -LiteralPath $Resolved -PathType $PathType)) {
    throw "$Name does not reference a $PathType path."
  }
  return $Resolved
}

function Copy-VerifiedRuntime {
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][string]$SourceDirectory,
    [Parameter(Mandatory)][string]$ManifestPath,
    [Parameter(Mandatory)][string]$DestinationDirectory,
    [Parameter(Mandatory)][string]$RequiredExecutable
  )
  $Manifest = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($Manifest.format_version -ne 1 -or $null -eq $Manifest.files) {
    throw "$Name runtime manifest is invalid."
  }
  $SourceRoot = [IO.Path]::GetFullPath($SourceDirectory).TrimEnd("\") + "\"
  $RequiredFound = $false
  foreach ($Entry in $Manifest.files) {
    $Relative = [string]$Entry.path
    $ExpectedHash = ([string]$Entry.sha256).ToLowerInvariant()
    if ([IO.Path]::IsPathRooted($Relative) -or ($Relative -split "[\\/]" -contains "..")) {
      throw "$Name runtime manifest contains an unsafe path."
    }
    if ($ExpectedHash -notmatch "^[0-9a-f]{64}$") {
      throw "$Name runtime manifest contains an invalid SHA-256 value for $Relative."
    }
    $Source = [IO.Path]::GetFullPath((Join-Path $SourceDirectory $Relative))
    if (-not $Source.StartsWith($SourceRoot, [StringComparison]::OrdinalIgnoreCase)) {
      throw "$Name runtime file escapes its source directory."
    }
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
      throw "$Name runtime file is missing: $Relative"
    }
    $ActualHash = (Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($ActualHash -ne $ExpectedHash) {
      throw "$Name runtime hash mismatch: $Relative"
    }
    $Destination = Join-Path $DestinationDirectory $Relative
    New-Item -ItemType Directory -Force -Path (Split-Path $Destination) | Out-Null
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
    if ($Relative.Replace("/", "\") -ieq $RequiredExecutable) {
      $RequiredFound = $true
    }
  }
  if (-not $RequiredFound) {
    throw "$Name manifest must include $RequiredExecutable."
  }
}

function Invoke-Checked {
  param(
    [Parameter(Mandatory)][string]$Command,
    [Parameter(ValueFromRemainingArguments)][string[]]$Arguments
  )
  & $Command @Arguments
  if ($LASTEXITCODE -ne 0) {
    throw "Command failed ($LASTEXITCODE): $Command $($Arguments -join ' ')"
  }
}

function Stage-LargeFile {
  param(
    [Parameter(Mandatory)][string]$Source,
    [Parameter(Mandatory)][string]$Destination
  )
  try {
    New-Item -ItemType HardLink -Path $Destination -Target $Source -ErrorAction Stop | Out-Null
  }
  catch {
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
  }
}

function Build-PythonSidecar {
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][string]$EntryPoint,
    [string[]]$AdditionalArguments = @()
  )
  $Arguments = @(
    "-m", "PyInstaller", "--noconfirm", "--clean", "--onefile",
    "--name", $Name,
    "--distpath", (Join-Path $PyInstallerRoot "dist"),
    "--workpath", (Join-Path $PyInstallerRoot "work\$Name"),
    "--specpath", (Join-Path $PyInstallerRoot "spec")
  ) + $AdditionalArguments + @($EntryPoint)
  Invoke-Checked python $Arguments
}

function New-SilenceWave {
  param([Parameter(Mandatory)][string]$Path)
  $SampleRate = 16000
  $Channels = 1
  $BitsPerSample = 16
  $Data = [byte[]]::new($SampleRate * 2)
  $Stream = [IO.File]::Create($Path)
  $Writer = [IO.BinaryWriter]::new($Stream)
  try {
    $Writer.Write([Text.Encoding]::ASCII.GetBytes("RIFF"))
    $Writer.Write([uint32](36 + $Data.Length))
    $Writer.Write([Text.Encoding]::ASCII.GetBytes("WAVEfmt "))
    $Writer.Write([uint32]16)
    $Writer.Write([uint16]1)
    $Writer.Write([uint16]$Channels)
    $Writer.Write([uint32]$SampleRate)
    $Writer.Write([uint32]($SampleRate * $Channels * ($BitsPerSample / 8)))
    $Writer.Write([uint16]($Channels * ($BitsPerSample / 8)))
    $Writer.Write([uint16]$BitsPerSample)
    $Writer.Write([Text.Encoding]::ASCII.GetBytes("data"))
    $Writer.Write([uint32]$Data.Length)
    $Writer.Write($Data)
  }
  finally {
    $Writer.Dispose()
    $Stream.Dispose()
  }
}

function Test-NativeRuntimes {
  param(
    [Parameter(Mandatory)][string]$LlamaExecutable,
    [Parameter(Mandatory)][string]$QModelPath,
    [Parameter(Mandatory)][string]$WhisperExecutable,
    [Parameter(Mandatory)][string]$WhisperModelPath
  )
  $SmokeRoot = Join-Path $RepositoryRoot "build\native-runtime-smoke"
  if (Test-Path -LiteralPath $SmokeRoot) {
    Remove-Item -LiteralPath $SmokeRoot -Recurse -Force
  }
  New-Item -ItemType Directory -Force -Path $SmokeRoot | Out-Null
  $Listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
  $Listener.Start()
  $Port = ([Net.IPEndPoint]$Listener.LocalEndpoint).Port
  $Listener.Stop()
  $ApiKey = "experimental-q-native-smoke"
  $Stdout = Join-Path $SmokeRoot "llama.stdout.log"
  $Stderr = Join-Path $SmokeRoot "llama.stderr.log"
  $Process = Start-Process -FilePath $LlamaExecutable -ArgumentList @(
    "--model", $QModelPath,
    "--host", "127.0.0.1",
    "--port", $Port,
    "--ctx-size", "1024",
    "--parallel", "1",
    "--threads", "2",
    "--batch-size", "128",
    "--n-gpu-layers", "0",
    "--api-key", $ApiKey
  ) -RedirectStandardOutput $Stdout -RedirectStandardError $Stderr -PassThru
  try {
    $Headers = @{ Authorization = "Bearer $ApiKey" }
    $Deadline = [DateTime]::UtcNow.AddSeconds(120)
    $Healthy = $false
    while ([DateTime]::UtcNow -lt $Deadline -and -not $Process.HasExited) {
      try {
        $Health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Headers $Headers -TimeoutSec 2
        if ($null -ne $Health) {
          $Healthy = $true
          break
        }
      }
      catch {
        Start-Sleep -Milliseconds 500
      }
    }
    if (-not $Healthy) {
      $Detail = if (Test-Path -LiteralPath $Stderr) { Get-Content -LiteralPath $Stderr -Tail 30 | Out-String } else { "no log" }
      throw "Pinned llama.cpp/Q GGUF failed its loopback health check: $Detail"
    }
    $Tool = [ordered]@{
      type = "function"
      function = [ordered]@{
        name = "q_tool_request"
        description = "Request one registered Experimental Q controller action."
        parameters = [ordered]@{
          type = "object"
          required = @("request_id", "tool", "arguments", "reason", "project_id")
          properties = [ordered]@{
            request_id = @{ type = "string" }
            tool = @{ type = "string"; enum = @("system.resources") }
            arguments = @{ type = "object" }
            reason = @{ type = "string" }
            project_id = @{ type = @("string", "null") }
          }
          additionalProperties = $false
        }
      }
    }
    $ExpectedRequestId = "00000000-0000-4000-8000-000000000001"
    $Payload = [ordered]@{
      messages = @(
        @{ role = "system"; content = "Call q_tool_request exactly once. Never claim execution." },
        @{ role = "user"; content = "Request system.resources with request_id $ExpectedRequestId, empty arguments, reason Verificar recursos, and null project_id." }
      )
      tools = @($Tool)
      tool_choice = "required"
      temperature = 0
      max_tokens = 96
      stream = $false
    } | ConvertTo-Json -Depth 12
    $Response = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$Port/v1/chat/completions" -Headers $Headers -ContentType "application/json" -Body $Payload -TimeoutSec 600
    if ($null -eq $Response.choices -or $Response.choices.Count -lt 1) {
      throw "Pinned Q GGUF did not return an OpenAI-compatible chat response."
    }
    $Calls = $Response.choices[0].message.tool_calls
    if ($null -eq $Calls -or $Calls.Count -ne 1 -or $Calls[0].function.name -ne "q_tool_request") {
      throw "Pinned Q GGUF did not honor the forced canonical controller request."
    }
    $Arguments = $Calls[0].function.arguments | ConvertFrom-Json
    $ArgumentNames = @($Arguments.PSObject.Properties.Name)
    $CanonicalNames = @("request_id", "tool", "arguments", "reason", "project_id")
    if (@($CanonicalNames | Where-Object { $_ -notin $ArgumentNames }).Count -ne 0 -or
        @($ArgumentNames | Where-Object { $_ -notin $CanonicalNames }).Count -ne 0 -or
        $Arguments.request_id -ne $ExpectedRequestId -or
        $Arguments.tool -ne "system.resources" -or
        $null -eq $Arguments.arguments -or
        @($Arguments.arguments.PSObject.Properties).Count -ne 0 -or
        [string]::IsNullOrWhiteSpace([string]$Arguments.reason) -or
        $null -ne $Arguments.project_id) {
      throw "Pinned Q GGUF emitted an invalid canonical controller request."
    }
  }
  finally {
    if (-not $Process.HasExited) {
      Stop-Process -Id $Process.Id -Force
      $Process.WaitForExit()
    }
  }

  $Wave = Join-Path $SmokeRoot "silence.wav"
  $TranscriptBase = Join-Path $SmokeRoot "silence-transcript"
  New-SilenceWave $Wave
  Invoke-Checked $WhisperExecutable @("-m", $WhisperModelPath, "-f", $Wave, "-l", "es", "-oj", "-of", $TranscriptBase)
  if (-not (Test-Path -LiteralPath "$TranscriptBase.json" -PathType Leaf)) {
    throw "Pinned whisper.cpp/model did not produce JSON output."
  }
}

Assert-WindowsHost
foreach ($Command in @("python", "node", "corepack", "cargo", "rustc")) {
  Assert-Command $Command
}

$PythonVersion = (& python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')").Trim()
if ($PythonVersion -ne "3.12") {
  throw "Python 3.12 is required; detected $PythonVersion."
}

$LlamaDirectory = Get-RequiredEnvironmentPath "Q_LLAMA_RUNTIME_DIR" "Container"
$LlamaManifest = Get-RequiredEnvironmentPath "Q_LLAMA_RUNTIME_MANIFEST" "Leaf"
$WhisperDirectory = Get-RequiredEnvironmentPath "Q_WHISPER_RUNTIME_DIR" "Container"
$WhisperManifest = Get-RequiredEnvironmentPath "Q_WHISPER_RUNTIME_MANIFEST" "Leaf"
$WhisperModel = Get-RequiredEnvironmentPath "Q_WHISPER_MODEL_PATH" "Leaf"
$WhisperModelHashValue = [Environment]::GetEnvironmentVariable("Q_WHISPER_MODEL_SHA256")
if ([string]::IsNullOrWhiteSpace($WhisperModelHashValue) -or $WhisperModelHashValue -notmatch "^[0-9A-Fa-f]{64}$") {
  throw "Q_WHISPER_MODEL_SHA256 must be a SHA-256 digest."
}
$WhisperModelHash = $WhisperModelHashValue.ToLowerInvariant()
if ((Get-FileHash -LiteralPath $WhisperModel -Algorithm SHA256).Hash.ToLowerInvariant() -ne $WhisperModelHash) {
  throw "Whisper model hash mismatch."
}
$QModel = Get-RequiredEnvironmentPath "Q_MODEL_PATH" "Leaf"
$QModelHashValue = [Environment]::GetEnvironmentVariable("Q_MODEL_SHA256")
if ([string]::IsNullOrWhiteSpace($QModelHashValue) -or $QModelHashValue -notmatch "^[0-9A-Fa-f]{64}$") {
  throw "Q_MODEL_SHA256 must be a SHA-256 digest."
}
$QModelHash = $QModelHashValue.ToLowerInvariant()
if ((Get-FileHash -LiteralPath $QModel -Algorithm SHA256).Hash.ToLowerInvariant() -ne $QModelHash) {
  throw "Q GGUF model hash mismatch."
}
if ([IO.Path]::GetExtension($QModel) -ine ".gguf") {
  throw "Q_MODEL_PATH must reference a GGUF model."
}

Push-Location $RepositoryRoot
try {
  Invoke-Checked python @("-m", "pip", "install", "-e", ".[dev,packaging]")
  Invoke-Checked corepack @("pnpm", "install", "--frozen-lockfile")

  Invoke-Checked python @("-m", "ruff", "check", ".")
  Invoke-Checked python @("-m", "mypy", "apps/backend", "runtimes", "tests")
  Invoke-Checked python @("-m", "pytest", "-q")
  Invoke-Checked corepack @("pnpm", "typecheck")
  Invoke-Checked corepack @("pnpm", "test")
  Invoke-Checked cargo @("fmt", "--all", "--", "--check")
  Invoke-Checked cargo @("clippy", "--workspace", "--all-targets", "--", "-D", "warnings")
  Invoke-Checked cargo @("test", "--workspace")

  foreach ($StagingPath in @($BinaryRoot, (Join-Path $ResourceRoot "config"), (Join-Path $ResourceRoot "schemas"), (Join-Path $ResourceRoot "models"), (Join-Path $ResourceRoot "runtimes"), (Join-Path $ResourceRoot "licenses"), $PyInstallerRoot)) {
    if (Test-Path -LiteralPath $StagingPath) {
      Remove-Item -LiteralPath $StagingPath -Recurse -Force
    }
  }
  New-Item -ItemType Directory -Force -Path $BinaryRoot, (Join-Path $ResourceRoot "config"), (Join-Path $ResourceRoot "schemas"), (Join-Path $ResourceRoot "models"), (Join-Path $ResourceRoot "runtimes\r_worker"), (Join-Path $ResourceRoot "licenses"), (Join-Path $PyInstallerRoot "spec") | Out-Null

  Copy-VerifiedRuntime "llama.cpp" $LlamaDirectory $LlamaManifest (Join-Path $BinaryRoot "llama_cpp") "llama-server.exe"
  Copy-VerifiedRuntime "whisper.cpp" $WhisperDirectory $WhisperManifest (Join-Path $BinaryRoot "whisper_cpp") "whisper-cli.exe"
  Stage-LargeFile $WhisperModel (Join-Path $ResourceRoot "models\ggml-base.bin")
  Stage-LargeFile $QModel (Join-Path $ResourceRoot "models\experimental-q.gguf")
  Copy-Item -Path (Join-Path $RepositoryRoot "config\*") -Destination (Join-Path $ResourceRoot "config") -Recurse -Force
  Copy-Item -Path (Join-Path $RepositoryRoot "schemas\*") -Destination (Join-Path $ResourceRoot "schemas") -Recurse -Force
  Copy-Item -LiteralPath (Join-Path $RepositoryRoot "runtimes\r_worker\worker.R") -Destination (Join-Path $ResourceRoot "runtimes\r_worker\worker.R") -Force
  Copy-Item -LiteralPath (Join-Path $RepositoryRoot "THIRD_PARTY_NOTICES.md") -Destination (Join-Path $ResourceRoot "THIRD_PARTY_NOTICES.md") -Force
  Copy-Item -Path (Join-Path $RepositoryRoot "installer\licenses\*") -Destination (Join-Path $ResourceRoot "licenses") -Force

  Test-NativeRuntimes (Join-Path $BinaryRoot "llama_cpp\llama-server.exe") (Join-Path $ResourceRoot "models\experimental-q.gguf") (Join-Path $BinaryRoot "whisper_cpp\whisper-cli.exe") (Join-Path $ResourceRoot "models\ggml-base.bin")

  $BackendArguments = @(
    "--paths", (Join-Path $RepositoryRoot "apps\backend"),
    "--collect-all", "qdrant_client",
    "--collect-all", "matplotlib",
    "--collect-all", "sklearn",
    "--collect-all", "statsmodels",
    "--collect-all", "reportlab",
    "--collect-all", "dulwich",
    "--hidden-import", "uvicorn.logging",
    "--hidden-import", "uvicorn.loops.auto",
    "--hidden-import", "uvicorn.protocols.http.auto",
    "--hidden-import", "uvicorn.protocols.websockets.auto"
  )
  Build-PythonSidecar "q-backend" (Join-Path $RepositoryRoot "apps\backend\q_backend\main.py") $BackendArguments
  Build-PythonSidecar "q-python-worker" (Join-Path $RepositoryRoot "runtimes\python_worker\main.py")
  Build-PythonSidecar "q-sql-worker" (Join-Path $RepositoryRoot "runtimes\sql_worker\main.py") @("--collect-all", "duckdb")
  Build-PythonSidecar "q-package-worker" (Join-Path $RepositoryRoot "runtimes\package_worker\main.py")
  Build-PythonSidecar "q-audio-worker" (Join-Path $RepositoryRoot "runtimes\audio_worker\main.py")
  Copy-Item -Path (Join-Path $PyInstallerRoot "dist\*.exe") -Destination $BinaryRoot -Force

  Invoke-Checked python @("scripts\verify_packaging.py", "--resource-root", $ResourceRoot)
  Invoke-Checked corepack @("pnpm", "--filter", "@experimental-q/desktop", "tauri", "build", "--bundles", "nsis,msi")

  $Installers = @(
    Get-ChildItem -Path (Join-Path $RepositoryRoot "target\release\bundle\nsis\*.exe") -File
    Get-ChildItem -Path (Join-Path $RepositoryRoot "target\release\bundle\msi\*.msi") -File
  )
  if ($Installers.Count -lt 2) {
    throw "Tauri did not produce both NSIS and MSI installers."
  }

  $Thumbprint = [Environment]::GetEnvironmentVariable("WINDOWS_CERTIFICATE_THUMBPRINT")
  if ($RequireSigning -and [string]::IsNullOrWhiteSpace($Thumbprint)) {
    throw "Signing is required but WINDOWS_CERTIFICATE_THUMBPRINT is missing."
  }
  $Signed = -not [string]::IsNullOrWhiteSpace($Thumbprint)
  if ($Signed) {
    Assert-Command "signtool.exe"
    foreach ($Installer in $Installers) {
      Invoke-Checked signtool.exe @("sign", "/sha1", $Thumbprint, "/fd", "SHA256", $Installer.FullName)
      Invoke-Checked signtool.exe @("verify", "/pa", $Installer.FullName)
    }
  }

  New-Item -ItemType Directory -Force -Path $ReleaseRoot | Out-Null
  $ManifestEntries = @()
  foreach ($Installer in $Installers) {
    $Destination = Join-Path $ReleaseRoot $Installer.Name
    Copy-Item -LiteralPath $Installer.FullName -Destination $Destination -Force
    $ManifestEntries += [ordered]@{
      file = $Installer.Name
      sha256 = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash.ToLowerInvariant()
      size_bytes = (Get-Item -LiteralPath $Destination).Length
      signed = $Signed
    }
  }
  $ReleaseManifest = [ordered]@{
    product = "Experimental Q"
    version = "0.3.0"
    generated_at_utc = [DateTime]::UtcNow.ToString("o")
    windows_minimum_build = 19041
    architecture = "x86_64"
    q_model = [ordered]@{
      file = "resources/models/experimental-q.gguf"
      sha256 = $QModelHash
    }
    whisper_model = [ordered]@{
      file = "resources/models/ggml-base.bin"
      sha256 = $WhisperModelHash
    }
    installers = $ManifestEntries
  }
  $ReleaseManifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $ReleaseRoot "release-manifest.json") -Encoding UTF8
  Write-Host "Verified installers are available in $ReleaseRoot"
}
finally {
  Pop-Location
}
