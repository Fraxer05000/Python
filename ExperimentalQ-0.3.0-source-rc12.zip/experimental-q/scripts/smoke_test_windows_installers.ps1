[CmdletBinding()]
param(
  [string]$ReleaseDirectory = "release"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$RepositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ReleaseRoot = (Resolve-Path (Join-Path $RepositoryRoot $ReleaseDirectory)).Path
$ManifestPath = Join-Path $ReleaseRoot "release-manifest.json"
$SmokeRoot = Join-Path $env:RUNNER_TEMP "experimental-q-installer-smoke"
$NsisRoot = Join-Path $SmokeRoot "nsis-install"
$MsiRoot = Join-Path $SmokeRoot "msi-install"
$Workspace = Join-Path $SmokeRoot "user-workspace"

function Invoke-ProcessWithTimeout {
  param(
    [Parameter(Mandatory)][string]$FilePath,
    [Parameter(Mandatory)][string[]]$Arguments,
    [int]$TimeoutSeconds = 300,
    [int[]]$AllowedExitCodes = @(0)
  )
  $Process = Start-Process -FilePath $FilePath -ArgumentList $Arguments -PassThru
  if (-not $Process.WaitForExit($TimeoutSeconds * 1000)) {
    $Process.Kill($true)
    $Process.WaitForExit()
    throw "Process timed out: $FilePath"
  }
  if ($Process.ExitCode -notin $AllowedExitCodes) {
    throw "Process failed ($($Process.ExitCode)): $FilePath"
  }
}

function Assert-NoExperimentalQAutostart {
  foreach ($Key in @(
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
  )) {
    if (-not (Test-Path -LiteralPath $Key)) {
      continue
    }
    $Values = (Get-ItemProperty -LiteralPath $Key).PSObject.Properties |
      Where-Object { $_.Name -notmatch "^PS" } |
      ForEach-Object { "$($_.Name)=$($_.Value)" }
    if (($Values -join "`n") -match "(?i)experimental[ -]?q") {
      throw "Installer created a forbidden Windows startup registry value."
    }
  }
  $StartupFolders = @(
    [Environment]::GetFolderPath("Startup"),
    [Environment]::GetFolderPath("CommonStartup")
  ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and (Test-Path -LiteralPath $_) }
  foreach ($Folder in $StartupFolders) {
    if (Get-ChildItem -LiteralPath $Folder -File | Where-Object { $_.Name -match "(?i)experimental[ -]?q" }) {
      throw "Installer created a forbidden Windows Startup-folder entry."
    }
  }
}

function Get-ExperimentalQUninstallEntries {
  param([Parameter(Mandatory)][string[]]$RegistryRoots)
  $Entries = @()
  foreach ($Root in $RegistryRoots) {
    if (-not (Test-Path -LiteralPath $Root)) {
      continue
    }
    $Entries += @(Get-ChildItem -LiteralPath $Root -ErrorAction SilentlyContinue |
      ForEach-Object {
        $Entry = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
        if ($null -ne $Entry) {
          $DisplayName = $Entry.PSObject.Properties["DisplayName"]
          if ($null -ne $DisplayName -and [string]$DisplayName.Value -like "Experimental Q*") {
            $Entry
          }
        }
      })
  }
  return @($Entries)
}

function Assert-PerMachineInstallerRegistration {
  $MachineEntries = Get-ExperimentalQUninstallEntries @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
  )
  if ($MachineEntries.Count -lt 1) {
    throw "Installer did not create an Experimental Q per-machine uninstall registration."
  }
  $UserEntries = Get-ExperimentalQUninstallEntries @(
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall"
  )
  if ($UserEntries.Count -gt 0) {
    throw "Installer unexpectedly registered Experimental Q as a current-user application."
  }
}

function Assert-NoInstallerRegistration {
  $Entries = Get-ExperimentalQUninstallEntries @(
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
  )
  if ($Entries.Count -gt 0) {
    throw "Experimental Q uninstall registration remained after uninstall."
  }
}

function Get-InstalledApplication {
  param([Parameter(Mandatory)][string]$Root)
  if (-not (Test-Path -LiteralPath $Root -PathType Container)) {
    throw "Experimental Q install root does not exist: $Root"
  }
  # Tauri keeps the Cargo binary name on disk while using productName for
  # installer/UI labels.
  $Application = Get-ChildItem -LiteralPath $Root -Recurse -File -Filter "experimental-q-desktop.exe" |
    Select-Object -First 1
  if ($null -eq $Application) {
    $Observed = @(Get-ChildItem -LiteralPath $Root -Recurse -File -ErrorAction SilentlyContinue |
      Select-Object -First 30 -ExpandProperty FullName)
    throw "Installed Experimental Q desktop executable was not found under $Root. Observed: $($Observed -join ', ')"
  }
  return $Application
}

function Get-RegisteredInstallRoot {
  $RegistryKeys = @(
    "HKCU:\Software\Experimental Q\Experimental Q",
    "HKLM:\Software\Experimental Q\Experimental Q",
    "HKLM:\Software\WOW6432Node\Experimental Q\Experimental Q"
  )
  foreach ($Key in $RegistryKeys) {
    if (-not (Test-Path -LiteralPath $Key)) {
      continue
    }
    $InstallDir = Get-ItemPropertyValue -LiteralPath $Key -Name "InstallDir" -ErrorAction SilentlyContinue
    if (-not [string]::IsNullOrWhiteSpace([string]$InstallDir) -and
        (Test-Path -LiteralPath ([string]$InstallDir) -PathType Container)) {
      return [IO.Path]::GetFullPath([string]$InstallDir)
    }
  }
  throw "Windows Installer did not register an Experimental Q install root."
}

function Assert-InstalledLayout {
  param([Parameter(Mandatory)][string]$Root)
  $Application = Get-InstalledApplication $Root
  $ApplicationRoot = $Application.DirectoryName
  $Required = @(
    "resources\bin\q-backend.exe",
    "resources\bin\q-python-worker.exe",
    "resources\bin\q-sql-worker.exe",
    "resources\bin\q-package-worker.exe",
    "resources\bin\q-audio-worker.exe",
    "resources\bin\llama_cpp\llama-server.exe",
    "resources\bin\whisper_cpp\whisper-cli.exe",
    "resources\models\experimental-q.gguf",
    "resources\models\ggml-base.bin",
    "resources\config\tool_registry.json",
    "resources\config\permission_policy.yaml",
    "resources\THIRD_PARTY_NOTICES.md",
    "resources\licenses\Apache-2.0.txt",
    "resources\licenses\MIT-ggml-runtimes.txt"
  )
  $Missing = @($Required | Where-Object { -not (Test-Path -LiteralPath (Join-Path $ApplicationRoot $_) -PathType Leaf) })
  if ($Missing.Count -gt 0) {
    throw "Installed layout is incomplete: $($Missing -join ', ')"
  }
  return $Application
}

function Test-ApplicationStartsOff {
  param([Parameter(Mandatory)][IO.FileInfo]$Application)
  if (Get-Process -Name "llama-server" -ErrorAction SilentlyContinue) {
    throw "A llama-server process existed before the launch smoke test."
  }
  $PreviousWorkspace = $env:Q_WORKSPACE
  $env:Q_WORKSPACE = $Workspace
  try {
    $Process = Start-Process -FilePath $Application.FullName -PassThru
    Start-Sleep -Seconds 15
    if ($Process.HasExited) {
      throw "Installed desktop exited during its launch smoke test with $($Process.ExitCode)."
    }
    if (-not (Get-Process -Name "q-backend" -ErrorAction SilentlyContinue)) {
      throw "Installed desktop did not start its packaged backend sidecar."
    }
    if (Get-Process -Name "llama-server" -ErrorAction SilentlyContinue) {
      throw "Installed desktop auto-started Q; launch must remain OFF."
    }
    $null = $Process.CloseMainWindow()
    if (-not $Process.WaitForExit(15000)) {
      $Process.Kill($true)
      $Process.WaitForExit()
    }
    Start-Sleep -Seconds 3
    $Orphans = @(Get-Process -Name "q-backend", "q-python-worker", "q-sql-worker", "q-package-worker", "q-audio-worker", "llama-server" -ErrorAction SilentlyContinue)
    if ($Orphans.Count -gt 0) {
      $Details = $Orphans | ForEach-Object { "$($_.ProcessName):$($_.Id)" }
      throw "Installed desktop left an orphan Experimental Q process: $($Details -join ', ')."
    }
  }
  finally {
    $env:Q_WORKSPACE = $PreviousWorkspace
  }
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
  throw "Windows installers can only be smoke-tested on Windows."
}
if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
  throw "release-manifest.json is missing."
}
if (Test-Path -LiteralPath $SmokeRoot) {
  Remove-Item -LiteralPath $SmokeRoot -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $SmokeRoot, $Workspace | Out-Null
Set-Content -LiteralPath (Join-Path $Workspace "preserve-on-uninstall.txt") -Value "user-data" -Encoding UTF8
Assert-NoExperimentalQAutostart

$Manifest = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($Manifest.version -ne "0.3.0" -or
    $Manifest.architecture -ne "x86_64" -or
    $Manifest.install_scope -ne "per_machine" -or
    -not [bool]$Manifest.requires_administrator -or
    [bool]$Manifest.runtime_requires_administrator) {
  throw "Release manifest version, architecture, or privilege boundary is invalid."
}
foreach ($Entry in $Manifest.installers) {
  $Installer = Join-Path $ReleaseRoot ([string]$Entry.file)
  if (-not (Test-Path -LiteralPath $Installer -PathType Leaf)) {
    throw "Manifest installer is missing: $($Entry.file)"
  }
  $ActualHash = (Get-FileHash -LiteralPath $Installer -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($ActualHash -cne ([string]$Entry.sha256)) {
    throw "Installer hash mismatch: $($Entry.file)"
  }
  if ([bool]$Entry.signed -and (Get-AuthenticodeSignature -LiteralPath $Installer).Status -ne "Valid") {
    throw "Installer was declared signed but Authenticode validation failed."
  }
}

$Nsis = Get-ChildItem -LiteralPath $ReleaseRoot -File -Filter "*.exe" | Select-Object -First 1
$Msi = Get-ChildItem -LiteralPath $ReleaseRoot -File -Filter "*.msi" | Select-Object -First 1
if ($null -eq $Nsis -or $null -eq $Msi) {
  throw "Both NSIS and MSI installers are required."
}

Invoke-ProcessWithTimeout $Nsis.FullName @("/S", "/D=$NsisRoot") 600
$NsisApplication = Assert-InstalledLayout $NsisRoot
Assert-PerMachineInstallerRegistration
Assert-NoExperimentalQAutostart
Test-ApplicationStartsOff $NsisApplication
$Uninstaller = Get-ChildItem -LiteralPath $NsisRoot -Recurse -File -Filter "uninstall.exe" | Select-Object -First 1
if ($null -eq $Uninstaller) {
  throw "NSIS uninstaller is missing."
}
Invoke-ProcessWithTimeout $Uninstaller.FullName @("/S") 300
Assert-NoInstallerRegistration
if (-not (Test-Path -LiteralPath (Join-Path $Workspace "preserve-on-uninstall.txt") -PathType Leaf)) {
  throw "NSIS uninstall removed user workspace data."
}
Assert-NoExperimentalQAutostart

$MsiLog = Join-Path $SmokeRoot "msi-install.log"
Invoke-ProcessWithTimeout "msiexec.exe" @(
  "/i", "`"$($Msi.FullName)`"", "/qn", "/norestart", "INSTALLDIR=`"$MsiRoot`"", "/l*v", "`"$MsiLog`""
) 600 @(0, 3010)
$EffectiveMsiRoot = Get-RegisteredInstallRoot
$MsiApplication = Assert-InstalledLayout $EffectiveMsiRoot
Assert-PerMachineInstallerRegistration
Assert-NoExperimentalQAutostart
Test-ApplicationStartsOff $MsiApplication
Invoke-ProcessWithTimeout "msiexec.exe" @(
  "/x", "`"$($Msi.FullName)`"", "/qn", "/norestart"
) 600 @(0, 3010)
if (Test-Path -LiteralPath $MsiApplication.FullName -PathType Leaf) {
  throw "MSI uninstall left the Experimental Q desktop executable installed."
}
Assert-NoInstallerRegistration
if (-not (Test-Path -LiteralPath (Join-Path $Workspace "preserve-on-uninstall.txt") -PathType Leaf)) {
  throw "MSI uninstall removed user workspace data."
}
Assert-NoExperimentalQAutostart

[ordered]@{
  status = "ok"
  tested_at_utc = [DateTime]::UtcNow.ToString("o")
  windows_version = [Environment]::OSVersion.VersionString
  windows_build = [Environment]::OSVersion.Version.Build
  process_architecture = [Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString()
  privilege_boundary = [ordered]@{
    installer_scope = "per_machine"
    installer_requires_administrator = $true
    runtime_requires_administrator = $false
  }
  nsis = [ordered]@{ install = "ok"; uac_scope = "per_machine"; launch_q_state = "OFF"; uninstall = "ok" }
  msi = [ordered]@{ install = "ok"; uac_scope = "per_machine"; layout = "ok"; launch_q_state = "OFF"; uninstall = "ok" }
  autostart = "absent"
  workspace_preserved = $true
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $ReleaseRoot "windows-smoke-report.json") -Encoding UTF8

Write-Host "NSIS and MSI installation smoke tests passed on $([Environment]::OSVersion.VersionString)."
