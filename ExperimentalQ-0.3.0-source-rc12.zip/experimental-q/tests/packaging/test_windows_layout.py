from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_windows_packaging_configuration_smoke() -> None:
    result = subprocess.run(  # noqa: S603 - fixed repository validation entry point
        [sys.executable, str(ROOT / "scripts" / "verify_packaging.py")],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
        timeout=10,
    )
    assert result.returncode == 0, result.stderr
    assert '"status": "ok"' in result.stdout
    assert "workflow_action_pins" in result.stdout
    assert "installer_smoke_gate" in result.stdout
    assert "q_model_hash" in result.stdout
    assert "uac_machine_install" in result.stdout


def test_native_model_smoke_is_bounded_and_uses_supported_tool_choice() -> None:
    script = (ROOT / "scripts" / "build_windows.ps1").read_text(encoding="utf-8")
    assert '"--parallel", "1"' in script
    assert 'tool_choice = "required"' in script
    assert "-TimeoutSec 600" in script
    assert "$CanonicalNames" in script


def test_installer_smoke_uses_the_tauri_binary_name() -> None:
    script = (ROOT / "scripts" / "smoke_test_windows_installers.ps1").read_text(
        encoding="utf-8"
    )
    assert 'Filter "experimental-q-desktop.exe"' in script
    assert "Get-RegisteredInstallRoot" in script
    assert "$EffectiveMsiRoot = Get-RegisteredInstallRoot" in script
    assert "Test-ApplicationStartsOff $MsiApplication" in script
    assert "MSI uninstall left the Experimental Q desktop executable installed" in script
    assert "Assert-PerMachineInstallerRegistration" in script
    assert "Assert-NoInstallerRegistration" in script
    assert '$Entry.PSObject.Properties["DisplayName"]' in script


def test_installer_elevation_is_limited_to_packaging() -> None:
    tauri = (
        ROOT / "apps" / "desktop" / "src-tauri" / "tauri.conf.json"
    ).read_text(encoding="utf-8")
    build = (ROOT / "scripts" / "build_windows.ps1").read_text(encoding="utf-8")
    assert '"installMode": "perMachine"' in tauri
    assert 'requires_administrator = $true' in build
    assert 'runtime_requires_administrator = $false' in build


def test_windows_supervisor_owns_complete_process_trees() -> None:
    cargo = (ROOT / "apps" / "desktop" / "src-tauri" / "Cargo.toml").read_text(
        encoding="utf-8"
    )
    managed_process = (
        ROOT / "apps" / "desktop" / "src-tauri" / "src" / "managed_process.rs"
    ).read_text(encoding="utf-8")
    assert 'process-wrap = { version = "=9.1.0"' in cargo
    assert 'win32job = "=2.0.3"' in cargo
    assert ".wrap(JobObject)" in managed_process
    assert "limit_kill_on_job_close" in managed_process
    assert ".wrap(KillOnSupervisorExit::default())" in managed_process
    assert ".wrap(JobObject)" in managed_process
    assert "terminate_and_wait" in managed_process
    assert "windows_job_terminates_descendants" in managed_process
