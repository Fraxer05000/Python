from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_windows_packaging_configuration_smoke() -> None:
    result = subprocess.run(  # noqa: S603 - fixed repository validation entry point
        [sys.executable, str(ROOT / "scripts" / "verify_packaging.py")],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
        timeout=10,
    )
    assert result.returncode == 0, result.stderr
    assert '"status": "ok"' in result.stdout
    assert "workflow_action_pins" in result.stdout
    assert "installer_smoke_gate" in result.stdout
    assert "q_model_hash" in result.stdout


def test_native_model_smoke_is_bounded_and_uses_supported_tool_choice() -> None:
    script = (ROOT / "scripts" / "build_windows.ps1").read_text(encoding="utf-8")
    assert '"--parallel", "1"' in script
    assert 'tool_choice = "required"' in script
    assert "-TimeoutSec 600" in script
    assert "$CanonicalNames" in script


def test_installer_smoke_uses_the_tauri_binary_name() -> None:
    script = (ROOT / "scripts" / "smoke_test_windows_installers.ps1").read_text(
        encoding="utf-8"
    )
    assert 'Filter "experimental-q-desktop.exe"' in script
