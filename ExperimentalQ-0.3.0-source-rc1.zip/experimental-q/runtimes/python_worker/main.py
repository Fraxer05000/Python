"""Fixed restricted Python worker. Input and output are bounded JSON on stdio."""

from __future__ import annotations

import ast
import contextlib
import io
import json
import os
import sys
from typing import Any

_MAX_INPUT = 1_048_576
_MAX_OUTPUT = 1_048_576
_DENIED_NAMES = {
    "__import__",
    "breakpoint",
    "compile",
    "eval",
    "exec",
    "globals",
    "help",
    "input",
    "locals",
    "open",
    "vars",
}
_SAFE_BUILTINS: dict[str, object] = {
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "dict": dict,
    "enumerate": enumerate,
    "float": float,
    "int": int,
    "len": len,
    "list": list,
    "max": max,
    "min": min,
    "print": print,
    "range": range,
    "reversed": reversed,
    "round": round,
    "set": set,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "tuple": tuple,
    "zip": zip,
}


class SafetyVisitor(ast.NodeVisitor):
    def visit_Import(self, node: ast.Import) -> None:
        raise ValueError(f"Imports are disabled at line {node.lineno}.")

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        raise ValueError(f"Imports are disabled at line {node.lineno}.")

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr.startswith("_"):
            raise ValueError(f"Private attributes are disabled at line {node.lineno}.")
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name) -> None:
        if node.id.startswith("_") or node.id in _DENIED_NAMES:
            raise ValueError(f"Name '{node.id}' is disabled at line {node.lineno}.")
        self.generic_visit(node)


def _limits() -> None:
    try:
        import resource

        memory = int(os.environ.get("Q_WORKER_MEMORY_BYTES", str(512 * 1024 * 1024)))
        cpu = int(os.environ.get("Q_WORKER_CPU_SECONDS", "120"))
        resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))
        resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
    except (ImportError, OSError, ValueError):
        return


def main() -> int:
    _limits()
    raw = sys.stdin.buffer.read(_MAX_INPUT + 1)
    if len(raw) > _MAX_INPUT:
        return _emit({"status": "error", "error": "input_too_large"})
    try:
        request = json.loads(raw)
        code = request["code"]
        if not isinstance(code, str):
            raise ValueError("code must be a string")
        tree = ast.parse(code, mode="exec")
        SafetyVisitor().visit(tree)
        output = io.StringIO()
        globals_map: dict[str, Any] = {"__builtins__": _SAFE_BUILTINS}
        with contextlib.redirect_stdout(output):
            exec(compile(tree, "<q-sandbox>", "exec"), globals_map, globals_map)  # noqa: S102
        result = globals_map.get("result")
        response = {
            "status": "ok",
            "stdout": output.getvalue()[:_MAX_OUTPUT],
            "result": result,
        }
        json.dumps(response)
        return _emit(response)
    except (SyntaxError, ValueError, TypeError, KeyError) as exc:
        return _emit({"status": "error", "error": str(exc)[:4000]})
    except Exception as exc:  # noqa: BLE001 - worker boundary normalizes all failures
        return _emit({"status": "error", "error": type(exc).__name__})


def _emit(value: dict[str, object]) -> int:
    encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    sys.stdout.write(encoded[:_MAX_OUTPUT])
    sys.stdout.flush()
    return 0 if value.get("status") == "ok" else 2


if __name__ == "__main__":
    raise SystemExit(main())
