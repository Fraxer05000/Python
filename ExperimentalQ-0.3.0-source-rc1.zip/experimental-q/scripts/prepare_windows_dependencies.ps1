[CmdletBinding()]
param(
  [string]$OutputDirectory = "vendor",
  [string]$LockFile = "installer/runtime-sources.lock.json"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$RepositoryRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$RepositoryPrefix = $RepositoryRoot.TrimEnd("\") + "\"
$LockPath = [IO.Path]::GetFullPath((Join-Path $RepositoryRoot $LockFile))
$OutputRoot = [IO.Path]::GetFullPath((Join-Path $RepositoryRoot $OutputDirectory))
$BuildRoot = Join-Path $RepositoryRoot "build\native-dependencies"

function Assert-Command {
  param([Parameter(Mandatory)][string]$Name)
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    throw "Required dependency command is unavailable: $Name"
  }
}

function Invoke-Checked {
  param(
    [Parameter(Mandatory)][string]$Command,
    [Parameter(ValueFromRemainingArguments)][string[]]$Arguments
  )
  & $Command @Arguments
  if ($LASTEXITCODE -ne 0) {
    throw "Command failed ($LASTEXITCODE): $Command $($Arguments -join ' ')"
  }
}

function Assert-PinnedSource {
  param(
    [Parameter(Mandatory)][string]$Url,
    [Parameter(Mandatory)][string]$Commit
  )
  $Allowed = @(
    "https://github.com/ggml-org/llama.cpp.git",
    "https://github.com/ggml-org/whisper.cpp.git"
  )
  if ($Url -cnotin $Allowed) {
    throw "Native runtime source is not on the reviewed allowlist: $Url"
  }
  if ($Commit -notmatch "^[0-9a-f]{40}$") {
    throw "Native runtime source lacks a full pinned commit SHA."
  }
}

function Assert-PinnedDownload {
  param(
    [Parameter(Mandatory)][string]$Url,
    [Parameter(Mandatory)][string]$ExpectedHash
  )
  $Uri = [Uri]$Url
  if ($Uri.Scheme -ne "https" -or $Uri.Host -ne "huggingface.co") {
    throw "Model source must be an approved Hugging Face HTTPS URL."
  }
  if ($ExpectedHash -notmatch "^[0-9a-f]{64}$") {
    throw "Model source lacks a pinned SHA-256 digest."
  }
}

function Get-PeMachine {
  param([Parameter(Mandatory)][string]$Path)
  $Stream = [IO.File]::OpenRead($Path)
  $Reader = [IO.BinaryReader]::new($Stream)
  try {
    if ($Reader.ReadUInt16() -ne 0x5A4D) {
      throw "Native runtime file is not a PE executable: $Path"
    }
    $Stream.Position = 0x3C
    $HeaderOffset = $Reader.ReadUInt32()
    $Stream.Position = $HeaderOffset
    if ($Reader.ReadUInt32() -ne 0x00004550) {
      throw "Native runtime file has an invalid PE header: $Path"
    }
    return $Reader.ReadUInt16()
  }
  finally {
    $Reader.Dispose()
    $Stream.Dispose()
  }
}

function Checkout-PinnedSource {
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][string]$Repository,
    [Parameter(Mandatory)][string]$Commit,
    [Parameter(Mandatory)][string]$Destination
  )
  Assert-PinnedSource $Repository $Commit
  New-Item -ItemType Directory -Force -Path $Destination | Out-Null
  Invoke-Checked git @("-C", $Destination, "init", "--quiet")
  Invoke-Checked git @("-C", $Destination, "remote", "add", "origin", $Repository)
  Invoke-Checked git @("-C", $Destination, "fetch", "--quiet", "--depth", "1", "origin", $Commit)
  Invoke-Checked git @("-C", $Destination, "checkout", "--quiet", "--detach", "FETCH_HEAD")
  $Head = (& git -C $Destination rev-parse HEAD).Trim()
  if ($LASTEXITCODE -ne 0 -or $Head -cne $Commit) {
    throw "$Name source checkout does not match its pinned commit."
  }
}

function Build-NativeRuntime {
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][object]$Definition,
    [Parameter(Mandatory)][string]$CMakePrefix,
    [Parameter(Mandatory)][string]$Destination
  )
  $Source = Join-Path $BuildRoot "$Name\source"
  $Build = Join-Path $BuildRoot "$Name\build"
  Checkout-PinnedSource $Name ([string]$Definition.source_repository) ([string]$Definition.commit_sha) $Source
  $Options = @(
    "-S", $Source,
    "-B", $Build,
    "-A", "x64",
    "-DBUILD_SHARED_LIBS=ON",
    "-DGGML_NATIVE=OFF",
    "-DGGML_AVX=OFF",
    "-DGGML_AVX2=OFF",
    "-DGGML_FMA=OFF",
    "-DGGML_F16C=OFF",
    "-DGGML_OPENMP=OFF"
  ) + $CMakePrefix.Split(" ", [StringSplitOptions]::RemoveEmptyEntries)
  Invoke-Checked cmake $Options
  Invoke-Checked cmake @("--build", $Build, "--config", "Release", "--target", ([string]$Definition.build_target), "--parallel", "2")

  $Executable = Get-ChildItem -LiteralPath $Build -Recurse -File -Filter ([string]$Definition.required_executable) |
    Where-Object { $_.FullName -match "[\\/]Release[\\/]" } |
    Select-Object -First 1
  if ($null -eq $Executable) {
    throw "$Name did not produce $($Definition.required_executable)."
  }
  New-Item -ItemType Directory -Force -Path $Destination | Out-Null
  Copy-Item -LiteralPath $Executable.FullName -Destination (Join-Path $Destination $Executable.Name) -Force
  $Dlls = Get-ChildItem -LiteralPath $Executable.DirectoryName -File -Filter "*.dll"
  foreach ($Dll in $Dlls) {
    Copy-Item -LiteralPath $Dll.FullName -Destination (Join-Path $Destination $Dll.Name) -Force
  }
  $Files = Get-ChildItem -LiteralPath $Destination -File
  if (-not ($Files.Name -contains ([string]$Definition.required_executable))) {
    throw "$Name staged runtime lacks its required executable."
  }
  foreach ($File in $Files) {
    if ((Get-PeMachine $File.FullName) -ne 0x8664) {
      throw "$Name produced a non-x64 PE file: $($File.Name)"
    }
  }
  return @($Files | Sort-Object Name | ForEach-Object {
    [ordered]@{
      path = $_.Name
      sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    }
  })
}

function Save-RuntimeManifest {
  param(
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][object[]]$Files,
    [Parameter(Mandatory)][string]$Path
  )
  [ordered]@{
    format_version = 1
    runtime = $Name
    target = "windows-x86_64"
    files = $Files
  } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Get-VerifiedModel {
  param(
    [Parameter(Mandatory)][object]$Definition,
    [Parameter(Mandatory)][string]$Destination
  )
  $Url = [string]$Definition.source_url
  $ExpectedHash = [string]$Definition.sha256
  Assert-PinnedDownload $Url $ExpectedHash
  Invoke-Checked curl.exe @("--location", "--fail", "--retry", "3", "--retry-delay", "5", "--output", $Destination, $Url)
  $ActualHash = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($ActualHash -cne $ExpectedHash) {
    throw "Downloaded model hash mismatch for $($Definition.installed_name)."
  }
}

foreach ($Command in @("git", "cmake", "curl.exe")) {
  Assert-Command $Command
}
if (-not $LockPath.StartsWith($RepositoryPrefix, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $LockPath -PathType Leaf)) {
  throw "Runtime lock must be an existing file inside the repository."
}
if (-not $OutputRoot.StartsWith($RepositoryPrefix, [StringComparison]::OrdinalIgnoreCase) -or $OutputRoot -eq $RepositoryRoot) {
  throw "Dependency output must be a dedicated directory inside the repository."
}
if (Test-Path -LiteralPath $BuildRoot) {
  Remove-Item -LiteralPath $BuildRoot -Recurse -Force
}
if (Test-Path -LiteralPath $OutputRoot) {
  Remove-Item -LiteralPath $OutputRoot -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $BuildRoot, $OutputRoot | Out-Null

$Lock = Get-Content -LiteralPath $LockPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($Lock.format_version -ne 1 -or $Lock.target -ne "windows-x86_64") {
  throw "Unsupported runtime source lock."
}

$LlamaFiles = Build-NativeRuntime "llama_cpp" $Lock.native_runtimes.llama_cpp "-DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_BUILD_SERVER=ON -DLLAMA_CURL=OFF" (Join-Path $OutputRoot "llama")
Save-RuntimeManifest "llama.cpp" $LlamaFiles (Join-Path $OutputRoot "llama-manifest.json")
$WhisperFiles = Build-NativeRuntime "whisper_cpp" $Lock.native_runtimes.whisper_cpp "-DWHISPER_BUILD_TESTS=OFF -DWHISPER_BUILD_EXAMPLES=ON" (Join-Path $OutputRoot "whisper")
Save-RuntimeManifest "whisper.cpp" $WhisperFiles (Join-Path $OutputRoot "whisper-manifest.json")

Get-VerifiedModel $Lock.models.q (Join-Path $OutputRoot ([string]$Lock.models.q.installed_name))
Get-VerifiedModel $Lock.models.whisper (Join-Path $OutputRoot ([string]$Lock.models.whisper.installed_name))
Copy-Item -LiteralPath $LockPath -Destination (Join-Path $OutputRoot "runtime-sources.lock.json") -Force

[ordered]@{
  format_version = 1
  generated_at_utc = [DateTime]::UtcNow.ToString("o")
  target = "windows-x86_64"
  llama_cpp_commit = [string]$Lock.native_runtimes.llama_cpp.commit_sha
  whisper_cpp_commit = [string]$Lock.native_runtimes.whisper_cpp.commit_sha
  q_model_sha256 = [string]$Lock.models.q.sha256
  whisper_model_sha256 = [string]$Lock.models.whisper.sha256
} | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $OutputRoot "dependency-provenance.json") -Encoding UTF8

Remove-Item -LiteralPath $BuildRoot -Recurse -Force
Write-Host "Pinned Windows dependencies are available in $OutputRoot"
