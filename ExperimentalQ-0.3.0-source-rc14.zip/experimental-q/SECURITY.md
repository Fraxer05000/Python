# Security policy

Experimental Q treats all model output as untrusted data. A report is
security-sensitive when it indicates a way to bypass tool registration,
argument validation, policy evaluation, confirmation, path isolation, local
authentication, secret redaction, audit creation, or model unloading.

Do not include real credentials or private datasets in a report. Preserve logs
locally and redact document contents. There is no telemetry or automatic crash
upload in this release.

The project does not support silent self-update and does not enable Windows
startup.
