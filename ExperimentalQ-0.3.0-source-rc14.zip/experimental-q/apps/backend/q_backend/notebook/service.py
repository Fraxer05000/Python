"""Notebook persistence and execution through the mandatory orchestration boundary."""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import func, select

from q_backend.errors import QError, QErrorCode
from q_backend.models.chat import ChatTurnRequest
from q_backend.models.notebook import (
    CellCreate,
    CellExecuteRequest,
    CellExecutionResult,
    CellType,
    CellUpdate,
    Notebook,
    NotebookCell,
    NotebookCreate,
)
from q_backend.models.permissions import ApplicationMode, InvocationIdentity
from q_backend.models.tool import ToolRequest
from q_backend.orchestrator.service import ChatOrchestrator
from q_backend.projects.service import ProjectService
from q_backend.storage.database import Database, NotebookCellRow, NotebookRow
from q_backend.tools.manager import ToolManager


class NotebookService:
    def __init__(
        self,
        database: Database,
        projects: ProjectService,
        tools: ToolManager,
        chat: ChatOrchestrator,
    ) -> None:
        self._database = database
        self._projects = projects
        self._tools = tools
        self._chat = chat

    async def create(self, request: NotebookCreate) -> Notebook:
        await self._projects.get(request.project_id)
        return await asyncio.to_thread(self._create_sync, request)

    def _create_sync(self, request: NotebookCreate) -> Notebook:
        now = datetime.now(UTC).isoformat()
        row = NotebookRow(
            notebook_id=str(uuid4()),
            project_id=str(request.project_id),
            title=request.title,
            created_at_utc=now,
            updated_at_utc=now,
            deleted=False,
        )
        with self._database.session() as session:
            session.add(row)
        return _notebook(row, [])

    async def list_notebooks(self, project_id: UUID) -> list[Notebook]:
        await self._projects.get(project_id)
        return await asyncio.to_thread(self._list_sync, str(project_id))

    def _list_sync(self, project_id: str) -> list[Notebook]:
        with self._database.session() as session:
            rows = session.scalars(
                select(NotebookRow)
                .where(NotebookRow.project_id == project_id, NotebookRow.deleted.is_(False))
                .order_by(NotebookRow.updated_at_utc.desc())
            ).all()
            return [_notebook(row, []) for row in rows]

    async def get(self, notebook_id: UUID) -> Notebook:
        return await asyncio.to_thread(self._get_sync, str(notebook_id))

    def _get_sync(self, notebook_id: str) -> Notebook:
        with self._database.session() as session:
            notebook = session.get(NotebookRow, notebook_id)
            if notebook is None or notebook.deleted:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Notebook not found.")
            cells = session.scalars(
                select(NotebookCellRow)
                .where(NotebookCellRow.notebook_id == notebook_id)
                .order_by(NotebookCellRow.position.asc())
            ).all()
            return _notebook(notebook, [_cell(row) for row in cells])

    async def add_cell(self, notebook_id: UUID, request: CellCreate) -> NotebookCell:
        return await asyncio.to_thread(self._add_cell_sync, str(notebook_id), request)

    def _add_cell_sync(self, notebook_id: str, request: CellCreate) -> NotebookCell:
        now = datetime.now(UTC).isoformat()
        with self._database.session() as session:
            notebook = session.get(NotebookRow, notebook_id)
            if notebook is None or notebook.deleted:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Notebook not found.")
            maximum = session.scalar(
                select(func.max(NotebookCellRow.position)).where(
                    NotebookCellRow.notebook_id == notebook_id
                )
            )
            row = NotebookCellRow(
                cell_id=str(uuid4()),
                notebook_id=notebook_id,
                position=int(maximum or -1) + 1,
                cell_type=request.cell_type.value,
                content=request.content,
                output_json=None,
                created_at_utc=now,
                updated_at_utc=now,
            )
            notebook.updated_at_utc = now
            session.add(row)
            session.flush()
            return _cell(row)

    async def update_cell(self, cell_id: UUID, request: CellUpdate) -> NotebookCell:
        return await asyncio.to_thread(self._update_cell_sync, str(cell_id), request)

    def _update_cell_sync(self, cell_id: str, request: CellUpdate) -> NotebookCell:
        with self._database.session() as session:
            row = session.get(NotebookCellRow, cell_id)
            if row is None:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Notebook cell not found.")
            if request.content is not None:
                row.content = request.content
                row.output_json = None
            if request.position is not None:
                row.position = request.position
            row.updated_at_utc = datetime.now(UTC).isoformat()
            session.flush()
            return _cell(row)

    async def execute(
        self,
        cell_id: UUID,
        request: CellExecuteRequest,
    ) -> CellExecutionResult:
        cell, project_id = await asyncio.to_thread(self._execution_input_sync, str(cell_id))
        if cell.cell_type is CellType.MARKDOWN:
            output: dict[str, Any] = {"rendered": cell.content}
            status = "ok"
        elif cell.cell_type is CellType.PROMPT:
            response = await self._chat.turn(
                ChatTurnRequest(
                    session_id=request.session_id,
                    project_id=UUID(project_id),
                    message=cell.content,
                )
            )
            output = response.model_dump(mode="json")
            status = response.status.value
        else:
            tool_request = _tool_request(cell, UUID(project_id))
            try:
                mode = ApplicationMode(request.mode)
            except ValueError as exc:
                raise QError(QErrorCode.VALIDATION_ERROR, "Notebook mode is invalid.") from exc
            identity = InvocationIdentity(
                session_id=str(request.session_id),
                project_id=project_id,
                mode=mode,
            )
            result = await self._tools.invoke(tool_request, identity)
            output = result.model_dump(mode="json")
            status = result.status.value
        await asyncio.to_thread(self._store_output_sync, str(cell_id), output)
        return CellExecutionResult(cell_id=cell_id, status=status, output=output)

    async def validate_pending_confirmation(
        self,
        cell_id: UUID,
        challenge_id: str,
    ) -> tuple[CellType, UUID]:
        """Bind a one-time permission challenge to the cell that created it."""
        cell, _ = await asyncio.to_thread(self._execution_input_sync, str(cell_id))
        output = cell.output
        if output is None:
            raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Notebook confirmation not found.")
        pending: object
        if cell.cell_type is CellType.PROMPT:
            pending = output.get("pending_tool_result")
        else:
            pending = output
        if not isinstance(pending, dict):
            raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Notebook confirmation not found.")
        challenge = pending.get("data")
        request_id = pending.get("request_id")
        if (
            pending.get("status") != "confirmation_required"
            or not isinstance(challenge, dict)
            or challenge.get("challenge_id") != challenge_id
            or not isinstance(request_id, str)
        ):
            raise QError(
                QErrorCode.PERMISSION_DENIED,
                "The confirmation does not belong to this notebook cell.",
            )
        try:
            parsed_request_id = UUID(request_id)
        except ValueError as exc:
            raise QError(
                QErrorCode.INTERNAL_ERROR,
                "Stored request identifier is invalid.",
            ) from exc
        return cell.cell_type, parsed_request_id

    async def complete_confirmation(
        self,
        cell_id: UUID,
        *,
        status: str,
        output: dict[str, Any],
    ) -> CellExecutionResult:
        await asyncio.to_thread(self._store_output_sync, str(cell_id), output)
        return CellExecutionResult(cell_id=cell_id, status=status, output=output)

    def _execution_input_sync(self, cell_id: str) -> tuple[NotebookCell, str]:
        with self._database.session() as session:
            row = session.get(NotebookCellRow, cell_id)
            if row is None:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Notebook cell not found.")
            notebook = session.get(NotebookRow, row.notebook_id)
            if notebook is None or notebook.deleted:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Notebook not found.")
            return _cell(row), notebook.project_id

    def _store_output_sync(self, cell_id: str, output: dict[str, Any]) -> None:
        with self._database.session() as session:
            row = session.get(NotebookCellRow, cell_id)
            if row is None:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Notebook cell not found.")
            row.output_json = json.dumps(output, ensure_ascii=False, separators=(",", ":"))
            row.updated_at_utc = datetime.now(UTC).isoformat()


def _tool_request(cell: NotebookCell, project_id: UUID) -> ToolRequest:
    if cell.cell_type is CellType.CODE:
        tool = "python.run_code"
        arguments: dict[str, Any] = {"code": cell.content, "timeout_seconds": 60}
    elif cell.cell_type is CellType.SQL:
        tool = "sql.query"
        arguments = {"engine": "duckdb", "query": cell.content, "timeout_seconds": 60}
    elif cell.cell_type is CellType.R:
        tool = "r.run_structured"
        try:
            raw = json.loads(cell.content)
        except json.JSONDecodeError as exc:
            raise QError(
                QErrorCode.VALIDATION_ERROR,
                "R cells contain a structured JSON operation, not raw R code.",
            ) from exc
        if not isinstance(raw, dict):
            raise QError(QErrorCode.VALIDATION_ERROR, "R cell JSON must be an object.")
        arguments = raw
    else:
        raise QError(QErrorCode.VALIDATION_ERROR, "Cell type is not executable.")
    return ToolRequest(
        request_id=uuid4(),
        tool=tool,
        arguments=arguments,
        reason=f"Ejecutar celda {cell.cell_type.value} del cuaderno",
        project_id=project_id,
    )


def _notebook(row: NotebookRow, cells: list[NotebookCell]) -> Notebook:
    return Notebook(
        notebook_id=UUID(row.notebook_id),
        project_id=UUID(row.project_id),
        title=row.title,
        cells=cells,
        created_at_utc=datetime.fromisoformat(row.created_at_utc),
        updated_at_utc=datetime.fromisoformat(row.updated_at_utc),
    )


def _cell(row: NotebookCellRow) -> NotebookCell:
    raw_output = json.loads(row.output_json) if row.output_json else None
    if raw_output is not None and not isinstance(raw_output, dict):
        raise QError(QErrorCode.INTERNAL_ERROR, "Stored notebook output is invalid.")
    return NotebookCell(
        cell_id=UUID(row.cell_id),
        position=row.position,
        cell_type=CellType(row.cell_type),
        content=row.content,
        output=raw_output,
        created_at_utc=datetime.fromisoformat(row.created_at_utc),
        updated_at_utc=datetime.fromisoformat(row.updated_at_utc),
    )
