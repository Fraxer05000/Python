"""SQLAlchemy metadata database with explicit transaction ownership."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import Boolean, Integer, String, Text, create_engine, event
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker


class Base(DeclarativeBase):
    pass


class AuditRow(Base):
    __tablename__ = "audit_events"

    event_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    timestamp_utc: Mapped[str] = mapped_column(String(40), index=True)
    actor: Mapped[str] = mapped_column(String(32))
    action: Mapped[str] = mapped_column(String(255), index=True)
    resource: Mapped[str | None] = mapped_column(Text, nullable=True)
    decision: Mapped[str] = mapped_column(String(16))
    result: Mapped[str] = mapped_column(String(16))
    correlation_id: Mapped[str] = mapped_column(String(64), index=True)
    details_json: Mapped[str] = mapped_column(Text, default="{}")
    previous_hash: Mapped[str] = mapped_column(String(64), default="")
    event_hash: Mapped[str] = mapped_column(String(64), unique=True)


class ProvenanceRow(Base):
    __tablename__ = "provenance_records"

    provenance_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    timestamp_utc: Mapped[str] = mapped_column(String(40), index=True)
    operation: Mapped[str] = mapped_column(String(255), index=True)
    inputs_json: Mapped[str] = mapped_column(Text)
    parameters_json: Mapped[str] = mapped_column(Text)
    environment_json: Mapped[str] = mapped_column(Text)
    outputs_json: Mapped[str] = mapped_column(Text)
    correlation_id: Mapped[str] = mapped_column(String(64), index=True)


class PermissionChallengeRow(Base):
    __tablename__ = "permission_challenges"

    challenge_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    request_id: Mapped[str] = mapped_column(String(36), unique=True, index=True)
    secret_hash: Mapped[str] = mapped_column(String(64))
    tool_name: Mapped[str] = mapped_column(String(255), index=True)
    resource: Mapped[str | None] = mapped_column(Text, nullable=True)
    expires_at_utc: Mapped[str] = mapped_column(String(40), index=True)
    used: Mapped[bool] = mapped_column(Boolean, default=False)
    request_json: Mapped[str] = mapped_column(Text)
    identity_json: Mapped[str] = mapped_column(Text)
    normalized_arguments_json: Mapped[str] = mapped_column(Text)
    outcome_json: Mapped[str] = mapped_column(Text)


class PermissionGrantRow(Base):
    __tablename__ = "permission_grants"

    grant_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str] = mapped_column(String(255), index=True)
    tool_name: Mapped[str] = mapped_column(String(255), index=True)
    scope: Mapped[str] = mapped_column(String(32), index=True)
    resource: Mapped[str] = mapped_column(Text)
    created_at_utc: Mapped[str] = mapped_column(String(40))
    expires_at_utc: Mapped[str | None] = mapped_column(String(40), nullable=True)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)


class ModelProfileRow(Base):
    __tablename__ = "model_profiles"

    profile_id: Mapped[str] = mapped_column(String(100), primary_key=True)
    profile_json: Mapped[str] = mapped_column(Text)
    updated_at_utc: Mapped[str] = mapped_column(String(40))


class ProjectRow(Base):
    __tablename__ = "projects"

    project_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    root_path: Mapped[str] = mapped_column(Text, unique=True)
    created_at_utc: Mapped[str] = mapped_column(String(40))
    updated_at_utc: Mapped[str] = mapped_column(String(40))
    deleted: Mapped[bool] = mapped_column(Boolean, default=False, index=True)


class AuthorizedRootRow(Base):
    __tablename__ = "authorized_roots"

    root_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    project_id: Mapped[str] = mapped_column(String(36), index=True)
    root_path: Mapped[str] = mapped_column(Text)
    created_at_utc: Mapped[str] = mapped_column(String(40))
    revoked: Mapped[bool] = mapped_column(Boolean, default=False, index=True)


class ChatSessionRow(Base):
    __tablename__ = "chat_sessions"

    session_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    project_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(200), default="Nueva conversación")
    created_at_utc: Mapped[str] = mapped_column(String(40))
    updated_at_utc: Mapped[str] = mapped_column(String(40), index=True)


class ChatMessageRow(Base):
    __tablename__ = "chat_messages"

    message_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    session_id: Mapped[str] = mapped_column(String(36), index=True)
    role: Mapped[str] = mapped_column(String(16))
    content: Mapped[str] = mapped_column(Text)
    tool_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    tool_call_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    tool_calls_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at_utc: Mapped[str] = mapped_column(String(40), index=True)


class ArtifactRow(Base):
    __tablename__ = "artifacts"

    artifact_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    project_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    path: Mapped[str] = mapped_column(Text)
    artifact_type: Mapped[str] = mapped_column(String(80), index=True)
    source_operation: Mapped[str] = mapped_column(String(255), index=True)
    created_at_utc: Mapped[str] = mapped_column(String(40), index=True)
    provenance_id: Mapped[str] = mapped_column(String(36), index=True)


class MemoryRecordRow(Base):
    __tablename__ = "memory_records"

    memory_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    scope: Mapped[str] = mapped_column(String(32), index=True)
    user_id: Mapped[str] = mapped_column(String(255), index=True)
    project_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    content: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(Text)
    sensitivity: Mapped[bool] = mapped_column(Boolean, default=False)
    vector_ref: Mapped[str] = mapped_column(String(36), unique=True)
    created_at_utc: Mapped[str] = mapped_column(String(40), index=True)
    updated_at_utc: Mapped[str] = mapped_column(String(40))
    deleted: Mapped[bool] = mapped_column(Boolean, default=False, index=True)


class ConnectorRow(Base):
    __tablename__ = "connectors"

    connector_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    connector_type: Mapped[str] = mapped_column(String(64), index=True)
    endpoint: Mapped[str] = mapped_column(Text)
    username: Mapped[str | None] = mapped_column(String(320), nullable=True)
    credential_ref: Mapped[str | None] = mapped_column(String(200), nullable=True)
    created_at_utc: Mapped[str] = mapped_column(String(40))
    updated_at_utc: Mapped[str] = mapped_column(String(40))
    revoked: Mapped[bool] = mapped_column(Boolean, default=False, index=True)


class NotebookRow(Base):
    __tablename__ = "notebooks"

    notebook_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    project_id: Mapped[str] = mapped_column(String(36), index=True)
    title: Mapped[str] = mapped_column(String(200))
    created_at_utc: Mapped[str] = mapped_column(String(40))
    updated_at_utc: Mapped[str] = mapped_column(String(40), index=True)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False, index=True)


class NotebookCellRow(Base):
    __tablename__ = "notebook_cells"

    cell_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    notebook_id: Mapped[str] = mapped_column(String(36), index=True)
    position: Mapped[int] = mapped_column(Integer)
    cell_type: Mapped[str] = mapped_column(String(32))
    content: Mapped[str] = mapped_column(Text)
    output_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at_utc: Mapped[str] = mapped_column(String(40))
    updated_at_utc: Mapped[str] = mapped_column(String(40))


class Database:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.engine = create_engine(
            f"sqlite+pysqlite:///{path.as_posix()}",
            connect_args={"check_same_thread": False},
            future=True,
        )
        event.listen(self.engine, "connect", _configure_sqlite)
        self._sessions = sessionmaker(self.engine, expire_on_commit=False, class_=Session)

    def initialize(self) -> None:
        Base.metadata.create_all(self.engine)

    @contextmanager
    def session(self) -> Iterator[Session]:
        session = self._sessions()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def close(self) -> None:
        self.engine.dispose()


def _configure_sqlite(connection: object, _record: object) -> None:
    if not hasattr(connection, "cursor"):
        raise TypeError("SQLite connection does not expose a cursor")
    cursor = connection.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=FULL")
    finally:
        cursor.close()
