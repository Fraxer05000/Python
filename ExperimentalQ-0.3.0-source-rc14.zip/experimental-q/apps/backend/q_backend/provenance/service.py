"""Canonical provenance records for reproducible controller outputs."""

from __future__ import annotations

import asyncio
import json
import platform
from datetime import UTC, datetime
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from uuid import uuid4

from q_backend.controllers.base import ControllerResult
from q_backend.models.tool import ToolDefinition, ToolRequest
from q_backend.storage.database import ArtifactRow, Database, ProvenanceRow


class ProvenanceService:
    def __init__(self, database: Database) -> None:
        self._database = database

    async def record_controller_result(
        self,
        request: ToolRequest,
        definition: ToolDefinition,
        result: ControllerResult,
    ) -> str | None:
        if not result.provenance_inputs and not result.provenance_outputs:
            return None
        return await asyncio.to_thread(self._record_sync, request, definition, result)

    def _record_sync(
        self,
        request: ToolRequest,
        definition: ToolDefinition,
        result: ControllerResult,
    ) -> str:
        provenance_id = str(uuid4())
        environment = {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "packages": {
                name: _safe_version(name) for name in ("numpy", "pandas", "scipy", "scikit-learn")
            },
        }
        timestamp = datetime.now(UTC).isoformat()
        with self._database.session() as session:
            session.add(
                ProvenanceRow(
                    provenance_id=provenance_id,
                    timestamp_utc=timestamp,
                    operation=definition.name,
                    inputs_json=json.dumps(result.provenance_inputs, separators=(",", ":")),
                    parameters_json=json.dumps(
                        result.provenance_parameters,
                        separators=(",", ":"),
                    ),
                    environment_json=json.dumps(environment, separators=(",", ":")),
                    outputs_json=json.dumps(result.provenance_outputs, separators=(",", ":")),
                    correlation_id=str(request.request_id),
                )
            )
            for output in result.provenance_outputs:
                path_value = output.get("path")
                if not isinstance(path_value, str):
                    continue
                path = Path(path_value)
                session.add(
                    ArtifactRow(
                        artifact_id=str(uuid4()),
                        project_id=str(request.project_id) if request.project_id else None,
                        path=path_value,
                        artifact_type=path.suffix.lower().lstrip(".") or "artifact",
                        source_operation=definition.name,
                        created_at_utc=timestamp,
                        provenance_id=provenance_id,
                    )
                )
        return provenance_id


def _safe_version(package: str) -> str | None:
    try:
        return version(package)
    except PackageNotFoundError:
        return None
