"""Read-only artifact index populated by provenance recording."""

from __future__ import annotations

import asyncio
from datetime import datetime
from pathlib import Path
from uuid import UUID

from sqlalchemy import select

from q_backend.models.artifact import Artifact
from q_backend.storage.database import ArtifactRow, Database


class ArtifactService:
    def __init__(self, database: Database) -> None:
        self._database = database

    async def list_artifacts(self, project_id: UUID | None) -> list[Artifact]:
        return await asyncio.to_thread(self._list_sync, str(project_id) if project_id else None)

    def _list_sync(self, project_id: str | None) -> list[Artifact]:
        with self._database.session() as session:
            statement = select(ArtifactRow).order_by(ArtifactRow.created_at_utc.desc())
            if project_id is not None:
                statement = statement.where(ArtifactRow.project_id == project_id)
            rows = session.scalars(statement).all()
            return [
                Artifact(
                    artifact_id=UUID(row.artifact_id),
                    project_id=UUID(row.project_id) if row.project_id else None,
                    path=row.path,
                    filename=Path(row.path).name,
                    artifact_type=row.artifact_type,
                    source_operation=row.source_operation,
                    created_at_utc=datetime.fromisoformat(row.created_at_utc),
                    provenance_id=UUID(row.provenance_id),
                )
                for row in rows
            ]
