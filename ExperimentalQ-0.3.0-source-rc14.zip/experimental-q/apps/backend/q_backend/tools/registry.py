"""Immutable-at-runtime tool registry loader."""

from __future__ import annotations

import json
from pathlib import Path

from q_backend.errors import QError, QErrorCode
from q_backend.models.tool import ToolDefinition, ToolRegistryDocument


class ToolRegistry:
    def __init__(self, document: ToolRegistryDocument) -> None:
        names = [tool.name for tool in document.tools]
        if len(names) != len(set(names)):
            raise QError(QErrorCode.VALIDATION_ERROR, "Tool registry contains duplicate names.")
        self.version = document.version
        self._tools = {tool.name: tool for tool in document.tools}

    @classmethod
    def from_file(cls, path: Path) -> ToolRegistry:
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            document = ToolRegistryDocument.model_validate(raw)
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            raise QError(QErrorCode.VALIDATION_ERROR, "Tool registry is invalid.") from exc
        return cls(document)

    def resolve(self, name: str) -> ToolDefinition:
        try:
            return self._tools[name]
        except KeyError as exc:
            raise QError(
                QErrorCode.VALIDATION_ERROR,
                "The requested tool is not registered.",
                details={"tool": name},
            ) from exc

    def definitions(self) -> tuple[ToolDefinition, ...]:
        return tuple(self._tools.values())

    def openai_tools(self) -> list[dict[str, object]]:
        return [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": f"Registered Experimental Q tool {tool.name}",
                    "parameters": tool.arguments_schema,
                },
            }
            for tool in self._tools.values()
        ]
