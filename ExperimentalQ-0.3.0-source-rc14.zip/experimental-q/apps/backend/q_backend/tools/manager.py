"""Mandatory validation, policy, permission, controller, audit, and provenance path."""

from __future__ import annotations

from typing import Protocol

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError, ValidationError

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import (
    InvocationIdentity,
    PermissionChallenge,
    PolicyDecision,
    PolicyOutcome,
)
from q_backend.models.protocol import ErrorBody
from q_backend.models.tool import ToolDefinition, ToolRequest, ToolResult, ToolStatus
from q_backend.tools.registry import ToolRegistry


class PolicyEvaluator(Protocol):
    async def evaluate(
        self,
        definition: ToolDefinition,
        arguments: dict[str, object],
        identity: InvocationIdentity,
    ) -> PolicyOutcome: ...


class PermissionIssuer(Protocol):
    async def issue(
        self,
        request: ToolRequest,
        definition: ToolDefinition,
        arguments: dict[str, object],
        identity: InvocationIdentity,
        outcome: PolicyOutcome,
    ) -> PermissionChallenge: ...


class AuditRecorder(Protocol):
    async def record_tool_decision(
        self,
        request: ToolRequest,
        definition: ToolDefinition,
        identity: InvocationIdentity,
        outcome: PolicyOutcome,
        result: str,
        resource: str | None = None,
    ) -> str: ...


class ProvenanceRecorder(Protocol):
    async def record_controller_result(
        self,
        request: ToolRequest,
        definition: ToolDefinition,
        result: ControllerResult,
    ) -> str | None: ...


class ToolManager:
    def __init__(
        self,
        registry: ToolRegistry,
        controllers: dict[str, BaseController],
        policy: PolicyEvaluator,
        permissions: PermissionIssuer,
        audit: AuditRecorder,
        provenance: ProvenanceRecorder,
    ) -> None:
        self._registry = registry
        self._controllers = dict(controllers)
        self._policy = policy
        self._permissions = permissions
        self._audit = audit
        self._provenance = provenance

    def model_tool_contract(self) -> dict[str, object]:
        available = [
            definition.name
            for definition in self._registry.definitions()
            if definition.controller in self._controllers
        ]
        return {
            "type": "function",
            "function": {
                "name": "q_tool_request",
                "description": "Request one registered Experimental Q controller action.",
                "parameters": {
                    "$schema": "https://json-schema.org/draft/2020-12/schema",
                    "type": "object",
                    "required": ["request_id", "tool", "arguments", "reason", "project_id"],
                    "properties": {
                        "request_id": {"type": "string", "format": "uuid"},
                        "tool": {"type": "string", "enum": available},
                        "arguments": {"type": "object"},
                        "reason": {"type": "string", "minLength": 1, "maxLength": 300},
                        "project_id": {"type": ["string", "null"], "format": "uuid"},
                    },
                    "additionalProperties": False,
                },
            },
        }

    async def invoke(self, request: ToolRequest, identity: InvocationIdentity) -> ToolResult:
        audit_id: str | None = None
        try:
            definition = self._registry.resolve(request.tool)
            controller = self._controllers.get(definition.controller)
            if controller is None:
                raise QError(
                    QErrorCode.RUNTIME_UNAVAILABLE,
                    "The registered controller is not available.",
                    details={"controller": definition.controller},
                )
            schema = controller.argument_schema(definition.method)
            Draft202012Validator.check_schema(schema)
            Draft202012Validator(schema).validate(request.arguments)
            normalized = await controller.normalize_arguments(
                definition.method,
                request.arguments,
                identity,
            )
            outcome = await self._policy.evaluate(definition, normalized, identity)
            if outcome.decision is PolicyDecision.DENY:
                audit_id = await self._audit.record_tool_decision(
                    request,
                    definition,
                    identity,
                    outcome,
                    "failure",
                )
                raise QError(
                    _error_code(outcome.error_code),
                    "Policy denied this tool invocation.",
                    details={"reason_code": outcome.reason_code},
                )
            if outcome.decision is PolicyDecision.CONFIRM:
                challenge = await self._permissions.issue(
                    request,
                    definition,
                    normalized,
                    identity,
                    outcome,
                )
                audit_id = await self._audit.record_tool_decision(
                    request,
                    definition,
                    identity,
                    outcome,
                    "pending",
                )
                return ToolResult(
                    request_id=request.request_id,
                    status=ToolStatus.CONFIRMATION_REQUIRED,
                    data=challenge.model_dump(mode="json"),
                    audit_id=audit_id,
                )
            controller_result = await controller.invoke(
                definition.method,
                normalized,
                identity,
            )
            audit_id = await self._audit.record_tool_decision(
                request,
                definition,
                identity,
                outcome,
                "success",
                controller_result.resource,
            )
            provenance_id = await self._provenance.record_controller_result(
                request,
                definition,
                controller_result,
            )
            return ToolResult(
                request_id=request.request_id,
                status=ToolStatus.OK,
                data=controller_result.data,
                audit_id=audit_id,
                provenance_id=provenance_id,
            )
        except (ValidationError, SchemaError) as exc:
            error = QError(
                QErrorCode.VALIDATION_ERROR,
                "Tool arguments do not match the registered schema.",
                details={"path": [str(item) for item in getattr(exc, "path", [])]},
            )
        except QError as exc:
            error = exc
        return ToolResult(
            request_id=request.request_id,
            status=ToolStatus.ERROR,
            error=ErrorBody.model_validate(error.as_dict()),
            audit_id=audit_id,
        )

    async def invoke_confirmed(
        self,
        request: ToolRequest,
        identity: InvocationIdentity,
        normalized_arguments: dict[str, object],
    ) -> ToolResult:
        """Execute a request only after PermissionManager verified its one-time challenge."""
        definition = self._registry.resolve(request.tool)
        controller = self._controllers.get(definition.controller)
        if controller is None:
            raise QError(
                QErrorCode.RUNTIME_UNAVAILABLE,
                "The registered controller is not available.",
            )
        outcome = PolicyOutcome(
            decision=PolicyDecision.ALLOW,
            reason_code="confirmed_once",
            destructive=definition.permission.value == "P4",
        )
        try:
            result = await controller.invoke(definition.method, normalized_arguments, identity)
        except QError as error:
            audit_id = await self._audit.record_tool_decision(
                request,
                definition,
                identity,
                outcome,
                "failure",
                _normalized_resource(normalized_arguments),
            )
            return ToolResult(
                request_id=request.request_id,
                status=ToolStatus.ERROR,
                error=ErrorBody.model_validate(error.as_dict()),
                audit_id=audit_id,
            )
        audit_id = await self._audit.record_tool_decision(
            request,
            definition,
            identity,
            outcome,
            "success",
            result.resource,
        )
        provenance_id = await self._provenance.record_controller_result(
            request,
            definition,
            result,
        )
        return ToolResult(
            request_id=request.request_id,
            status=ToolStatus.OK,
            data=result.data,
            audit_id=audit_id,
            provenance_id=provenance_id,
        )


def _error_code(value: str | None) -> QErrorCode:
    if value is None:
        return QErrorCode.PERMISSION_DENIED
    try:
        return QErrorCode(value)
    except ValueError:
        return QErrorCode.PERMISSION_DENIED


def _normalized_resource(arguments: dict[str, object]) -> str | None:
    policy = arguments.get("_policy")
    if isinstance(policy, dict):
        resource = policy.get("resource")
        if isinstance(resource, str):
            return resource
    return None
