"""Versioned authenticated API routes."""

from __future__ import annotations

import secrets
from typing import Annotated, Any
from uuid import UUID

from fastapi import APIRouter, Depends, Header, Request, Response, status

from q_backend.container import AppContainer
from q_backend.errors import QError, QErrorCode
from q_backend.models.artifact import Artifact
from q_backend.models.audio import TranscriptionResponse
from q_backend.models.chat import (
    ChatMessageView,
    ChatSession,
    ChatSessionCreate,
    ChatTurnRequest,
    ChatTurnResponse,
)
from q_backend.models.connector import Connector, ConnectorCreate
from q_backend.models.memory import KnowledgeIndexRequest, KnowledgeIndexResult
from q_backend.models.notebook import (
    CellCreate,
    CellExecuteRequest,
    CellExecutionResult,
    CellType,
    CellUpdate,
    Notebook,
    NotebookCell,
    NotebookCreate,
)
from q_backend.models.permissions import (
    ApplicationMode,
    InvocationIdentity,
    PermissionConfirmation,
    PermissionGrant,
)
from q_backend.models.project import (
    AuthorizedRoot,
    AuthorizedRootRequest,
    Project,
    ProjectCreate,
    ProjectDeleteRequest,
    ProjectUpdate,
)
from q_backend.models.protocol import (
    CancelledResponse,
    ErrorBody,
    HealthResponse,
    ModelStartRequest,
    OperationAccepted,
)
from q_backend.models.runtime import ModelProfile
from q_backend.models.tool import ToolRequest, ToolResult, ToolStatus


def require_local_bearer(
    request: Request,
    authorization: Annotated[str | None, Header()] = None,
) -> None:
    expected = request.app.state.settings.session_token
    scheme, _, supplied = (authorization or "").partition(" ")
    if scheme.lower() != "bearer" or not supplied or not secrets.compare_digest(supplied, expected):
        raise QError(
            QErrorCode.PERMISSION_DENIED,
            "A valid per-launch local bearer token is required.",
            details={"authentication": True},
        )


router = APIRouter(prefix="/api/v1", dependencies=[Depends(require_local_bearer)])


def _container(request: Request) -> AppContainer:
    container = request.app.state.container
    if not isinstance(container, AppContainer):
        raise QError(QErrorCode.RUNTIME_UNAVAILABLE, "Backend services are not initialized.")
    return container


def _identity(
    request: Request,
    project_id: object,
    session_id: str | None,
) -> InvocationIdentity:
    container = _container(request)
    return InvocationIdentity(
        session_id=session_id or "desktop_api",
        project_id=str(project_id) if project_id else None,
        mode=ApplicationMode(container.settings.mode),
    )


@router.get("/health", response_model=HealthResponse)
async def health(request: Request) -> HealthResponse:
    state = await _container(request).models.state()
    return HealthResponse(q_state=state.state.value)


@router.get("/system/state")
async def system_state(request: Request) -> dict[str, Any]:
    container = _container(request)
    state = await container.models.state()
    resources = await container.models.resources()
    return {
        "lifecycle": state.model_dump(mode="json"),
        "resources": resources.model_dump(mode="json"),
        "mode": container.settings.mode,
        "network_enabled": container.settings.mode != "local_only",
    }


@router.post("/models/profiles", status_code=status.HTTP_201_CREATED)
async def put_model_profile(request: Request, profile: ModelProfile) -> ModelProfile:
    return await _container(request).models.put_profile(profile)


@router.get("/models/profiles")
async def list_model_profiles(request: Request) -> list[ModelProfile]:
    return await _container(request).models.list_profiles()


@router.get("/projects", response_model=list[Project])
async def list_projects(request: Request) -> list[Project]:
    return await _container(request).projects.list_projects()


@router.post("/projects", response_model=Project, status_code=status.HTTP_201_CREATED)
async def create_project(request: Request, body: ProjectCreate) -> Project:
    container = _container(request)
    project = await container.projects.create(body)
    await container.audit.record(
        actor="user",
        action="project.create",
        resource=project.root_path,
        decision="allow",
        result="success",
        correlation_id=str(project.project_id),
    )
    return project


@router.get("/projects/{project_id}", response_model=Project)
async def get_project(request: Request, project_id: str) -> Project:
    return await _container(request).projects.get(project_id)


@router.patch("/projects/{project_id}", response_model=Project)
async def update_project(request: Request, project_id: str, body: ProjectUpdate) -> Project:
    return await _container(request).projects.update(project_id, body)


@router.delete(
    "/projects/{project_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
)
async def delete_project(
    request: Request,
    project_id: str,
    body: ProjectDeleteRequest,
) -> Response:
    container = _container(request)
    await container.projects.delete(project_id, body)
    await container.audit.record(
        actor="user",
        action="project.delete",
        resource=project_id,
        decision="allow",
        result="success",
        correlation_id=project_id,
        details={"remove_project_files": body.remove_project_files},
    )
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post(
    "/projects/{project_id}/authorized-roots",
    response_model=AuthorizedRoot,
    status_code=status.HTTP_201_CREATED,
)
async def authorize_project_root(
    request: Request,
    project_id: str,
    body: AuthorizedRootRequest,
) -> AuthorizedRoot:
    container = _container(request)
    root = await container.projects.add_authorized_root(project_id, body)
    await container.audit.record(
        actor="user",
        action="project.authorize_root",
        resource=root.root_path,
        decision="allow",
        result="success",
        correlation_id=str(root.root_id),
    )
    return root


@router.post("/model/start", status_code=status.HTTP_202_ACCEPTED)
async def start_model(request: Request, body: ModelStartRequest) -> OperationAccepted:
    container = _container(request)
    state = await container.models.start(body.profile_id)
    await container.audit.record(
        actor="user",
        action="model.start",
        resource=body.profile_id,
        decision="allow",
        result="success",
        correlation_id=body.profile_id,
    )
    return OperationAccepted(state=state.state.value)


@router.post("/model/sleep", status_code=status.HTTP_202_ACCEPTED)
async def sleep_model(request: Request) -> OperationAccepted:
    container = _container(request)
    state = await container.models.sleep()
    await container.audit.record(
        actor="user",
        action="model.sleep",
        resource=state.model_profile_id,
        decision="allow",
        result="success",
        correlation_id=state.model_profile_id or "model",
    )
    return OperationAccepted(state=state.state.value)


@router.post("/model/stop", status_code=status.HTTP_202_ACCEPTED)
async def stop_model(request: Request) -> OperationAccepted:
    container = _container(request)
    state = await container.models.stop()
    await container.audit.record(
        actor="user",
        action="model.stop",
        resource=None,
        decision="allow",
        result="success",
        correlation_id="model",
    )
    return OperationAccepted(state=state.state.value)


@router.post("/tools/invoke", response_model=ToolResult)
async def invoke_tool(
    request: Request,
    body: ToolRequest,
    response: Response,
    x_session_id: Annotated[str | None, Header()] = None,
) -> ToolResult:
    identity = _identity(request, body.project_id, x_session_id)
    result = await _container(request).tools.invoke(body, identity)
    if result.status is ToolStatus.CONFIRMATION_REQUIRED:
        response.status_code = status.HTTP_409_CONFLICT
    return result


@router.get("/chat/sessions", response_model=list[ChatSession])
async def list_chat_sessions(request: Request) -> list[ChatSession]:
    return await _container(request).chat.sessions()


@router.post(
    "/chat/sessions",
    response_model=ChatSession,
    status_code=status.HTTP_201_CREATED,
)
async def create_chat_session(request: Request, body: ChatSessionCreate) -> ChatSession:
    container = _container(request)
    if body.project_id is not None:
        await container.projects.get(body.project_id)
    return await container.chat.create_session(body)


@router.get("/chat/sessions/{session_id}/messages", response_model=list[ChatMessageView])
async def chat_messages(request: Request, session_id: UUID) -> list[ChatMessageView]:
    return await _container(request).chat.messages(session_id)


@router.post("/chat/turn", response_model=ChatTurnResponse)
async def chat_turn(request: Request, body: ChatTurnRequest) -> ChatTurnResponse:
    return await _container(request).chat.turn(body)


@router.post("/chat/cancel/{request_id}", response_model=CancelledResponse)
async def cancel_chat(request: Request, request_id: str) -> CancelledResponse:
    await _container(request).chat.cancel(request_id)
    return CancelledResponse()


@router.get("/artifacts", response_model=list[Artifact])
async def list_artifacts(request: Request, project_id: UUID | None = None) -> list[Artifact]:
    return await _container(request).artifacts.list_artifacts(project_id)


@router.post("/knowledge/index", response_model=KnowledgeIndexResult)
async def index_knowledge(
    request: Request,
    body: KnowledgeIndexRequest,
) -> KnowledgeIndexResult:
    container = _container(request)
    await container.projects.get(body.project_id)
    result = await container.memory.index_knowledge(body)
    await container.audit.record(
        actor="user",
        action="knowledge.index",
        resource=body.source,
        decision="allow",
        result="success",
        correlation_id=str(body.project_id),
        details={"chunk_count": result.chunk_count},
    )
    return result


@router.delete("/memory/{memory_id}", response_model=CancelledResponse)
async def delete_memory(
    request: Request,
    memory_id: UUID,
    explicit_user_confirmation: bool = False,
) -> CancelledResponse:
    container = _container(request)
    await container.memory.delete(
        memory_id,
        explicit_confirmation=explicit_user_confirmation,
    )
    await container.audit.record(
        actor="user",
        action="memory.delete",
        resource=str(memory_id),
        decision="allow",
        result="success",
        correlation_id=str(memory_id),
    )
    return CancelledResponse()


@router.get("/connectors", response_model=list[Connector])
async def list_connectors(request: Request) -> list[Connector]:
    return await _container(request).connectors.list_connectors()


@router.post(
    "/connectors",
    response_model=Connector,
    status_code=status.HTTP_201_CREATED,
)
async def create_connector(request: Request, body: ConnectorCreate) -> Connector:
    container = _container(request)
    connector = await container.connectors.create(body)
    await container.audit.record(
        actor="user",
        action="connector.create",
        resource=connector.endpoint,
        decision="allow",
        result="success",
        correlation_id=str(connector.connector_id),
        details={
            "connector_type": connector.connector_type.value,
            "has_credential": connector.has_credential,
        },
    )
    return connector


@router.delete("/connectors/{connector_id}", response_model=CancelledResponse)
async def revoke_connector(
    request: Request,
    connector_id: UUID,
    explicit_user_confirmation: bool = False,
) -> CancelledResponse:
    if not explicit_user_confirmation:
        raise QError(
            QErrorCode.CONFIRMATION_REQUIRED,
            "Revoking a connector requires explicit user confirmation.",
        )
    container = _container(request)
    await container.connectors.revoke(connector_id)
    await container.audit.record(
        actor="user",
        action="connector.revoke",
        resource=str(connector_id),
        decision="allow",
        result="success",
        correlation_id=str(connector_id),
    )
    return CancelledResponse()


@router.get("/notebooks", response_model=list[Notebook])
async def list_notebooks(request: Request, project_id: UUID) -> list[Notebook]:
    return await _container(request).notebooks.list_notebooks(project_id)


@router.post(
    "/notebooks",
    response_model=Notebook,
    status_code=status.HTTP_201_CREATED,
)
async def create_notebook(request: Request, body: NotebookCreate) -> Notebook:
    return await _container(request).notebooks.create(body)


@router.get("/notebooks/{notebook_id}", response_model=Notebook)
async def get_notebook(request: Request, notebook_id: UUID) -> Notebook:
    return await _container(request).notebooks.get(notebook_id)


@router.post(
    "/notebooks/{notebook_id}/cells",
    response_model=NotebookCell,
    status_code=status.HTTP_201_CREATED,
)
async def add_notebook_cell(
    request: Request,
    notebook_id: UUID,
    body: CellCreate,
) -> NotebookCell:
    return await _container(request).notebooks.add_cell(notebook_id, body)


@router.patch("/notebook-cells/{cell_id}", response_model=NotebookCell)
async def update_notebook_cell(
    request: Request,
    cell_id: UUID,
    body: CellUpdate,
) -> NotebookCell:
    return await _container(request).notebooks.update_cell(cell_id, body)


@router.post("/notebook-cells/{cell_id}/execute", response_model=CellExecutionResult)
async def execute_notebook_cell(
    request: Request,
    cell_id: UUID,
    body: CellExecuteRequest,
) -> CellExecutionResult:
    result = await _container(request).notebooks.execute(cell_id, body)
    await _container(request).audit.record(
        actor="user",
        action="notebook.execute_cell",
        resource=str(cell_id),
        decision="allow",
        result="success" if result.status == "ok" else "pending",
        correlation_id=str(cell_id),
        details={"status": result.status},
    )
    return result


@router.post(
    "/notebook-cells/{cell_id}/permissions/confirm",
    response_model=CellExecutionResult,
)
async def confirm_notebook_cell_permission(
    request: Request,
    cell_id: UUID,
    body: PermissionConfirmation,
) -> CellExecutionResult:
    """Resume a gated notebook cell once, without replaying its operation."""
    container = _container(request)
    cell_type, pending_request_id = await container.notebooks.validate_pending_confirmation(
        cell_id,
        body.challenge_id,
    )
    confirmed = await container.permissions.confirm(body)
    decision = "deny" if confirmed is None else "allow"
    if confirmed is None:
        error = QError(QErrorCode.PERMISSION_DENIED, "The user cancelled the requested action.")
        tool_result = ToolResult(
            request_id=pending_request_id,
            status=ToolStatus.ERROR,
            error=ErrorBody.model_validate(error.as_dict()),
        )
    else:
        tool_result = await container.tools.invoke_confirmed(
            confirmed.request,
            confirmed.identity,
            confirmed.normalized_arguments,
        )

    if cell_type is CellType.PROMPT:
        chat_result = await container.chat.resume_confirmation(body.challenge_id, tool_result)
        output = chat_result.model_dump(mode="json")
        result_status = chat_result.status.value
    else:
        output = tool_result.model_dump(mode="json")
        result_status = tool_result.status.value

    await container.audit.record(
        actor="user",
        action="notebook.permission_confirm",
        resource=str(cell_id),
        decision=decision,
        result="success" if tool_result.status is ToolStatus.OK else "error",
        correlation_id=str(pending_request_id),
        details={"challenge_id": body.challenge_id, "tool_status": tool_result.status.value},
    )
    return await container.notebooks.complete_confirmation(
        cell_id,
        status=result_status,
        output=output,
    )


@router.post("/audio/transcribe", response_model=TranscriptionResponse)
async def transcribe_audio(
    request: Request,
    language: str = "es",
) -> TranscriptionResponse:
    raw_length = request.headers.get("content-length")
    if raw_length is not None:
        try:
            content_length = int(raw_length)
        except ValueError as exc:
            raise QError(QErrorCode.VALIDATION_ERROR, "Content-Length is invalid.") from exc
        if content_length > 25 * 1024 * 1024:
            raise QError(QErrorCode.VALIDATION_ERROR, "Audio exceeds the 25 MB limit.")
    if request.headers.get("content-type", "").split(";", 1)[0] != "audio/wav":
        raise QError(QErrorCode.VALIDATION_ERROR, "Audio content type must be audio/wav.")
    audio = await request.body()
    result = await _container(request).audio.transcribe(audio, language)
    await _container(request).audit.record(
        actor="user",
        action="microphone.transcribe",
        resource="ephemeral_local_audio",
        decision="allow",
        result="success",
        correlation_id=result.language,
        details={"audio_bytes": len(audio), "duration_ms": result.duration_ms},
    )
    return result


@router.post("/permissions/confirm", response_model=ToolResult | CancelledResponse)
async def confirm_permission(
    request: Request,
    body: PermissionConfirmation,
) -> ToolResult | CancelledResponse:
    container = _container(request)
    confirmed = await container.permissions.confirm(body)
    if confirmed is None:
        await container.audit.record(
            actor="user",
            action="permission.confirm",
            resource=body.challenge_id,
            decision="deny",
            result="cancelled",
            correlation_id=body.challenge_id,
        )
        return CancelledResponse()
    await container.audit.record(
        actor="user",
        action="permission.confirm",
        resource=body.challenge_id,
        decision="allow",
        result="success",
        correlation_id=str(confirmed.request.request_id),
    )
    return await container.tools.invoke_confirmed(
        confirmed.request,
        confirmed.identity,
        confirmed.normalized_arguments,
    )


@router.get("/permissions/grants", response_model=list[PermissionGrant])
async def list_permission_grants(request: Request) -> list[PermissionGrant]:
    return await _container(request).permissions.grants()


@router.delete("/permissions/grants/{grant_id}", response_model=CancelledResponse)
async def revoke_permission_grant(
    request: Request,
    grant_id: UUID,
    explicit_user_confirmation: bool = False,
) -> CancelledResponse:
    if not explicit_user_confirmation:
        raise QError(
            QErrorCode.CONFIRMATION_REQUIRED,
            "Revoking a permission grant requires explicit user confirmation.",
        )
    container = _container(request)
    if not await container.permissions.revoke(str(grant_id)):
        raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Permission grant not found.")
    await container.audit.record(
        actor="user",
        action="permission.revoke",
        resource=str(grant_id),
        decision="allow",
        result="success",
        correlation_id=str(grant_id),
    )
    return CancelledResponse()


@router.post("/chat/permissions/confirm", response_model=ChatTurnResponse)
async def confirm_chat_permission(
    request: Request,
    body: PermissionConfirmation,
) -> ChatTurnResponse:
    container = _container(request)
    pending_request_id = container.chat.pending_request_id(body.challenge_id)
    confirmed = await container.permissions.confirm(body)
    if confirmed is None:
        error = QError(QErrorCode.PERMISSION_DENIED, "The user cancelled the requested action.")
        result = ToolResult(
            request_id=pending_request_id,
            status=ToolStatus.ERROR,
            error=ErrorBody.model_validate(error.as_dict()),
        )
        await container.audit.record(
            actor="user",
            action="permission.confirm",
            resource=body.challenge_id,
            decision="deny",
            result="cancelled",
            correlation_id=str(pending_request_id),
        )
    else:
        result = await container.tools.invoke_confirmed(
            confirmed.request,
            confirmed.identity,
            confirmed.normalized_arguments,
        )
        await container.audit.record(
            actor="user",
            action="permission.confirm",
            resource=body.challenge_id,
            decision="allow",
            result="success",
            correlation_id=str(confirmed.request.request_id),
        )
    return await container.chat.resume_confirmation(body.challenge_id, result)


@router.get("/events")
async def events_placeholder() -> dict[str, str]:
    return {"websocket": "/api/v1/events/ws"}
