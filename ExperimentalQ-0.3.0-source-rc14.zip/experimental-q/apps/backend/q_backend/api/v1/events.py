"""Authenticated local WebSocket event stream."""

from __future__ import annotations

import asyncio
import secrets

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from q_backend.container import AppContainer

events_router = APIRouter(prefix="/api/v1")


@events_router.websocket("/events/ws")
async def event_stream(websocket: WebSocket) -> None:
    """Publish bounded supervisor snapshots; never accept commands over the socket."""
    protocols = [
        value.strip()
        for value in websocket.headers.get("sec-websocket-protocol", "").split(",")
        if value.strip()
    ]
    expected = websocket.app.state.settings.session_token
    if (
        len(protocols) != 2
        or protocols[0] != "q-auth"
        or not secrets.compare_digest(protocols[1], expected)
    ):
        await websocket.close(code=4401, reason="Authentication required")
        return
    await websocket.accept(subprotocol="q-auth")
    container = websocket.app.state.container
    if not isinstance(container, AppContainer):
        await websocket.close(code=1011, reason="Backend unavailable")
        return
    try:
        while True:
            lifecycle = await container.models.state()
            resources = await container.models.resources()
            await websocket.send_json(
                {
                    "event": "system.snapshot",
                    "data": {
                        "lifecycle": lifecycle.model_dump(mode="json"),
                        "resources": resources.model_dump(mode="json"),
                        "mode": container.settings.mode,
                    },
                }
            )
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        return
