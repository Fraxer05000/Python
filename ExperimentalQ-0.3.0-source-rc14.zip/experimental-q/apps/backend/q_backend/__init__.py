"""Experimental Q local backend."""

__version__ = "0.1.0"
