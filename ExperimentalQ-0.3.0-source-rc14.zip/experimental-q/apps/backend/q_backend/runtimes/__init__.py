"""Replaceable model runtime adapters."""

from q_backend.runtimes.base import ModelRuntimeAdapter
from q_backend.runtimes.llama_cpp import LlamaCppAdapter

__all__ = ["LlamaCppAdapter", "ModelRuntimeAdapter"]
