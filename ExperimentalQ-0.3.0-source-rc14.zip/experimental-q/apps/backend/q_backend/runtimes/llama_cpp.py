"""OpenAI-compatible llama.cpp adapter restricted to the supervisor endpoint."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from typing import Any

import httpx

from q_backend.errors import QError, QErrorCode
from q_backend.models.lifecycle import QState
from q_backend.models.runtime import (
    InferenceChunk,
    InferenceRequest,
    InferenceResponse,
    ModelProfile,
    RuntimeConnection,
    RuntimeHealth,
    ToolCall,
)
from q_backend.supervisor.client import SupervisorClient


class LlamaCppAdapter:
    def __init__(
        self,
        supervisor: SupervisorClient,
        *,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._supervisor = supervisor
        self._client = client or httpx.AsyncClient(
            timeout=httpx.Timeout(180.0, connect=5.0),
            follow_redirects=False,
            trust_env=False,
        )
        self._owns_client = client is None
        self._cancellations: dict[str, asyncio.Event] = {}

    async def load(self, profile: ModelProfile) -> None:
        state = await self._supervisor.start(profile)
        if state.state is not QState.ACTIVE:
            raise QError(
                QErrorCode.MODEL_UNAVAILABLE,
                f"Model did not reach ACTIVE; current state is {state.state}.",
            )

    async def unload(self) -> None:
        await self._supervisor.stop()

    async def health(self) -> RuntimeHealth:
        state = await self._supervisor.state()
        if state.state is not QState.ACTIVE:
            return RuntimeHealth(state=state.state, healthy=False, detail=state.last_error)
        connection = await self._required_connection()
        try:
            response = await self._client.get(
                self._url(connection, "/health"),
                headers=self._headers(connection),
                timeout=2.0,
            )
        except httpx.HTTPError as exc:
            return RuntimeHealth(state=state.state, healthy=False, detail=str(exc))
        return RuntimeHealth(
            state=state.state,
            healthy=response.status_code == 200,
            detail=None if response.status_code == 200 else f"HTTP {response.status_code}",
        )

    async def generate(self, request: InferenceRequest) -> InferenceResponse:
        connection = await self._required_active_connection()
        payload = self._payload(request, stream=False)
        try:
            response = await self._client.post(
                self._url(connection, "/v1/chat/completions"),
                headers=self._headers(connection),
                json=payload,
            )
            response.raise_for_status()
            body = response.json()
        except (httpx.HTTPError, json.JSONDecodeError) as exc:
            raise QError(
                QErrorCode.MODEL_UNAVAILABLE,
                "llama.cpp inference failed.",
                details={"type": type(exc).__name__},
            ) from exc
        try:
            choice = body["choices"][0]
            message = choice["message"]
            raw_calls = message.get("tool_calls") or []
            tool_calls = [self._parse_tool_call(item) for item in raw_calls]
            usage = {key: int(value) for key, value in (body.get("usage") or {}).items()}
            return InferenceResponse(
                request_id=request.request_id,
                content=message.get("content"),
                tool_calls=tool_calls,
                finish_reason=choice.get("finish_reason"),
                usage=usage,
            )
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            raise QError(
                QErrorCode.INTERNAL_ERROR,
                "llama.cpp returned an invalid inference response.",
            ) from exc

    async def stream(self, request: InferenceRequest) -> AsyncIterator[InferenceChunk]:
        connection = await self._required_active_connection()
        cancellation = asyncio.Event()
        self._cancellations[request.request_id] = cancellation
        try:
            async with self._client.stream(
                "POST",
                self._url(connection, "/v1/chat/completions"),
                headers=self._headers(connection),
                json=self._payload(request, stream=True),
            ) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if cancellation.is_set():
                        raise QError(QErrorCode.TIMEOUT, "Inference was cancelled.")
                    if not line.startswith("data: "):
                        continue
                    raw = line[6:]
                    if raw == "[DONE]":
                        break
                    try:
                        body = json.loads(raw)
                        choice = body["choices"][0]
                        delta = choice.get("delta") or {}
                    except (json.JSONDecodeError, KeyError, IndexError, TypeError) as exc:
                        raise QError(
                            QErrorCode.INTERNAL_ERROR,
                            "llama.cpp returned an invalid stream chunk.",
                        ) from exc
                    yield InferenceChunk(
                        request_id=request.request_id,
                        content_delta=str(delta.get("content") or ""),
                        finish_reason=choice.get("finish_reason"),
                    )
        except httpx.HTTPError as exc:
            raise QError(QErrorCode.MODEL_UNAVAILABLE, "llama.cpp streaming failed.") from exc
        finally:
            self._cancellations.pop(request.request_id, None)

    async def cancel(self, request_id: str) -> None:
        if event := self._cancellations.get(request_id):
            event.set()

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def _required_active_connection(self) -> RuntimeConnection:
        state = await self._supervisor.state()
        if state.state is not QState.ACTIVE:
            raise QError(QErrorCode.MODEL_UNAVAILABLE, "Q is not ACTIVE.")
        return await self._required_connection()

    async def _required_connection(self) -> RuntimeConnection:
        connection = await self._supervisor.runtime_connection()
        if connection is None:
            raise QError(QErrorCode.MODEL_UNAVAILABLE, "No model runtime connection exists.")
        if connection.host != "127.0.0.1":
            raise QError(
                QErrorCode.PERMISSION_DENIED,
                "Model runtime must use the loopback interface.",
            )
        return connection

    @staticmethod
    def _url(connection: RuntimeConnection, path: str) -> str:
        return f"http://127.0.0.1:{connection.port}{path}"

    @staticmethod
    def _headers(connection: RuntimeConnection) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if connection.api_key:
            headers["Authorization"] = f"Bearer {connection.api_key}"
        return headers

    @staticmethod
    def _payload(request: InferenceRequest, *, stream: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "messages": [message.model_dump(exclude_none=True) for message in request.messages],
            "stream": stream,
        }
        if request.tools:
            payload["tools"] = request.tools
            payload["tool_choice"] = "auto"
        for key in ("temperature", "max_tokens", "seed"):
            value = getattr(request, key)
            if value is not None:
                payload[key] = value
        return payload

    @staticmethod
    def _parse_tool_call(raw: dict[str, Any]) -> ToolCall:
        function = raw.get("function") or {}
        arguments = function.get("arguments") or "{}"
        if isinstance(arguments, str):
            parsed = json.loads(arguments)
        elif isinstance(arguments, dict):
            parsed = arguments
        else:
            raise ValueError("Tool arguments are not an object")
        if not isinstance(parsed, dict):
            raise ValueError("Tool arguments are not an object")
        return ToolCall(
            id=str(raw["id"]),
            name=str(function["name"]),
            arguments=parsed,
        )
