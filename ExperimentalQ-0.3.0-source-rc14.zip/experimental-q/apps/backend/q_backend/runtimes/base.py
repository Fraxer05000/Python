"""Runtime adapter protocol from Architecture 3.0."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Protocol

from q_backend.models.runtime import (
    InferenceChunk,
    InferenceRequest,
    InferenceResponse,
    ModelProfile,
    RuntimeHealth,
)


class ModelRuntimeAdapter(Protocol):
    async def load(self, profile: ModelProfile) -> None: ...

    async def unload(self) -> None: ...

    async def health(self) -> RuntimeHealth: ...

    async def generate(self, request: InferenceRequest) -> InferenceResponse: ...

    def stream(self, request: InferenceRequest) -> AsyncIterator[InferenceChunk]: ...

    async def cancel(self, request_id: str) -> None: ...

    async def close(self) -> None: ...
