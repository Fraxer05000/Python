"""Length-bounded loopback client for the Rust supervisor control channel."""

from __future__ import annotations

import asyncio
import json
import socket
from typing import Any, Protocol

from q_backend.errors import QError, QErrorCode
from q_backend.models.lifecycle import LifecycleSnapshot, QState, ResourceSnapshot
from q_backend.models.runtime import ModelProfile, RuntimeConnection, WorkerResult

_MAX_RESPONSE_BYTES = 1_048_576
_MAX_REQUEST_BYTES = 10 * 1024 * 1024


class SupervisorClient(Protocol):
    async def state(self) -> LifecycleSnapshot: ...

    async def resources(self) -> ResourceSnapshot: ...

    async def runtime_connection(self) -> RuntimeConnection | None: ...

    async def start(self, profile: ModelProfile) -> LifecycleSnapshot: ...

    async def sleep(self) -> LifecycleSnapshot: ...

    async def stop(self) -> LifecycleSnapshot: ...

    async def run_worker(
        self,
        kind: str,
        payload: str,
        working_directory: str,
        timeout_seconds: int,
    ) -> WorkerResult: ...

    async def resolve_credential(self, credential_ref: str) -> str: ...


class SocketSupervisorClient:
    def __init__(self, port: int, token: str, *, timeout_seconds: float = 65.0) -> None:
        if not 1 <= port <= 65_535 or len(token) < 32:
            raise QError(
                QErrorCode.RUNTIME_UNAVAILABLE,
                "The supervisor connection is invalid.",
            )
        self._port = port
        self._token = token
        self._timeout_seconds = timeout_seconds

    async def state(self) -> LifecycleSnapshot:
        data = await self._send("state")
        return LifecycleSnapshot.model_validate(data)

    async def resources(self) -> ResourceSnapshot:
        data = await self._send("resources")
        return ResourceSnapshot.model_validate(data)

    async def runtime_connection(self) -> RuntimeConnection | None:
        data = await self._send("runtime_connection")
        if data is None:
            return None
        return RuntimeConnection.model_validate(data)

    async def start(self, profile: ModelProfile) -> LifecycleSnapshot:
        data = await self._send("start", profile=profile.model_dump(mode="json"))
        return LifecycleSnapshot.model_validate(data)

    async def sleep(self) -> LifecycleSnapshot:
        return LifecycleSnapshot.model_validate(await self._send("sleep"))

    async def stop(self) -> LifecycleSnapshot:
        return LifecycleSnapshot.model_validate(await self._send("stop"))

    async def run_worker(
        self,
        kind: str,
        payload: str,
        working_directory: str,
        timeout_seconds: int,
    ) -> WorkerResult:
        data = await self._send(
            "run_worker",
            kind=kind,
            payload=payload,
            working_directory=working_directory,
            timeout_seconds=timeout_seconds,
        )
        return WorkerResult.model_validate(data)

    async def resolve_credential(self, credential_ref: str) -> str:
        data = await self._send("resolve_credential", credential_ref=credential_ref)
        if not isinstance(data, str) or not data:
            raise QError(QErrorCode.RUNTIME_UNAVAILABLE, "Credential could not be resolved.")
        return data

    async def _send(self, action: str, **payload: Any) -> Any:
        request = {"token": self._token, "action": action, **payload}
        return await asyncio.to_thread(self._send_blocking, request)

    def _send_blocking(self, request: dict[str, Any]) -> Any:
        encoded = json.dumps(request, separators=(",", ":")).encode("utf-8") + b"\n"
        if len(encoded) > _MAX_REQUEST_BYTES:
            raise QError(QErrorCode.VALIDATION_ERROR, "Supervisor request is too large.")
        try:
            with socket.create_connection(
                ("127.0.0.1", self._port),
                timeout=self._timeout_seconds,
            ) as connection:
                connection.settimeout(self._timeout_seconds)
                connection.sendall(encoded)
                chunks = bytearray()
                while len(chunks) <= _MAX_RESPONSE_BYTES:
                    chunk = connection.recv(min(65_536, _MAX_RESPONSE_BYTES + 1 - len(chunks)))
                    if not chunk:
                        break
                    chunks.extend(chunk)
                    if b"\n" in chunk:
                        break
        except (OSError, TimeoutError) as exc:
            raise QError(
                QErrorCode.RUNTIME_UNAVAILABLE,
                "The Rust supervisor is unavailable.",
            ) from exc
        if len(chunks) > _MAX_RESPONSE_BYTES:
            raise QError(QErrorCode.INTERNAL_ERROR, "Supervisor response exceeded its limit.")
        try:
            response = json.loads(bytes(chunks).split(b"\n", 1)[0])
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise QError(QErrorCode.INTERNAL_ERROR, "Supervisor returned invalid data.") from exc
        if response.get("status") != "ok":
            error = response.get("error") or {}
            code = _map_error_code(error.get("code"))
            raise QError(code, str(error.get("message") or "Supervisor action failed."))
        return response.get("data")


class OfflineSupervisorClient:
    """Development fallback that never fabricates model availability."""

    async def state(self) -> LifecycleSnapshot:
        return LifecycleSnapshot(state=QState.OFF)

    async def resources(self) -> ResourceSnapshot:
        return ResourceSnapshot(
            q_owned_ram_bytes=0,
            q_owned_cpu_percent=0,
            backend_ram_bytes=0,
            model_ram_bytes=0,
            worker_ram_bytes=0,
            disk_cache_bytes=0,
        )

    async def runtime_connection(self) -> RuntimeConnection | None:
        return None

    async def start(self, profile: ModelProfile) -> LifecycleSnapshot:
        del profile
        raise QError(
            QErrorCode.RUNTIME_UNAVAILABLE,
            "Model lifecycle requires the Tauri/Rust supervisor.",
        )

    async def sleep(self) -> LifecycleSnapshot:
        raise QError(
            QErrorCode.RUNTIME_UNAVAILABLE,
            "Model lifecycle requires the Tauri/Rust supervisor.",
        )

    async def stop(self) -> LifecycleSnapshot:
        return LifecycleSnapshot(state=QState.OFF)

    async def run_worker(
        self,
        kind: str,
        payload: str,
        working_directory: str,
        timeout_seconds: int,
    ) -> WorkerResult:
        del kind, payload, working_directory, timeout_seconds
        raise QError(
            QErrorCode.RUNTIME_UNAVAILABLE,
            "Execution workers require the Tauri/Rust supervisor.",
        )

    async def resolve_credential(self, credential_ref: str) -> str:
        del credential_ref
        raise QError(
            QErrorCode.RUNTIME_UNAVAILABLE,
            "Credential resolution requires Windows Credential Manager.",
        )


def _map_error_code(value: object) -> QErrorCode:
    try:
        return QErrorCode(str(value))
    except ValueError:
        return QErrorCode.RUNTIME_UNAVAILABLE
