"""Project CRUD and explicit filesystem-root authorization."""

from __future__ import annotations

import asyncio
import shutil
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID, uuid4

from sqlalchemy import select

from q_backend.errors import QError, QErrorCode
from q_backend.models.project import (
    AuthorizedRoot,
    AuthorizedRootRequest,
    Project,
    ProjectCreate,
    ProjectDeleteRequest,
    ProjectUpdate,
)
from q_backend.storage.database import AuthorizedRootRow, Database, ProjectRow


class ProjectService:
    def __init__(self, database: Database, workspace: Path) -> None:
        self._database = database
        self._workspace = workspace.resolve()
        self._projects_root = (self._workspace / "Projects").resolve()

    async def create(self, request: ProjectCreate) -> Project:
        return await asyncio.to_thread(self._create_sync, request)

    def _create_sync(self, request: ProjectCreate) -> Project:
        project_id = uuid4()
        now = datetime.now(UTC)
        root = self._projects_root / str(project_id)
        root.mkdir(parents=True, exist_ok=False)
        for directory in ("Inputs", "Outputs", "Knowledge", "Notebooks", "Sandbox"):
            (root / directory).mkdir()
        row = ProjectRow(
            project_id=str(project_id),
            name=request.name.strip(),
            description=request.description,
            root_path=str(root),
            created_at_utc=now.isoformat(),
            updated_at_utc=now.isoformat(),
            deleted=False,
        )
        try:
            with self._database.session() as session:
                session.add(row)
        except Exception:
            shutil.rmtree(root, ignore_errors=True)
            raise
        return _project_from_row(row)

    async def list_projects(self) -> list[Project]:
        return await asyncio.to_thread(self._list_sync)

    def _list_sync(self) -> list[Project]:
        with self._database.session() as session:
            rows = session.scalars(
                select(ProjectRow)
                .where(ProjectRow.deleted.is_(False))
                .order_by(ProjectRow.updated_at_utc.desc())
            ).all()
            return [_project_from_row(row) for row in rows]

    async def get(self, project_id: str | UUID) -> Project:
        return await asyncio.to_thread(self._get_sync, str(project_id))

    def _get_sync(self, project_id: str) -> Project:
        with self._database.session() as session:
            row = session.get(ProjectRow, project_id)
            if row is None or row.deleted:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Project not found.")
            return _project_from_row(row)

    async def update(self, project_id: str | UUID, request: ProjectUpdate) -> Project:
        return await asyncio.to_thread(self._update_sync, str(project_id), request)

    def _update_sync(self, project_id: str, request: ProjectUpdate) -> Project:
        with self._database.session() as session:
            row = session.get(ProjectRow, project_id)
            if row is None or row.deleted:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Project not found.")
            if request.name is not None:
                row.name = request.name.strip()
            if request.description is not None:
                row.description = request.description
            row.updated_at_utc = datetime.now(UTC).isoformat()
            session.flush()
            return _project_from_row(row)

    async def delete(self, project_id: str | UUID, request: ProjectDeleteRequest) -> None:
        if not request.explicit_user_confirmation:
            raise QError(
                QErrorCode.CONFIRMATION_REQUIRED,
                "Deleting a project requires explicit user confirmation.",
            )
        await asyncio.to_thread(self._delete_sync, str(project_id), request)

    def _delete_sync(self, project_id: str, request: ProjectDeleteRequest) -> None:
        root: Path | None = None
        with self._database.session() as session:
            row = session.get(ProjectRow, project_id)
            if row is None or row.deleted:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Project not found.")
            root = Path(row.root_path)
            row.deleted = True
            row.updated_at_utc = datetime.now(UTC).isoformat()
        if request.remove_project_files and root is not None:
            resolved = root.resolve(strict=True)
            if resolved.parent != self._projects_root:
                raise QError(QErrorCode.SANDBOX_VIOLATION, "Project root failed validation.")
            shutil.rmtree(resolved)

    async def add_authorized_root(
        self,
        project_id: str | UUID,
        request: AuthorizedRootRequest,
    ) -> AuthorizedRoot:
        if not request.explicit_user_confirmation:
            raise QError(
                QErrorCode.CONFIRMATION_REQUIRED,
                "Authorizing an external root requires explicit user confirmation.",
            )
        return await asyncio.to_thread(self._add_authorized_root_sync, str(project_id), request)

    def _add_authorized_root_sync(
        self,
        project_id: str,
        request: AuthorizedRootRequest,
    ) -> AuthorizedRoot:
        project = self._get_sync(project_id)
        del project
        raw = Path(request.path)
        if not raw.is_absolute() or _looks_unsafe_windows_path(request.path):
            raise QError(QErrorCode.SANDBOX_VIOLATION, "Authorized root must be a local path.")
        try:
            root = raw.resolve(strict=True)
        except OSError as exc:
            raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Authorized root does not exist.") from exc
        if not root.is_dir() or _is_protected_root(root):
            raise QError(QErrorCode.SANDBOX_VIOLATION, "This root cannot be authorized.")
        row = AuthorizedRootRow(
            root_id=str(uuid4()),
            project_id=project_id,
            root_path=str(root),
            created_at_utc=datetime.now(UTC).isoformat(),
            revoked=False,
        )
        with self._database.session() as session:
            session.add(row)
        return _authorized_root_from_row(row)

    async def roots(self, project_id: str | UUID) -> list[Path]:
        project = await self.get(project_id)
        external = await asyncio.to_thread(self._external_roots_sync, str(project_id))
        return [Path(project.root_path).resolve(), *external]

    def _external_roots_sync(self, project_id: str) -> list[Path]:
        with self._database.session() as session:
            rows = session.scalars(
                select(AuthorizedRootRow).where(
                    AuthorizedRootRow.project_id == project_id,
                    AuthorizedRootRow.revoked.is_(False),
                )
            ).all()
            return [Path(row.root_path).resolve() for row in rows]


def _project_from_row(row: ProjectRow) -> Project:
    return Project(
        project_id=UUID(row.project_id),
        name=row.name,
        description=row.description,
        root_path=row.root_path,
        created_at_utc=datetime.fromisoformat(row.created_at_utc),
        updated_at_utc=datetime.fromisoformat(row.updated_at_utc),
    )


def _authorized_root_from_row(row: AuthorizedRootRow) -> AuthorizedRoot:
    return AuthorizedRoot(
        root_id=UUID(row.root_id),
        project_id=UUID(row.project_id),
        root_path=row.root_path,
        created_at_utc=datetime.fromisoformat(row.created_at_utc),
    )


def _looks_unsafe_windows_path(value: str) -> bool:
    normalized = value.replace("/", "\\").lower()
    return normalized.startswith(("\\\\", "\\?\\", "\\.\\"))


def _is_protected_root(path: Path) -> bool:
    value = str(path).replace("/", "\\").rstrip("\\").lower()
    protected = {
        "c:\\windows",
        "c:\\program files",
        "c:\\program files (x86)",
    }
    return value in protected or path == Path(path.anchor)
