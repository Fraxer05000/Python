"""Runtime configuration with hard security invariants."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, cast

from q_backend.errors import QError, QErrorCode


@dataclass(frozen=True, slots=True)
class Settings:
    environment: str
    bind_host: str
    port: int
    session_token: str
    workspace: Path
    allowed_origins: tuple[str, ...]
    mode: Literal["local_only", "hybrid", "connected"] = "local_only"
    supervisor_port: int | None = None
    supervisor_token: str | None = None
    max_tool_iterations: int = 8
    production: bool = True
    resource_root: Path | None = None

    @property
    def database_path(self) -> Path:
        return self.workspace / "Metadata" / "experimental_q.sqlite3"

    @property
    def audit_log_path(self) -> Path:
        return self.workspace / "Logs" / "audit.jsonl"

    def ensure_directories(self) -> None:
        for relative in ("Projects", "Exports", "Cache", "Logs", "Metadata", "Temp"):
            (self.workspace / relative).mkdir(parents=True, exist_ok=True)

    @classmethod
    def from_environment(cls) -> Settings:
        environment = os.getenv("Q_ENV", "production").strip().lower()
        bind_host = os.getenv("Q_BACKEND_HOST", "127.0.0.1").strip()
        if bind_host not in {"127.0.0.1", "::1", "localhost"}:
            raise QError(
                QErrorCode.PERMISSION_DENIED,
                "The backend may bind only to the loopback interface.",
                details={"bind_host": bind_host},
            )

        raw_port = os.getenv("Q_BACKEND_PORT", "0")
        try:
            port = int(raw_port)
        except ValueError as exc:
            raise QError(
                QErrorCode.VALIDATION_ERROR,
                "Q_BACKEND_PORT must be an integer.",
            ) from exc
        if not 0 <= port <= 65535:
            raise QError(QErrorCode.VALIDATION_ERROR, "Q_BACKEND_PORT is out of range.")

        session_token = os.getenv("Q_SESSION_TOKEN", "")
        minimum_length = 16 if environment == "testing" else 32
        if len(session_token) < minimum_length:
            raise QError(
                QErrorCode.RUNTIME_UNAVAILABLE,
                "A strong per-launch session token was not supplied by the supervisor.",
            )

        workspace = Path(os.getenv("Q_WORKSPACE", str(Path.home() / "ExperimentalQ")))
        raw_mode = os.getenv("Q_MODE", "local_only").strip().lower()
        if raw_mode not in {"local_only", "hybrid", "connected"}:
            raise QError(QErrorCode.VALIDATION_ERROR, "Q_MODE is invalid.")
        raw_supervisor_port = os.getenv("Q_SUPERVISOR_PORT")
        supervisor_port: int | None = None
        if raw_supervisor_port:
            try:
                supervisor_port = int(raw_supervisor_port)
            except ValueError as exc:
                raise QError(
                    QErrorCode.VALIDATION_ERROR,
                    "Q_SUPERVISOR_PORT must be an integer.",
                ) from exc
            if not 1 <= supervisor_port <= 65535:
                raise QError(
                    QErrorCode.VALIDATION_ERROR,
                    "Q_SUPERVISOR_PORT is out of range.",
                )
        supervisor_token = os.getenv("Q_SUPERVISOR_TOKEN")
        if supervisor_port is not None and (supervisor_token is None or len(supervisor_token) < 32):
            raise QError(
                QErrorCode.RUNTIME_UNAVAILABLE,
                "The supervisor control token is missing or weak.",
            )
        origins = tuple(
            item.strip()
            for item in os.getenv(
                "Q_ALLOWED_ORIGINS",
                "tauri://localhost,http://tauri.localhost,https://tauri.localhost",
            ).split(",")
            if item.strip()
        )
        return cls(
            environment=environment,
            bind_host=bind_host,
            port=port,
            session_token=session_token,
            workspace=workspace,
            allowed_origins=origins,
            mode=cast(Literal["local_only", "hybrid", "connected"], raw_mode),
            supervisor_port=supervisor_port,
            supervisor_token=supervisor_token,
            production=environment == "production",
            resource_root=(
                Path(value).resolve()
                if (value := os.getenv("Q_RESOURCE_ROOT"))
                else None
            ),
        )
