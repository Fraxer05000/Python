"""FastAPI application factory and packaged sidecar entry point."""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from q_backend.api.v1.events import events_router
from q_backend.api.v1.router import router
from q_backend.config import Settings
from q_backend.container import build_container
from q_backend.errors import QError, QErrorCode
from q_backend.logging_config import configure_logging

LOGGER = logging.getLogger(__name__)


def create_app(settings: Settings | None = None) -> FastAPI:
    resolved = settings or Settings.from_environment()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        container = build_container(resolved)
        app.state.container = container
        try:
            yield
        finally:
            await container.close()

    app = FastAPI(
        title="Experimental Q Local API",
        version="3.0.0",
        docs_url=None if resolved.environment == "production" else "/docs",
        redoc_url=None,
        openapi_url="/api/v1/openapi.json",
        lifespan=lifespan,
    )
    app.state.settings = resolved
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(resolved.allowed_origins),
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["Authorization", "Content-Type", "X-Correlation-ID"],
    )

    @app.exception_handler(QError)
    async def q_error_handler(_request: Request, exc: QError) -> JSONResponse:
        status_code = _status_for_error(exc)
        return JSONResponse(status_code=status_code, content={"error": exc.as_dict()})

    @app.exception_handler(Exception)
    async def internal_error_handler(_request: Request, exc: Exception) -> JSONResponse:
        error = QError(QErrorCode.INTERNAL_ERROR, "An internal error occurred.")
        LOGGER.exception(
            "Unhandled backend error",
            extra={"context": {"correlation_id": error.correlation_id}},
        )
        return JSONResponse(status_code=500, content={"error": error.as_dict()})

    app.include_router(router)
    app.include_router(events_router)
    return app


def _status_for_error(error: QError) -> int:
    if error.code is QErrorCode.PERMISSION_DENIED:
        return 401 if error.details.get("authentication") is True else 403
    return {
        QErrorCode.VALIDATION_ERROR: 422,
        QErrorCode.CONFIRMATION_REQUIRED: 409,
        QErrorCode.RESOURCE_NOT_FOUND: 404,
        QErrorCode.SANDBOX_VIOLATION: 403,
        QErrorCode.NETWORK_DISABLED: 403,
        QErrorCode.RUNTIME_UNAVAILABLE: 503,
        QErrorCode.MODEL_UNAVAILABLE: 503,
        QErrorCode.TIMEOUT: 504,
        QErrorCode.INTERNAL_ERROR: 500,
    }[error.code]


def run() -> None:
    settings = Settings.from_environment()
    configure_logging(
        secret_values=(settings.session_token, settings.supervisor_token or ""),
    )
    uvicorn.run(
        create_app(settings),
        host=settings.bind_host,
        port=settings.port,
        access_log=settings.environment != "production",
        server_header=False,
    )


if __name__ == "__main__":
    run()
