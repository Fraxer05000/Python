"""Policy decisions derived from the canonical permission policy."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import (
    InvocationIdentity,
    PolicyDecision,
    PolicyOutcome,
)
from q_backend.models.tool import PermissionLevel, ToolDefinition
from q_backend.permissions.manager import PermissionManager


class PolicyEngine:
    def __init__(self, document: dict[str, Any], permissions: PermissionManager) -> None:
        self._document = document
        self._permissions = permissions

    @classmethod
    def from_file(cls, path: Path, permissions: PermissionManager) -> PolicyEngine:
        try:
            document = yaml.safe_load(path.read_text(encoding="utf-8"))
        except (OSError, yaml.YAMLError) as exc:
            raise QError(QErrorCode.VALIDATION_ERROR, "Permission policy is invalid.") from exc
        if not isinstance(document, dict) or document.get("version") != "3.0.0":
            raise QError(QErrorCode.VALIDATION_ERROR, "Permission policy version is invalid.")
        return cls(document, permissions)

    async def evaluate(
        self,
        definition: ToolDefinition,
        arguments: dict[str, object],
        identity: InvocationIdentity,
    ) -> PolicyOutcome:
        if identity.mode not in definition.modes:
            network_tool = definition.permission is PermissionLevel.P3
            return PolicyOutcome(
                decision=PolicyDecision.DENY,
                reason_code="mode_disallows_tool",
                error_code=(
                    QErrorCode.NETWORK_DISABLED.value
                    if network_tool
                    else QErrorCode.PERMISSION_DENIED.value
                ),
            )
        metadata = arguments.get("_policy")
        policy_metadata = metadata if isinstance(metadata, dict) else {}
        resource = policy_metadata.get("resource")
        resource_value = resource if isinstance(resource, str) else None

        if definition.permission is PermissionLevel.P4:
            return PolicyOutcome(
                decision=PolicyDecision.CONFIRM,
                reason_code="destructive_action",
                destructive=True,
            )

        confirmation = definition.confirmation
        if confirmation == "always":
            return PolicyOutcome(
                decision=PolicyDecision.CONFIRM,
                reason_code="confirmation_always",
            )
        if confirmation == "never":
            return PolicyOutcome(decision=PolicyDecision.ALLOW, reason_code="policy_allow")

        if confirmation == "outside_workspace":
            needs_confirmation = bool(policy_metadata.get("outside_workspace"))
        elif confirmation == "outside_workspace_or_overwrite":
            needs_confirmation = bool(
                policy_metadata.get("outside_workspace") or policy_metadata.get("overwrite")
            )
        elif confirmation == "external_database":
            needs_confirmation = bool(policy_metadata.get("external_database"))
        elif confirmation in {"first_use_per_session", "first_use_per_project"}:
            needs_confirmation = not await self._permissions.has_grant(
                definition,
                identity,
                resource_value,
            )
        else:
            raise QError(
                QErrorCode.VALIDATION_ERROR,
                "Tool registry uses an unknown confirmation rule.",
                details={"rule": confirmation},
            )

        if not needs_confirmation:
            return PolicyOutcome(decision=PolicyDecision.ALLOW, reason_code="grant_or_scope_allow")
        return PolicyOutcome(
            decision=PolicyDecision.CONFIRM,
            reason_code=confirmation,
            destructive=False,
        )
