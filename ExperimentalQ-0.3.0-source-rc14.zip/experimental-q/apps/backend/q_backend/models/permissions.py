"""Policy and confirmation wire models."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from uuid import UUID

from pydantic import Field

from q_backend.models.protocol import StrictModel


class ApplicationMode(StrEnum):
    LOCAL_ONLY = "local_only"
    HYBRID = "hybrid"
    CONNECTED = "connected"


class PolicyDecision(StrEnum):
    ALLOW = "allow"
    DENY = "deny"
    CONFIRM = "confirm"


class PolicyOutcome(StrictModel):
    decision: PolicyDecision
    reason_code: str
    destructive: bool = False
    error_code: str | None = None


class InvocationIdentity(StrictModel):
    user_id: str = "local_user"
    session_id: str
    project_id: str | None = None
    mode: ApplicationMode = ApplicationMode.LOCAL_ONLY


class PermissionChallenge(StrictModel):
    challenge_id: str
    confirmation_secret: str
    request_id: str
    tool: str
    action: str
    resource: str | None = None
    reason: str
    destructive: bool
    allowed_scopes: list[str] = Field(default_factory=list)
    expires_at_utc: datetime


class PermissionConfirmation(StrictModel):
    challenge_id: str
    confirmation_secret: str
    allow: bool
    grant_scope: str | None = None
    grant_resource: str | None = None
    expires_at_utc: datetime | None = None


class PermissionGrant(StrictModel):
    grant_id: UUID
    tool_name: str
    scope: str
    resource: str
    created_at_utc: datetime
    expires_at_utc: datetime | None = None
