"""Supervisor lifecycle wire models."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from q_backend.models.protocol import StrictModel


class QState(StrEnum):
    OFF = "OFF"
    STARTING = "STARTING"
    ACTIVE = "ACTIVE"
    SLEEPING = "SLEEPING"
    SLEEP = "SLEEP"
    STOPPING = "STOPPING"
    ERROR = "ERROR"


class LifecycleSnapshot(StrictModel):
    state: QState
    model_profile_id: str | None = None
    last_error: str | None = None


class ResourceSnapshot(StrictModel):
    q_owned_ram_bytes: int = Field(ge=0)
    q_owned_cpu_percent: float = Field(ge=0)
    backend_ram_bytes: int = Field(ge=0)
    model_ram_bytes: int = Field(ge=0)
    worker_ram_bytes: int = Field(ge=0)
    disk_cache_bytes: int = Field(ge=0)
