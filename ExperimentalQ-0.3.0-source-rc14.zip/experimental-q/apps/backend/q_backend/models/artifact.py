"""Generated artifact metadata."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from q_backend.models.protocol import StrictModel


class Artifact(StrictModel):
    artifact_id: UUID
    project_id: UUID | None = None
    path: str
    filename: str
    artifact_type: str
    source_operation: str
    created_at_utc: datetime
    provenance_id: UUID
