"""Typed wire and domain models."""
