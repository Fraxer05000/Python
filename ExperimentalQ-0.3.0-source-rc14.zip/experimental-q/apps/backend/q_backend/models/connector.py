"""Connector metadata containing only opaque credential references."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from uuid import UUID

from pydantic import Field

from q_backend.models.protocol import StrictModel


class ConnectorType(StrEnum):
    GIT_HTTPS = "git_https"


class ConnectorCreate(StrictModel):
    name: str = Field(min_length=1, max_length=160)
    connector_type: ConnectorType
    endpoint: str = Field(min_length=1, max_length=8192)
    username: str | None = Field(default=None, max_length=320)
    credential_ref: str | None = Field(default=None, pattern=r"^[A-Za-z0-9_-]{1,200}$")
    explicit_user_confirmation: bool


class Connector(StrictModel):
    connector_id: UUID
    name: str
    connector_type: ConnectorType
    endpoint: str
    username: str | None = None
    has_credential: bool
    created_at_utc: datetime
    updated_at_utc: datetime
