"""Local microphone transcription models."""

from __future__ import annotations

from pydantic import Field

from q_backend.models.protocol import StrictModel


class TranscriptionResponse(StrictModel):
    text: str
    language: str
    duration_ms: int | None = None


class AudioSettings(StrictModel):
    language: str = Field(default="es", pattern=r"^[a-z]{2}$")
