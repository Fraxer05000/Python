"""Model runtime contracts independent of llama.cpp."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from q_backend.models.lifecycle import QState
from q_backend.models.protocol import StrictModel


class ModelProfile(StrictModel):
    profile_id: str = Field(min_length=1, max_length=100, pattern=r"^[a-zA-Z0-9_-]+$")
    name: str = Field(min_length=1, max_length=120)
    runtime: Literal["llama_cpp", "ollama", "onnx", "transformers", "custom"] = "llama_cpp"
    model_path: str = Field(min_length=1, max_length=32_767)
    context_length: int = Field(default=32_768, ge=1_024, le=1_048_576)
    threads: int = Field(default=8, ge=1, le=512)
    batch_size: int = Field(default=512, ge=1, le=65_536)
    gpu_layers: int = Field(default=0, ge=0, le=10_000)
    temperature: float = Field(default=0.2, ge=0, le=2)
    tool_calling: bool = True
    vision: bool = False

    @model_validator(mode="after")
    def require_gguf_for_llama_cpp(self) -> ModelProfile:
        if self.runtime == "llama_cpp" and not self.model_path.lower().endswith(".gguf"):
            raise ValueError("llama.cpp profiles require a .gguf model file")
        return self


class ChatMessage(StrictModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: str | None = None
    name: str | None = None
    tool_call_id: str | None = None
    tool_calls: list[dict[str, Any]] | None = None


class InferenceRequest(StrictModel):
    request_id: str
    messages: Sequence[ChatMessage]
    tools: list[dict[str, Any]] = Field(default_factory=list)
    temperature: float | None = Field(default=None, ge=0, le=2)
    max_tokens: int | None = Field(default=None, ge=1)
    seed: int | None = None


class ToolCall(StrictModel):
    id: str
    name: str
    arguments: dict[str, Any]


class InferenceResponse(StrictModel):
    request_id: str
    content: str | None
    tool_calls: list[ToolCall] = Field(default_factory=list)
    finish_reason: str | None = None
    usage: dict[str, int] = Field(default_factory=dict)


class InferenceChunk(StrictModel):
    request_id: str
    content_delta: str = ""
    finish_reason: str | None = None


class RuntimeHealth(StrictModel):
    state: QState
    healthy: bool
    detail: str | None = None


class RuntimeConnection(StrictModel):
    host: Literal["127.0.0.1"]
    port: int = Field(ge=1, le=65_535)
    api_key: str | None = None


class WorkerResult(StrictModel):
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False
