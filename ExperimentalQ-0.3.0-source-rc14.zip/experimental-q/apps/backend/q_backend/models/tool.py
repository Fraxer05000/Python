"""Canonical ToolRequest, ToolResult, and registry models."""

from __future__ import annotations

from enum import StrEnum
from typing import Any
from uuid import UUID

from pydantic import Field

from q_backend.models.permissions import ApplicationMode
from q_backend.models.protocol import ErrorBody, StrictModel


class ToolStatus(StrEnum):
    OK = "ok"
    ERROR = "error"
    CONFIRMATION_REQUIRED = "confirmation_required"


class ToolRequest(StrictModel):
    request_id: UUID
    tool: str = Field(pattern=r"^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$")
    arguments: dict[str, Any]
    reason: str = Field(min_length=1, max_length=300)
    project_id: UUID | None = None


class ToolResult(StrictModel):
    request_id: UUID
    status: ToolStatus
    data: Any = None
    error: ErrorBody | None = None
    audit_id: str | None = None
    provenance_id: str | None = None


class PermissionLevel(StrEnum):
    P0 = "P0"
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"
    P4 = "P4"


class ToolDefinition(StrictModel):
    name: str = Field(pattern=r"^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$")
    controller: str = Field(min_length=1)
    method: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    permission: PermissionLevel
    confirmation: str
    modes: list[ApplicationMode]
    arguments_schema: dict[str, Any] = Field(default_factory=lambda: {"type": "object"})


class ToolRegistryDocument(StrictModel):
    version: str
    tools: list[ToolDefinition]
