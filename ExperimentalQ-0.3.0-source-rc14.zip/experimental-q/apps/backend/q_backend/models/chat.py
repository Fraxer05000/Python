"""Chat orchestration wire models."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from uuid import UUID

from pydantic import Field

from q_backend.models.protocol import StrictModel
from q_backend.models.tool import ToolResult


class ChatTurnStatus(StrEnum):
    COMPLETED = "completed"
    CONFIRMATION_REQUIRED = "confirmation_required"


class ChatSessionCreate(StrictModel):
    project_id: UUID | None = None
    title: str = Field(default="Nueva conversación", min_length=1, max_length=200)


class ChatSession(StrictModel):
    session_id: UUID
    project_id: UUID | None = None
    title: str
    created_at_utc: datetime
    updated_at_utc: datetime


class ChatTurnRequest(StrictModel):
    session_id: UUID
    project_id: UUID | None = None
    message: str = Field(min_length=1, max_length=100_000)


class ChatAction(StrictModel):
    tool: str
    reason: str
    status: str
    audit_id: str | None = None
    provenance_id: str | None = None


class ChatTurnResponse(StrictModel):
    turn_id: UUID
    session_id: UUID
    status: ChatTurnStatus
    answer: str | None = None
    actions: list[ChatAction] = Field(default_factory=list)
    pending_tool_result: ToolResult | None = None


class ChatMessageView(StrictModel):
    message_id: UUID
    role: str
    content: str
    tool_name: str | None = None
    created_at_utc: datetime
