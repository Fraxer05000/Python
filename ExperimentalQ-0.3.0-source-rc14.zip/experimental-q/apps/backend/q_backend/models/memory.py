"""Persistent memory and local knowledge models."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from uuid import UUID

from pydantic import Field

from q_backend.models.protocol import StrictModel


class MemoryScope(StrEnum):
    USER = "user"
    PROJECT = "project"
    KNOWLEDGE = "knowledge"


class MemoryRecord(StrictModel):
    memory_id: UUID
    scope: MemoryScope
    project_id: UUID | None = None
    content: str
    source: str
    sensitivity: bool
    created_at_utc: datetime
    updated_at_utc: datetime


class MemorySearchResult(StrictModel):
    record: MemoryRecord
    score: float = Field(ge=0, le=1)


class KnowledgeIndexRequest(StrictModel):
    project_id: UUID
    source: str = Field(min_length=1, max_length=32767)
    content: str = Field(min_length=1, max_length=5_000_000)
    explicit_user_confirmation: bool


class KnowledgeIndexResult(StrictModel):
    memory_ids: list[UUID]
    chunk_count: int
