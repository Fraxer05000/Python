"""Project and authorized-root API models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import Field

from q_backend.models.protocol import StrictModel


class ProjectCreate(StrictModel):
    name: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=4_000)


class ProjectUpdate(StrictModel):
    name: str | None = Field(default=None, min_length=1, max_length=160)
    description: str | None = Field(default=None, max_length=4_000)


class Project(StrictModel):
    project_id: UUID
    name: str
    description: str
    root_path: str
    created_at_utc: datetime
    updated_at_utc: datetime


class AuthorizedRootRequest(StrictModel):
    path: str = Field(min_length=1, max_length=32_767)
    explicit_user_confirmation: bool


class AuthorizedRoot(StrictModel):
    root_id: UUID
    project_id: UUID
    root_path: str
    created_at_utc: datetime


class ProjectDeleteRequest(StrictModel):
    remove_project_files: bool = False
    explicit_user_confirmation: bool
