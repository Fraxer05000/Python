"""Q Notebook models."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any
from uuid import UUID

from pydantic import Field

from q_backend.models.protocol import StrictModel


class CellType(StrEnum):
    PROMPT = "prompt"
    CODE = "code"
    MARKDOWN = "markdown"
    SQL = "sql"
    R = "r"


class NotebookCreate(StrictModel):
    project_id: UUID
    title: str = Field(min_length=1, max_length=200)


class CellCreate(StrictModel):
    cell_type: CellType
    content: str = Field(max_length=1_000_000)


class CellUpdate(StrictModel):
    content: str | None = Field(default=None, max_length=1_000_000)
    position: int | None = Field(default=None, ge=0, le=100_000)


class NotebookCell(StrictModel):
    cell_id: UUID
    position: int
    cell_type: CellType
    content: str
    output: dict[str, Any] | None = None
    created_at_utc: datetime
    updated_at_utc: datetime


class Notebook(StrictModel):
    notebook_id: UUID
    project_id: UUID
    title: str
    cells: list[NotebookCell] = Field(default_factory=list)
    created_at_utc: datetime
    updated_at_utc: datetime


class CellExecuteRequest(StrictModel):
    session_id: UUID
    mode: str = "local_only"


class CellExecutionResult(StrictModel):
    cell_id: UUID
    status: str
    output: dict[str, Any]
