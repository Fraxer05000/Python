"""M0 API models."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class HealthResponse(StrictModel):
    status: Literal["ok"] = "ok"
    service: Literal["experimental-q-backend"] = "experimental-q-backend"
    api_version: Literal["v1"] = "v1"
    q_state: Literal["OFF", "STARTING", "ACTIVE", "SLEEPING", "SLEEP", "STOPPING", "ERROR"] = "OFF"
    timestamp_utc: datetime = Field(default_factory=lambda: datetime.now(UTC))


class ErrorBody(StrictModel):
    code: str
    message: str
    details: dict[str, Any]
    correlation_id: str


class ErrorEnvelope(StrictModel):
    error: ErrorBody


class ModelStartRequest(StrictModel):
    profile_id: str = Field(min_length=1, max_length=100)


class OperationAccepted(StrictModel):
    status: Literal["accepted"] = "accepted"
    state: str


class CancelledResponse(StrictModel):
    status: Literal["cancelled"] = "cancelled"
