"""External connector metadata services."""
