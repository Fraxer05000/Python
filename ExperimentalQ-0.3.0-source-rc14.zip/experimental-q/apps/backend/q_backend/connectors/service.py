"""Connector CRUD; secrets remain in the native credential vault."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import UTC, datetime
from uuid import UUID, uuid4

from sqlalchemy import select

from q_backend.controllers.web import validate_https_url_syntax
from q_backend.errors import QError, QErrorCode
from q_backend.models.connector import Connector, ConnectorCreate, ConnectorType
from q_backend.storage.database import ConnectorRow, Database


@dataclass(frozen=True, slots=True)
class ResolvedConnector:
    connector: Connector
    endpoint: str
    username: str | None
    credential_ref: str | None


class ConnectorService:
    def __init__(self, database: Database) -> None:
        self._database = database

    async def create(self, request: ConnectorCreate) -> Connector:
        if not request.explicit_user_confirmation:
            raise QError(
                QErrorCode.CONFIRMATION_REQUIRED,
                "Creating a connector requires explicit user confirmation.",
            )
        if request.connector_type is ConnectorType.GIT_HTTPS:
            validate_https_url_syntax(request.endpoint)
        return await asyncio.to_thread(self._create_sync, request)

    def _create_sync(self, request: ConnectorCreate) -> Connector:
        now = datetime.now(UTC).isoformat()
        row = ConnectorRow(
            connector_id=str(uuid4()),
            name=request.name,
            connector_type=request.connector_type.value,
            endpoint=request.endpoint,
            username=request.username,
            credential_ref=request.credential_ref,
            created_at_utc=now,
            updated_at_utc=now,
            revoked=False,
        )
        with self._database.session() as session:
            session.add(row)
        return _connector(row)

    async def list_connectors(self) -> list[Connector]:
        return await asyncio.to_thread(self._list_sync)

    def _list_sync(self) -> list[Connector]:
        with self._database.session() as session:
            rows = session.scalars(
                select(ConnectorRow)
                .where(ConnectorRow.revoked.is_(False))
                .order_by(ConnectorRow.name.asc())
            ).all()
            return [_connector(row) for row in rows]

    async def resolve(self, connector_id: UUID | str) -> ResolvedConnector:
        return await asyncio.to_thread(self._resolve_sync, str(connector_id))

    def _resolve_sync(self, connector_id: str) -> ResolvedConnector:
        with self._database.session() as session:
            row = session.get(ConnectorRow, connector_id)
            if row is None or row.revoked:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Connector not found.")
            return ResolvedConnector(
                connector=_connector(row),
                endpoint=row.endpoint,
                username=row.username,
                credential_ref=row.credential_ref,
            )

    async def revoke(self, connector_id: UUID) -> None:
        await asyncio.to_thread(self._revoke_sync, str(connector_id))

    def _revoke_sync(self, connector_id: str) -> None:
        with self._database.session() as session:
            row = session.get(ConnectorRow, connector_id)
            if row is None:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Connector not found.")
            row.revoked = True
            row.updated_at_utc = datetime.now(UTC).isoformat()


def _connector(row: ConnectorRow) -> Connector:
    return Connector(
        connector_id=UUID(row.connector_id),
        name=row.name,
        connector_type=ConnectorType(row.connector_type),
        endpoint=row.endpoint,
        username=row.username,
        has_credential=row.credential_ref is not None,
        created_at_utc=datetime.fromisoformat(row.created_at_utc),
        updated_at_utc=datetime.fromisoformat(row.updated_at_utc),
    )
