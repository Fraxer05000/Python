"""Single-orchestrator tool loop."""
