"""Persistent single-agent chat loop with mandatory ToolManager dispatch."""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Literal, cast
from uuid import UUID, uuid4

from pydantic import ValidationError
from sqlalchemy import select

from q_backend.errors import QError, QErrorCode
from q_backend.memory.service import MemoryService
from q_backend.models.chat import (
    ChatAction,
    ChatMessageView,
    ChatSession,
    ChatSessionCreate,
    ChatTurnRequest,
    ChatTurnResponse,
    ChatTurnStatus,
)
from q_backend.models.permissions import ApplicationMode, InvocationIdentity
from q_backend.models.runtime import ChatMessage, InferenceRequest, InferenceResponse
from q_backend.models.tool import ToolRequest, ToolResult, ToolStatus
from q_backend.orchestrator.context import ContextBuilder
from q_backend.runtimes.base import ModelRuntimeAdapter
from q_backend.storage.database import ChatMessageRow, ChatSessionRow, Database
from q_backend.tools.manager import ToolManager


@dataclass(slots=True)
class PendingTurn:
    session_id: UUID
    project_id: str | None
    turn_id: UUID
    call_id: str
    tool_name: str
    request_id: UUID
    messages: list[ChatMessage]
    actions: list[ChatAction]
    next_iteration: int


class ChatOrchestrator:
    def __init__(
        self,
        database: Database,
        runtime: ModelRuntimeAdapter,
        tools: ToolManager,
        context: ContextBuilder,
        memory: MemoryService,
        *,
        mode: ApplicationMode,
        max_tool_iterations: int,
    ) -> None:
        self._database = database
        self._runtime = runtime
        self._tools = tools
        self._context = context
        self._memory = memory
        self._mode = mode
        self._max_tool_iterations = max_tool_iterations
        self._session_locks: dict[str, asyncio.Lock] = {}
        self._pending: dict[str, PendingTurn] = {}

    async def create_session(self, request: ChatSessionCreate) -> ChatSession:
        return await asyncio.to_thread(self._create_session_sync, request)

    def _create_session_sync(self, request: ChatSessionCreate) -> ChatSession:
        now = datetime.now(UTC)
        row = ChatSessionRow(
            session_id=str(uuid4()),
            project_id=str(request.project_id) if request.project_id else None,
            title=request.title,
            created_at_utc=now.isoformat(),
            updated_at_utc=now.isoformat(),
        )
        with self._database.session() as session:
            session.add(row)
        return _session_from_row(row)

    async def sessions(self) -> list[ChatSession]:
        return await asyncio.to_thread(self._sessions_sync)

    def _sessions_sync(self) -> list[ChatSession]:
        with self._database.session() as session:
            rows = session.scalars(
                select(ChatSessionRow).order_by(ChatSessionRow.updated_at_utc.desc())
            ).all()
            return [_session_from_row(row) for row in rows]

    async def messages(self, session_id: UUID) -> list[ChatMessageView]:
        return await asyncio.to_thread(self._message_views_sync, str(session_id))

    def _message_views_sync(self, session_id: str) -> list[ChatMessageView]:
        self._required_session_sync(session_id)
        with self._database.session() as session:
            rows = session.scalars(
                select(ChatMessageRow)
                .where(ChatMessageRow.session_id == session_id)
                .order_by(ChatMessageRow.created_at_utc.asc())
            ).all()
            return [
                ChatMessageView(
                    message_id=UUID(row.message_id),
                    role=row.role,
                    content=row.content,
                    tool_name=row.tool_name,
                    created_at_utc=datetime.fromisoformat(row.created_at_utc),
                )
                for row in rows
            ]

    async def turn(self, request: ChatTurnRequest) -> ChatTurnResponse:
        lock = self._session_locks.setdefault(str(request.session_id), asyncio.Lock())
        async with lock:
            return await self._turn_locked(request)

    async def _turn_locked(self, request: ChatTurnRequest) -> ChatTurnResponse:
        session_id = str(request.session_id)
        requested_project = str(request.project_id) if request.project_id else None
        stored_project_id = await asyncio.to_thread(
            self._validate_session_sync,
            session_id,
            requested_project,
        )
        await asyncio.to_thread(
            self._append_message_sync,
            session_id,
            "user",
            request.message,
            None,
            None,
            None,
        )
        history = await asyncio.to_thread(self._history_sync, session_id)
        retrieved = await self._memory.context(request.message, stored_project_id)
        snippets = [
            f"[{item.record.scope.value}:{item.record.source}] {item.record.content}"
            for item in retrieved
        ]
        messages = self._context.build(history, stored_project_id, snippets)
        return await self._run_loop(
            session_id=session_id,
            session_uuid=request.session_id,
            project_id=stored_project_id,
            messages=messages,
            actions=[],
            turn_id=uuid4(),
            start_iteration=0,
        )

    async def _run_loop(
        self,
        *,
        session_id: str,
        session_uuid: UUID,
        project_id: str | None,
        messages: list[ChatMessage],
        actions: list[ChatAction],
        turn_id: UUID,
        start_iteration: int,
    ) -> ChatTurnResponse:
        for iteration in range(start_iteration, self._max_tool_iterations + 1):
            response = await self._runtime.generate(
                InferenceRequest(
                    request_id=str(turn_id),
                    messages=messages,
                    tools=[self._tools.model_tool_contract()],
                )
            )
            if not response.tool_calls:
                answer = (response.content or "").strip()
                if not answer:
                    raise QError(QErrorCode.INTERNAL_ERROR, "Q returned an empty response.")
                await asyncio.to_thread(
                    self._append_message_sync,
                    session_id,
                    "assistant",
                    answer,
                    None,
                    None,
                    None,
                )
                return ChatTurnResponse(
                    turn_id=turn_id,
                    session_id=session_uuid,
                    status=ChatTurnStatus.COMPLETED,
                    answer=answer,
                    actions=actions,
                )
            if iteration >= self._max_tool_iterations:
                raise QError(QErrorCode.TIMEOUT, "Q exceeded the tool iteration limit.")
            if len(response.tool_calls) != 1:
                raise QError(
                    QErrorCode.VALIDATION_ERROR,
                    "Q must request exactly one controller action at a time.",
                )
            assistant_message = self._assistant_tool_message(response)
            messages.append(assistant_message)
            await asyncio.to_thread(
                self._append_message_sync,
                session_id,
                "assistant",
                response.content or "",
                None,
                None,
                json.dumps(assistant_message.tool_calls, separators=(",", ":")),
            )
            for call in response.tool_calls:
                tool_request = self._validate_tool_call(
                    call.name,
                    call.arguments,
                    project_id,
                )
                identity = InvocationIdentity(
                    session_id=session_id,
                    project_id=project_id,
                    mode=self._mode,
                )
                result = await self._tools.invoke(tool_request, identity)
                actions.append(
                    ChatAction(
                        tool=tool_request.tool,
                        reason=tool_request.reason,
                        status=result.status.value,
                        audit_id=result.audit_id,
                        provenance_id=result.provenance_id,
                    )
                )
                if result.status is ToolStatus.CONFIRMATION_REQUIRED:
                    challenge_id = _challenge_id(result)
                    self._pending[challenge_id] = PendingTurn(
                        session_id=session_uuid,
                        project_id=project_id,
                        turn_id=turn_id,
                        call_id=call.id,
                        tool_name=tool_request.tool,
                        request_id=tool_request.request_id,
                        messages=list(messages),
                        actions=list(actions),
                        next_iteration=iteration + 1,
                    )
                    return ChatTurnResponse(
                        turn_id=turn_id,
                        session_id=session_uuid,
                        status=ChatTurnStatus.CONFIRMATION_REQUIRED,
                        actions=actions,
                        pending_tool_result=result,
                    )
                safe_result = result.model_dump_json(exclude_none=True)
                messages.append(
                    ChatMessage(
                        role="tool",
                        name=tool_request.tool,
                        tool_call_id=call.id,
                        content=safe_result,
                    )
                )
                await asyncio.to_thread(
                    self._append_message_sync,
                    session_id,
                    "tool",
                    safe_result,
                    tool_request.tool,
                    call.id,
                    None,
                )
        raise QError(QErrorCode.INTERNAL_ERROR, "Unreachable orchestrator state.")

    async def resume_confirmation(
        self,
        challenge_id: str,
        result: ToolResult,
    ) -> ChatTurnResponse:
        pending = self._pending.pop(challenge_id, None)
        if pending is None:
            raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Pending chat confirmation not found.")
        session_id = str(pending.session_id)
        lock = self._session_locks.setdefault(session_id, asyncio.Lock())
        async with lock:
            safe_result = result.model_dump_json(exclude_none=True)
            pending.messages.append(
                ChatMessage(
                    role="tool",
                    name=pending.tool_name,
                    tool_call_id=pending.call_id,
                    content=safe_result,
                )
            )
            await asyncio.to_thread(
                self._append_message_sync,
                session_id,
                "tool",
                safe_result,
                pending.tool_name,
                pending.call_id,
                None,
            )
            return await self._run_loop(
                session_id=session_id,
                session_uuid=pending.session_id,
                project_id=pending.project_id,
                messages=pending.messages,
                actions=pending.actions,
                turn_id=pending.turn_id,
                start_iteration=pending.next_iteration,
            )

    def pending_request_id(self, challenge_id: str) -> UUID:
        pending = self._pending.get(challenge_id)
        if pending is None:
            raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Pending chat confirmation not found.")
        return pending.request_id

    async def cancel(self, request_id: str) -> None:
        await self._runtime.cancel(request_id)

    @staticmethod
    def _assistant_tool_message(response: InferenceResponse) -> ChatMessage:
        calls = [
            {
                "id": call.id,
                "type": "function",
                "function": {
                    "name": call.name,
                    "arguments": json.dumps(call.arguments, separators=(",", ":")),
                },
            }
            for call in response.tool_calls
        ]
        return ChatMessage(role="assistant", content=response.content, tool_calls=calls)

    @staticmethod
    def _validate_tool_call(
        call_name: str,
        arguments: dict[str, Any],
        active_project_id: str | None,
    ) -> ToolRequest:
        if call_name != "q_tool_request":
            raise QError(QErrorCode.VALIDATION_ERROR, "Q emitted an unknown function call.")
        try:
            request = ToolRequest.model_validate(arguments)
        except ValidationError as exc:
            raise QError(
                QErrorCode.VALIDATION_ERROR,
                "Q emitted an invalid canonical ToolRequest.",
            ) from exc
        requested_project = str(request.project_id) if request.project_id else None
        if requested_project != active_project_id:
            raise QError(
                QErrorCode.PERMISSION_DENIED,
                "Q cannot change the active project scope.",
            )
        return request

    def _required_session_sync(self, session_id: str) -> ChatSessionRow:
        with self._database.session() as session:
            row = session.get(ChatSessionRow, session_id)
            if row is None:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Chat session not found.")
            session.expunge(row)
            return row

    def _validate_session_sync(self, session_id: str, project_id: str | None) -> str | None:
        row = self._required_session_sync(session_id)
        if row.project_id != project_id:
            raise QError(
                QErrorCode.PERMISSION_DENIED,
                "Chat session project scope cannot be changed.",
            )
        return row.project_id

    def _history_sync(self, session_id: str) -> list[ChatMessage]:
        with self._database.session() as session:
            rows = session.scalars(
                select(ChatMessageRow)
                .where(ChatMessageRow.session_id == session_id)
                .order_by(ChatMessageRow.created_at_utc.asc())
            ).all()
            messages: list[ChatMessage] = []
            for row in rows:
                raw_calls = json.loads(row.tool_calls_json) if row.tool_calls_json else None
                if raw_calls is not None and not isinstance(raw_calls, list):
                    raise QError(QErrorCode.INTERNAL_ERROR, "Stored tool calls are invalid.")
                messages.append(
                    ChatMessage(
                        role=_role(row.role),
                        content=row.content,
                        name=row.tool_name,
                        tool_call_id=row.tool_call_id,
                        tool_calls=cast(list[dict[str, Any]] | None, raw_calls),
                    )
                )
            return messages

    def _append_message_sync(
        self,
        session_id: str,
        role: str,
        content: str,
        tool_name: str | None,
        tool_call_id: str | None,
        tool_calls_json: str | None,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        with self._database.session() as session:
            chat = session.get(ChatSessionRow, session_id)
            if chat is None:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Chat session not found.")
            chat.updated_at_utc = now
            session.add(
                ChatMessageRow(
                    message_id=str(uuid4()),
                    session_id=session_id,
                    role=role,
                    content=content,
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    tool_calls_json=tool_calls_json,
                    created_at_utc=now,
                )
            )


def _session_from_row(row: ChatSessionRow) -> ChatSession:
    return ChatSession(
        session_id=UUID(row.session_id),
        project_id=UUID(row.project_id) if row.project_id else None,
        title=row.title,
        created_at_utc=datetime.fromisoformat(row.created_at_utc),
        updated_at_utc=datetime.fromisoformat(row.updated_at_utc),
    )


def _role(value: str) -> Literal["system", "user", "assistant", "tool"]:
    if value not in {"system", "user", "assistant", "tool"}:
        raise QError(QErrorCode.INTERNAL_ERROR, "Stored chat role is invalid.")
    return cast(Literal["system", "user", "assistant", "tool"], value)


def _challenge_id(result: ToolResult) -> str:
    if not isinstance(result.data, dict):
        raise QError(QErrorCode.INTERNAL_ERROR, "Confirmation challenge is invalid.")
    value = result.data.get("challenge_id")
    if not isinstance(value, str):
        raise QError(QErrorCode.INTERNAL_ERROR, "Confirmation challenge has no identifier.")
    return value
