"""Hash-chained audit events with redacted structured details."""

from __future__ import annotations

import asyncio
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

from sqlalchemy import select

from q_backend.logging_config import redact
from q_backend.models.permissions import InvocationIdentity, PolicyOutcome
from q_backend.models.tool import ToolDefinition, ToolRequest
from q_backend.storage.database import AuditRow, Database


class AuditService:
    def __init__(self, database: Database, log_path: Path) -> None:
        self._database = database
        self._log_path = log_path
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()

    async def record_tool_decision(
        self,
        request: ToolRequest,
        definition: ToolDefinition,
        identity: InvocationIdentity,
        outcome: PolicyOutcome,
        result: str,
        resource: str | None = None,
    ) -> str:
        return await self.record(
            actor="model_q",
            action=definition.name,
            resource=resource,
            decision=outcome.decision.value,
            result=result,
            correlation_id=str(request.request_id),
            details={
                "permission": definition.permission.value,
                "reason_code": outcome.reason_code,
                "project_id": identity.project_id,
                "session_id": identity.session_id,
            },
        )

    async def record(
        self,
        *,
        actor: str,
        action: str,
        resource: str | None,
        decision: str,
        result: str,
        correlation_id: str,
        details: dict[str, Any] | None = None,
    ) -> str:
        async with self._lock:
            return await asyncio.to_thread(
                self._record_sync,
                actor,
                action,
                resource,
                decision,
                result,
                correlation_id,
                details or {},
            )

    def _record_sync(
        self,
        actor: str,
        action: str,
        resource: str | None,
        decision: str,
        result: str,
        correlation_id: str,
        details: dict[str, Any],
    ) -> str:
        event_id = str(uuid4())
        timestamp = datetime.now(UTC).isoformat()
        safe_details = redact(details)
        with self._database.session() as session:
            previous = session.scalar(
                select(AuditRow).order_by(AuditRow.timestamp_utc.desc()).limit(1)
            )
            previous_hash = previous.event_hash if previous else ""
            payload = {
                "event_id": event_id,
                "timestamp_utc": timestamp,
                "actor": actor,
                "action": action,
                "resource": resource,
                "decision": decision,
                "result": result,
                "correlation_id": correlation_id,
                "details": safe_details,
                "previous_hash": previous_hash,
            }
            canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
            event_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
            session.add(
                AuditRow(
                    event_id=event_id,
                    timestamp_utc=timestamp,
                    actor=actor,
                    action=action,
                    resource=resource,
                    decision=decision,
                    result=result,
                    correlation_id=correlation_id,
                    details_json=json.dumps(safe_details, separators=(",", ":")),
                    previous_hash=previous_hash,
                    event_hash=event_hash,
                )
            )
            payload["event_hash"] = event_hash
        with self._log_path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
            stream.write("\n")
        return event_id
