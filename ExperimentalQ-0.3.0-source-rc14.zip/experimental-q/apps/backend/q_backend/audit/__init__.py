"""Append-only application audit service."""

from q_backend.audit.service import AuditService

__all__ = ["AuditService"]
