"""Allowlisted structured scientific Python operations."""

from __future__ import annotations

from typing import Any

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.python_sandbox import PythonSandbox
from q_backend.controllers.scientific import ScientificController
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity


class StructuredPythonController(BaseController):
    def __init__(self, scientific: ScientificController, sandbox: PythonSandbox) -> None:
        self._scientific = scientific
        self._sandbox = sandbox

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method == "run_structured":
            return self._scientific.argument_schema("analyze")
        if method == "run_code":
            return {
                "$schema": "https://json-schema.org/draft/2020-12/schema",
                "type": "object",
                "required": ["code"],
                "properties": {
                    "code": {"type": "string", "minLength": 1, "maxLength": 1000000},
                    "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120},
                },
                "additionalProperties": False,
            }
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown PythonController method.")

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        if method == "run_code":
            return await self._sandbox.normalize(arguments, identity)
        return arguments

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        if method == "run_structured":
            return await self._scientific.invoke("analyze", arguments, identity)
        if method == "run_code":
            return await self._sandbox.run(arguments)
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown PythonController method.")
