"""PDF extraction and generation through dedicated non-Office renderers."""

from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
from typing import Any

from pypdf import PdfReader
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.path_policy import PathPolicy
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity


class PDFController(BaseController):
    def __init__(self, paths: PathPolicy) -> None:
        self._paths = paths

    def argument_schema(self, method: str) -> dict[str, Any]:
        path = {"type": "string", "maxLength": 32767}
        if method == "read":
            return _schema(
                {
                    "path": path,
                    "start_page": {"type": "integer", "minimum": 1},
                    "max_pages": {"type": "integer", "minimum": 1, "maximum": 500},
                },
                ["path"],
            )
        if method == "create":
            return _schema(
                {
                    "path": path,
                    "title": {"type": "string", "maxLength": 500},
                    "paragraphs": {
                        "type": "array",
                        "items": {"type": "string", "maxLength": 100000},
                        "maxItems": 5000,
                    },
                },
                ["path", "title", "paragraphs"],
            )
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown PDFController method.")

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        resolved = await self._paths.resolve(
            str(arguments["path"]), identity, must_exist=method == "read"
        )
        if resolved.path.suffix.lower() != ".pdf":
            raise QError(QErrorCode.VALIDATION_ERROR, "PDF path must use .pdf.")
        normalized = dict(arguments)
        normalized["path"] = str(resolved.path)
        normalized["_policy"] = {
            "resource": str(resolved.path),
            "outside_workspace": resolved.outside_workspace,
            "overwrite": resolved.path.exists(),
        }
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        if method == "read":
            return await asyncio.to_thread(self._read, arguments)
        if method == "create":
            return await asyncio.to_thread(self._create, arguments)
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown PDFController method.")

    @staticmethod
    def _read(arguments: dict[str, Any]) -> ControllerResult:
        path = Path(str(arguments["path"]))
        reader = PdfReader(path)
        start = int(arguments.get("start_page", 1)) - 1
        maximum = int(arguments.get("max_pages", 100))
        if start >= len(reader.pages):
            raise QError(QErrorCode.VALIDATION_ERROR, "start_page exceeds PDF length.")
        selected = reader.pages[start : start + maximum]
        pages = [
            {"page": start + index + 1, "text": page.extract_text() or ""}
            for index, page in enumerate(selected)
        ]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        return ControllerResult(
            data={"total_pages": len(reader.pages), "pages": pages, "sha256": digest},
            resource=str(path),
            provenance_inputs=[{"path": str(path), "sha256": digest}],
        )

    @staticmethod
    def _create(arguments: dict[str, Any]) -> ControllerResult:
        path = Path(str(arguments["path"]))
        if path.exists():
            raise QError(QErrorCode.VALIDATION_ERROR, "PDF creation never overwrites.")
        document = SimpleDocTemplate(
            str(path),
            pagesize=A4,
            rightMargin=22 * mm,
            leftMargin=22 * mm,
            topMargin=20 * mm,
            bottomMargin=20 * mm,
            title=str(arguments["title"]),
        )
        styles = getSampleStyleSheet()
        story: list[Any] = [Paragraph(str(arguments["title"]), styles["Title"]), Spacer(1, 8 * mm)]
        for paragraph in arguments["paragraphs"]:
            story.extend([Paragraph(str(paragraph), styles["BodyText"]), Spacer(1, 4 * mm)])
        document.build(story)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        return ControllerResult(
            data={"path": str(path), "sha256": digest, "format": "pdf"},
            resource=str(path),
            provenance_outputs=[{"path": str(path), "sha256": digest}],
            provenance_parameters={"title": str(arguments["title"])},
        )


def _schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }
