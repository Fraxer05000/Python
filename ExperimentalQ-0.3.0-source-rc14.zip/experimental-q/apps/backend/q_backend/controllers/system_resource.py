"""Read-only application-owned resource observation."""

from __future__ import annotations

from typing import Any

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity
from q_backend.supervisor.client import SupervisorClient


class SystemResourceController(BaseController):
    def __init__(self, supervisor: SupervisorClient) -> None:
        self._supervisor = supervisor

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method != "snapshot":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown resource method.")
        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        }

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del arguments, identity
        if method != "snapshot":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown resource method.")
        snapshot = await self._supervisor.resources()
        return ControllerResult(data=snapshot.model_dump(mode="json"))
