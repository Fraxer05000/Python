"""Typed OS-resource controllers."""

from q_backend.controllers.base import BaseController, ControllerResult

__all__ = ["BaseController", "ControllerResult"]
