"""Scientific figure export using bounded, structured chart specifications."""

from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt  # noqa: E402

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.path_policy import PathPolicy
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity


class VisualizationController(BaseController):
    def __init__(self, paths: PathPolicy) -> None:
        self._paths = paths
        self._lock = asyncio.Lock()

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method != "create":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown visualization method.")
        values = {
            "type": "array",
            "items": {"type": "number"},
            "maxItems": 1000000,
        }
        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "required": ["chart_type", "x", "output_path"],
            "properties": {
                "chart_type": {"enum": ["line", "bar", "scatter", "histogram", "box"]},
                "x": values,
                "y": values,
                "title": {"type": "string", "maxLength": 300},
                "x_label": {"type": "string", "maxLength": 160},
                "y_label": {"type": "string", "maxLength": 160},
                "output_path": {"type": "string", "maxLength": 32767},
                "dpi": {"type": "integer", "minimum": 72, "maximum": 600},
            },
            "additionalProperties": False,
        }

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        del method
        resolved = await self._paths.resolve(
            str(arguments["output_path"]),
            identity,
            must_exist=False,
        )
        if resolved.path.suffix.lower() not in {".png", ".svg", ".pdf"}:
            raise QError(QErrorCode.VALIDATION_ERROR, "Figure format must be PNG, SVG, or PDF.")
        normalized = dict(arguments)
        normalized["output_path"] = str(resolved.path)
        normalized["_policy"] = {
            "resource": str(resolved.path),
            "outside_workspace": resolved.outside_workspace,
            "overwrite": resolved.path.exists(),
        }
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        if method != "create":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown visualization method.")
        async with self._lock:
            return await asyncio.to_thread(self._create, arguments)

    @staticmethod
    def _create(arguments: dict[str, Any]) -> ControllerResult:
        chart_type = str(arguments["chart_type"])
        x = [float(value) for value in arguments["x"]]
        y = [float(value) for value in arguments.get("y", [])]
        if chart_type in {"line", "bar", "scatter"} and len(x) != len(y):
            raise QError(QErrorCode.VALIDATION_ERROR, "x and y must have equal length.")
        figure, axis = plt.subplots(figsize=(9, 5.5), constrained_layout=True)
        if chart_type == "line":
            axis.plot(x, y, color="#18d5ff", linewidth=2)
        elif chart_type == "bar":
            axis.bar(x, y, color="#18d5ff")
        elif chart_type == "scatter":
            axis.scatter(x, y, color="#18d5ff", edgecolor="#071827")
        elif chart_type == "histogram":
            axis.hist(x, bins="auto", color="#18d5ff", edgecolor="#071827")
        elif chart_type == "box":
            axis.boxplot(x)
        axis.set_title(str(arguments.get("title", "Experimental Q")))
        axis.set_xlabel(str(arguments.get("x_label", "x")))
        axis.set_ylabel(str(arguments.get("y_label", "y")))
        axis.grid(alpha=0.2)
        output = Path(str(arguments["output_path"]))
        figure.savefig(output, dpi=int(arguments.get("dpi", 180)))
        plt.close(figure)
        digest = hashlib.sha256(output.read_bytes()).hexdigest()
        return ControllerResult(
            data={"path": str(output), "sha256": digest, "chart_type": chart_type},
            resource=str(output),
            provenance_outputs=[{"path": str(output), "sha256": digest}],
            provenance_parameters={
                key: value
                for key, value in arguments.items()
                if key not in {"x", "y", "_policy"}
            },
        )
