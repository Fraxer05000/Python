"""Spreadsheet profiling and structured workbook edits."""

from __future__ import annotations

import asyncio
import hashlib
import math
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl import Workbook, load_workbook

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.path_policy import PathPolicy
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity


class SpreadsheetController(BaseController):
    def __init__(self, paths: PathPolicy) -> None:
        self._paths = paths

    def argument_schema(self, method: str) -> dict[str, Any]:
        path = {"type": "string", "maxLength": 32767}
        if method == "profile_dataset":
            return _schema(
                {
                    "path": path,
                    "sheet_name": {"type": ["string", "integer", "null"]},
                    "sample_rows": {"type": "integer", "minimum": 1, "maximum": 1000},
                },
                ["path"],
            )
        if method == "edit":
            return _schema(
                {
                    "path": path,
                    "operation": {
                        "enum": [
                            "create_workbook",
                            "write_range",
                            "add_sheet",
                            "rename_sheet",
                            "formula",
                            "export_csv",
                            "import_csv",
                        ]
                    },
                    "sheet": {"type": "string", "maxLength": 31},
                    "new_name": {"type": "string", "maxLength": 31},
                    "start_cell": {"type": "string", "pattern": "^[A-Z]{1,3}[1-9][0-9]{0,6}$"},
                    "values": {
                        "type": "array",
                        "items": {"type": "array", "items": {}},
                        "maxItems": 100000,
                    },
                    "cell": {"type": "string", "pattern": "^[A-Z]{1,3}[1-9][0-9]{0,6}$"},
                    "formula": {"type": "string", "maxLength": 8192},
                    "source_path": path,
                    "output_path": path,
                },
                ["path", "operation"],
            )
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown SpreadsheetController method.")

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        operation = str(arguments.get("operation", ""))
        create = method == "edit" and operation == "create_workbook"
        resolved = await self._paths.resolve(
            str(arguments["path"]),
            identity,
            must_exist=not create,
        )
        normalized = dict(arguments)
        normalized["path"] = str(resolved.path)
        for key in ("source_path", "output_path"):
            if key in normalized:
                value = await self._paths.resolve(
                    str(normalized[key]),
                    identity,
                    must_exist=key == "source_path",
                )
                normalized[key] = str(value.path)
        normalized["_policy"] = {
            "resource": str(resolved.path),
            "outside_workspace": resolved.outside_workspace,
            "overwrite": method == "edit" and not create,
        }
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        if method == "profile_dataset":
            return await asyncio.to_thread(self._profile, arguments)
        if method == "edit":
            return await asyncio.to_thread(self._edit, arguments)
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown SpreadsheetController method.")

    @staticmethod
    def _profile(arguments: dict[str, Any]) -> ControllerResult:
        path = Path(str(arguments["path"]))
        frame = _read_frame(path, arguments.get("sheet_name"))
        sample_rows = int(arguments.get("sample_rows", 20))
        profile = {
            "rows": int(frame.shape[0]),
            "columns": int(frame.shape[1]),
            "schema": [
                {
                    "name": str(column),
                    "dtype": str(frame[column].dtype),
                    "missing": int(frame[column].isna().sum()),
                    "unique": int(frame[column].nunique(dropna=True)),
                }
                for column in frame.columns
            ],
            "numeric_summary": _records(
                frame.select_dtypes(include="number").describe().reset_index()
            ),
            "sample": _records(frame.head(sample_rows)),
        }
        digest = _hash(path)
        return ControllerResult(
            data=profile,
            resource=str(path),
            provenance_inputs=[{"path": str(path), "sha256": digest}],
            provenance_outputs=[{"type": "dataset_profile"}],
            provenance_parameters={"sample_rows": sample_rows},
        )

    @staticmethod
    def _edit(arguments: dict[str, Any]) -> ControllerResult:
        path = Path(str(arguments["path"]))
        operation = str(arguments["operation"])
        before = _hash(path) if path.exists() else None
        if operation == "create_workbook":
            if path.exists():
                raise QError(QErrorCode.VALIDATION_ERROR, "Workbook already exists.")
            if path.suffix.lower() != ".xlsx":
                raise QError(QErrorCode.VALIDATION_ERROR, "Workbook must use .xlsx.")
            workbook = Workbook()
            active = workbook.active
            if active is None:
                raise QError(QErrorCode.INTERNAL_ERROR, "Workbook has no active sheet.")
            active.title = str(arguments.get("sheet", "Sheet1"))
            workbook.save(path)
        elif operation == "import_csv":
            source = Path(str(arguments["source_path"]))
            frame = pd.read_csv(source)
            frame.to_excel(path, index=False, sheet_name=str(arguments.get("sheet", "Data")))
        elif operation == "export_csv":
            output = Path(str(arguments["output_path"]))
            frame = pd.read_excel(path, sheet_name=str(arguments.get("sheet", 0)))
            frame.to_csv(output, index=False)
            return _file_result(output, operation, before)
        else:
            workbook = load_workbook(path)
            active = workbook.active
            if active is None:
                raise QError(QErrorCode.INTERNAL_ERROR, "Workbook has no active sheet.")
            sheet_name = str(arguments.get("sheet", active.title))
            if operation == "add_sheet":
                if sheet_name in workbook.sheetnames:
                    raise QError(QErrorCode.VALIDATION_ERROR, "Sheet already exists.")
                workbook.create_sheet(sheet_name)
            elif operation == "rename_sheet":
                workbook[sheet_name].title = str(arguments["new_name"])
            elif operation == "formula":
                formula = str(arguments["formula"])
                if not formula.startswith("="):
                    raise QError(QErrorCode.VALIDATION_ERROR, "Formula must begin with '='.")
                workbook[sheet_name][str(arguments["cell"])] = formula
            elif operation == "write_range":
                values = arguments.get("values")
                if not isinstance(values, list):
                    raise QError(QErrorCode.VALIDATION_ERROR, "values must be a matrix.")
                cell = workbook[sheet_name][str(arguments.get("start_cell", "A1"))]
                for row_offset, row_values in enumerate(values):
                    if not isinstance(row_values, list):
                        raise QError(QErrorCode.VALIDATION_ERROR, "values must be a matrix.")
                    for column_offset, value in enumerate(row_values):
                        workbook[sheet_name].cell(
                            row=cell.row + row_offset,
                            column=cell.column + column_offset,
                            value=value,
                        )
            else:
                raise QError(QErrorCode.VALIDATION_ERROR, "Unknown workbook operation.")
            workbook.save(path)
        return _file_result(path, operation, before)


def _read_frame(path: Path, sheet_name: object) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix == ".xlsx":
        if sheet_name is not None and not isinstance(sheet_name, int | str):
            raise QError(QErrorCode.VALIDATION_ERROR, "sheet_name must be text or an index.")
        requested: int | str = 0 if sheet_name is None else sheet_name
        frame = pd.read_excel(path, sheet_name=requested)
        if not isinstance(frame, pd.DataFrame):
            raise QError(QErrorCode.VALIDATION_ERROR, "A single sheet must be selected.")
        return frame
    if suffix == ".parquet":
        return pd.read_parquet(path)
    raise QError(QErrorCode.VALIDATION_ERROR, "Supported datasets are CSV, XLSX, and Parquet.")


def _records(frame: pd.DataFrame) -> list[dict[str, object]]:
    values: list[dict[str, object]] = []
    for raw in frame.to_dict(orient="records"):
        row: dict[str, object] = {}
        for key, value in raw.items():
            if pd.isna(value):
                row[str(key)] = None
            elif hasattr(value, "item"):
                row[str(key)] = value.item()
            elif isinstance(value, float) and not math.isfinite(value):
                row[str(key)] = None
            else:
                row[str(key)] = value
        values.append(row)
    return values


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _file_result(path: Path, operation: str, before: str | None) -> ControllerResult:
    after = _hash(path)
    inputs = [{"path": str(path), "sha256": before}] if before else []
    return ControllerResult(
        data={"path": str(path), "sha256": after, "operation": operation},
        resource=str(path),
        provenance_inputs=inputs,
        provenance_outputs=[{"path": str(path), "sha256": after}],
        provenance_parameters={"operation": operation},
    )


def _schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }
