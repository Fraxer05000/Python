"""Policy-gated HTTPS controller with SSRF and download defenses."""

from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import json
import re
import socket
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlsplit

import httpx
from bs4 import BeautifulSoup

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.path_policy import PathPolicy
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import ApplicationMode, InvocationIdentity

_MAX_DOWNLOAD = 100 * 1024 * 1024
_DEFAULT_RESPONSE = 5 * 1024 * 1024
_SEARCH_URL = "https://html.duckduckgo.com/html/"


class WebController(BaseController):
    def __init__(self, paths: PathPolicy) -> None:
        self._paths = paths
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=8.0),
            follow_redirects=False,
            trust_env=False,
            headers={"User-Agent": "ExperimentalQ/3.0 (+local user-requested fetch)"},
        )

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method == "search":
            return _schema(
                {
                    "query": {"type": "string", "minLength": 1, "maxLength": 1000},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 20},
                },
                ["query"],
            )
        if method == "fetch":
            return _schema(
                {
                    "url": {"type": "string", "minLength": 1, "maxLength": 8192},
                    "max_bytes": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": _MAX_DOWNLOAD,
                    },
                    "save_path": {"type": "string", "maxLength": 32767},
                },
                ["url"],
            )
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown WebController method.")

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        normalized = dict(arguments)
        url = _SEARCH_URL if method == "search" else str(arguments["url"])
        host = validate_https_url_syntax(url)
        policy: dict[str, object] = {"resource": host, "domain": host}
        if "save_path" in arguments:
            resolved = await self._paths.resolve(
                str(arguments["save_path"]), identity, must_exist=False
            )
            normalized["save_path"] = str(resolved.path)
            policy.update(
                {
                    "outside_workspace": resolved.outside_workspace,
                    "overwrite": resolved.path.exists(),
                }
            )
        normalized["_policy"] = policy
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        if identity.mode is ApplicationMode.LOCAL_ONLY:
            raise QError(QErrorCode.NETWORK_DISABLED, "Network is disabled in Local Only mode.")
        if method == "search":
            return await self._search(arguments)
        if method == "fetch":
            return await self._fetch(arguments)
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown WebController method.")

    async def _search(self, arguments: dict[str, Any]) -> ControllerResult:
        await validate_public_destination(_SEARCH_URL)
        limit = int(arguments.get("limit", 10))
        try:
            response = await self._client.post(
                _SEARCH_URL,
                data={"q": str(arguments["query"])},
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise QError(QErrorCode.RUNTIME_UNAVAILABLE, "Web search request failed.") from exc
        if len(response.content) > _DEFAULT_RESPONSE:
            raise QError(QErrorCode.VALIDATION_ERROR, "Web search response is too large.")
        soup = BeautifulSoup(response.text, "html.parser")
        results: list[dict[str, str]] = []
        for result in soup.select(".result"):
            anchor = result.select_one(".result__a")
            if anchor is None or not anchor.get("href"):
                continue
            snippet = result.select_one(".result__snippet")
            results.append(
                {
                    "title": anchor.get_text(" ", strip=True),
                    "url": str(anchor.get("href")),
                    "snippet": snippet.get_text(" ", strip=True) if snippet else "",
                }
            )
            if len(results) >= limit:
                break
        return ControllerResult(
            data={"query": str(arguments["query"]), "results": results},
            resource="duckduckgo.com",
            provenance_outputs=[{"type": "web_search", "result_count": len(results)}],
        )

    async def _fetch(self, arguments: dict[str, Any]) -> ControllerResult:
        url = str(arguments["url"])
        maximum = int(arguments.get("max_bytes", _DEFAULT_RESPONSE))
        final_url, content, content_type = await bounded_https_get(self._client, url, maximum)
        digest = hashlib.sha256(content).hexdigest()
        if "save_path" in arguments:
            path = Path(str(arguments["save_path"]))
            if path.exists():
                raise QError(QErrorCode.VALIDATION_ERROR, "Download never overwrites a file.")
            path.write_bytes(content)
            return ControllerResult(
                data={
                    "url": final_url,
                    "path": str(path),
                    "size_bytes": len(content),
                    "sha256": digest,
                    "content_type": content_type,
                },
                resource=urlsplit(final_url).hostname,
                provenance_inputs=[{"url": final_url}],
                provenance_outputs=[{"path": str(path), "sha256": digest}],
            )
        if "json" in content_type:
            try:
                parsed: object = json.loads(content)
            except json.JSONDecodeError as exc:
                raise QError(QErrorCode.VALIDATION_ERROR, "Remote JSON is invalid.") from exc
            data: object = parsed
        elif content_type.startswith("text/") or "html" in content_type:
            text = content.decode("utf-8", errors="replace")
            if "html" in content_type:
                soup = BeautifulSoup(text, "html.parser")
                for element in soup(["script", "style", "noscript"]):
                    element.decompose()
                text = soup.get_text("\n", strip=True)
            data = text
        else:
            raise QError(
                QErrorCode.VALIDATION_ERROR,
                "Binary content requires an explicit save_path.",
            )
        return ControllerResult(
            data={
                "url": final_url,
                "content": data,
                "size_bytes": len(content),
                "sha256": digest,
                "content_type": content_type,
            },
            resource=urlsplit(final_url).hostname,
            provenance_inputs=[{"url": final_url, "sha256": digest}],
        )

    async def close(self) -> None:
        await self._client.aclose()


async def bounded_https_get(
    client: httpx.AsyncClient,
    url: str,
    maximum: int,
) -> tuple[str, bytes, str]:
    current = url
    for _redirect in range(6):
        await validate_public_destination(current)
        try:
            async with client.stream("GET", current) as response:
                if response.status_code in {301, 302, 303, 307, 308}:
                    location = response.headers.get("location")
                    if not location:
                        raise QError(QErrorCode.VALIDATION_ERROR, "Redirect has no location.")
                    current = urljoin(current, location)
                    continue
                response.raise_for_status()
                chunks = bytearray()
                async for chunk in response.aiter_bytes():
                    chunks.extend(chunk)
                    if len(chunks) > maximum:
                        raise QError(QErrorCode.VALIDATION_ERROR, "Response exceeds size limit.")
                content_type = response.headers.get("content-type", "application/octet-stream")
                return str(response.url), bytes(chunks), content_type.split(";", 1)[0].lower()
        except QError:
            raise
        except httpx.TimeoutException as exc:
            raise QError(QErrorCode.TIMEOUT, "Network request timed out.") from exc
        except httpx.HTTPError as exc:
            raise QError(QErrorCode.RUNTIME_UNAVAILABLE, "Network request failed.") from exc
    raise QError(QErrorCode.VALIDATION_ERROR, "Too many redirects.")


def validate_https_url_syntax(url: str) -> str:
    parts = urlsplit(url)
    if parts.scheme.lower() != "https" or not parts.hostname:
        raise QError(QErrorCode.PERMISSION_DENIED, "Only absolute HTTPS URLs are allowed.")
    if parts.username or parts.password:
        raise QError(QErrorCode.PERMISSION_DENIED, "Credentials in URLs are denied.")
    try:
        return parts.hostname.encode("idna").decode("ascii").lower()
    except UnicodeError as exc:
        raise QError(QErrorCode.VALIDATION_ERROR, "URL hostname is invalid.") from exc


async def validate_public_destination(url: str) -> None:
    host = validate_https_url_syntax(url)
    if host == "localhost" or host.endswith(".localhost"):
        raise QError(QErrorCode.PERMISSION_DENIED, "Local network destinations are blocked.")
    port = urlsplit(url).port or 443
    try:
        records = await asyncio.to_thread(
            socket.getaddrinfo,
            host,
            port,
            socket.AF_UNSPEC,
            socket.SOCK_STREAM,
        )
    except socket.gaierror as exc:
        raise QError(
            QErrorCode.RESOURCE_NOT_FOUND,
            "Remote hostname could not be resolved.",
        ) from exc
    if not records:
        raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Remote hostname has no addresses.")
    for record in records:
        address = ipaddress.ip_address(record[4][0])
        if not address.is_global:
            raise QError(QErrorCode.PERMISSION_DENIED, "Private network destinations are blocked.")


def sanitize_download_filename(value: str) -> str:
    name = Path(value.replace("\\", "/")).name
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", name).strip(". ")
    return safe[:180] or "download.bin"


def _schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }
