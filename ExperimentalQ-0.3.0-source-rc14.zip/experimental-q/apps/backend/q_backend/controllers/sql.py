"""Read-only project SQL routed through a constrained worker."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import sqlglot
from sqlglot import expressions

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity
from q_backend.projects.service import ProjectService
from q_backend.supervisor.client import SupervisorClient

_DENIED_SQL = re.compile(
    r"\b(attach|copy|export|import|install|load|pragma|read_csv|read_json|read_parquet|"
    r"sqlite_scan|httpfs|shell|write_csv|write_parquet)\b",
    re.IGNORECASE,
)


class SQLController(BaseController):
    def __init__(self, supervisor: SupervisorClient, projects: ProjectService) -> None:
        self._supervisor = supervisor
        self._projects = projects

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method != "query":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown SQLController method.")
        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "required": ["engine", "query"],
            "properties": {
                "engine": {"enum": ["sqlite", "duckdb"]},
                "query": {"type": "string", "minLength": 1, "maxLength": 100000},
                "parameters": {"type": "array", "items": {}, "maxItems": 10000},
                "connector_ref": {"type": "string", "maxLength": 200},
                "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120},
            },
            "additionalProperties": False,
        }

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        del method
        if "connector_ref" in arguments:
            normalized = dict(arguments)
            normalized["_policy"] = {
                "resource": str(arguments["connector_ref"]),
                "external_database": True,
            }
            return normalized
        if identity.project_id is None:
            raise QError(QErrorCode.VALIDATION_ERROR, "Project SQL requires project_id.")
        _validate_read_only_sql(str(arguments["query"]), str(arguments["engine"]))
        project = await self._projects.get(identity.project_id)
        metadata = Path(project.root_path) / "Metadata"
        metadata.mkdir(exist_ok=True)
        suffix = ".sqlite3" if arguments["engine"] == "sqlite" else ".duckdb"
        normalized = dict(arguments)
        normalized["database_path"] = str((metadata / f"project{suffix}").resolve())
        normalized["_policy"] = {
            "resource": str(metadata),
            "external_database": False,
        }
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        if method != "query":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown SQLController method.")
        if "connector_ref" in arguments:
            raise QError(
                QErrorCode.RUNTIME_UNAVAILABLE,
                "External SQL connectors require a configured credential reference.",
            )
        payload = json.dumps(
            {
                "engine": arguments["engine"],
                "query": arguments["query"],
                "parameters": arguments.get("parameters", []),
                "database_path": arguments["database_path"],
            },
            separators=(",", ":"),
        )
        worker = await self._supervisor.run_worker(
            "sql",
            payload,
            str(Path(str(arguments["database_path"])).parent),
            int(arguments.get("timeout_seconds", 60)),
        )
        if worker.timed_out:
            raise QError(QErrorCode.TIMEOUT, "SQL query exceeded its time limit.")
        try:
            body = json.loads(worker.stdout)
        except json.JSONDecodeError as exc:
            raise QError(QErrorCode.INTERNAL_ERROR, "SQL worker returned invalid JSON.") from exc
        if worker.exit_code != 0 or body.get("status") != "ok":
            raise QError(QErrorCode.VALIDATION_ERROR, "SQL query failed or was denied.")
        return ControllerResult(
            data={
                "columns": body.get("columns", []),
                "rows": body.get("rows", []),
                "truncated": body.get("truncated", False),
            },
            resource=str(arguments["database_path"]),
            provenance_inputs=[{"database": str(arguments["database_path"])}],
            provenance_outputs=[{"type": "query_result"}],
            provenance_parameters={
                "engine": arguments["engine"],
                "query_sha256": _hash(str(arguments["query"])),
            },
        )


def _validate_read_only_sql(query: str, dialect: str) -> None:
    if _DENIED_SQL.search(query):
        raise QError(QErrorCode.SANDBOX_VIOLATION, "SQL contains a denied capability.")
    try:
        statements = sqlglot.parse(query, read=dialect)
    except sqlglot.errors.ParseError as exc:
        raise QError(QErrorCode.VALIDATION_ERROR, "SQL syntax is invalid.") from exc
    if len(statements) != 1:
        raise QError(QErrorCode.SANDBOX_VIOLATION, "Only one SQL statement is allowed.")
    statement = statements[0]
    denied = (
        expressions.Insert,
        expressions.Update,
        expressions.Delete,
        expressions.Create,
        expressions.Drop,
        expressions.Alter,
        expressions.Command,
        expressions.Copy,
        expressions.Merge,
    )
    if not isinstance(statement, expressions.Select | expressions.Union) or any(
        statement.find(kind) is not None for kind in denied
    ):
        raise QError(QErrorCode.SANDBOX_VIOLATION, "Only read-only SELECT SQL is allowed.")


def _hash(value: str) -> str:
    import hashlib

    return hashlib.sha256(value.encode("utf-8")).hexdigest()
