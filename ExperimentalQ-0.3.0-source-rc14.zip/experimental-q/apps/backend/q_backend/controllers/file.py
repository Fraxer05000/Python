"""Bounded file operations over roots authorized by the user."""

from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
from typing import Any

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.path_policy import PathPolicy
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity

_MAX_TEXT_BYTES = 10 * 1024 * 1024


class FileController(BaseController):
    def __init__(self, paths: PathPolicy) -> None:
        self._paths = paths

    def argument_schema(self, method: str) -> dict[str, Any]:
        schemas: dict[str, dict[str, Any]] = {
            "list": _object_schema(
                {
                    "path": {"type": "string", "maxLength": 32767},
                    "recursive": {"type": "boolean", "default": False},
                    "max_entries": {"type": "integer", "minimum": 1, "maximum": 2000},
                },
                ["path"],
            ),
            "read": _object_schema(
                {
                    "path": {"type": "string", "maxLength": 32767},
                    "max_bytes": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": _MAX_TEXT_BYTES,
                    },
                },
                ["path"],
            ),
            "write_new": _object_schema(
                {
                    "path": {"type": "string", "maxLength": 32767},
                    "content": {"type": "string", "maxLength": _MAX_TEXT_BYTES},
                },
                ["path", "content"],
            ),
            "update": _object_schema(
                {
                    "path": {"type": "string", "maxLength": 32767},
                    "content": {"type": "string", "maxLength": _MAX_TEXT_BYTES},
                    "expected_sha256": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
                },
                ["path", "content"],
            ),
            "delete": _object_schema(
                {"path": {"type": "string", "maxLength": 32767}},
                ["path"],
            ),
        }
        try:
            return schemas[method]
        except KeyError as exc:
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown FileController method.") from exc

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        must_exist = method in {"list", "read", "update", "delete"}
        resolved = await self._paths.resolve(
            str(arguments["path"]), identity, must_exist=must_exist
        )
        normalized = dict(arguments)
        operation_path = resolved.leaf_link if method == "delete" else None
        normalized["path"] = str(operation_path or resolved.path)
        normalized["_policy"] = {
            "resource": str(operation_path or resolved.path),
            "scope_root": str(resolved.root),
            "outside_workspace": resolved.outside_workspace,
            "overwrite": method == "update" or (method == "write_new" and resolved.path.exists()),
        }
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        path = Path(str(arguments["path"]))
        if method == "list":
            return await asyncio.to_thread(self._list, path, arguments)
        if method == "read":
            return await asyncio.to_thread(self._read, path, arguments)
        if method == "write_new":
            return await asyncio.to_thread(self._write_new, path, arguments)
        if method == "update":
            return await asyncio.to_thread(self._update, path, arguments)
        if method == "delete":
            return await asyncio.to_thread(self._delete, path)
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown FileController method.")

    @staticmethod
    def _list(path: Path, arguments: dict[str, Any]) -> ControllerResult:
        if not path.is_dir():
            raise QError(QErrorCode.VALIDATION_ERROR, "The list target is not a directory.")
        recursive = bool(arguments.get("recursive", False))
        maximum = int(arguments.get("max_entries", 500))
        iterator = path.rglob("*") if recursive else path.iterdir()
        entries: list[dict[str, Any]] = []
        truncated = False
        for item in iterator:
            if len(entries) >= maximum:
                truncated = True
                break
            try:
                resolved = item.resolve(strict=True)
            except OSError:
                continue
            if not _within(resolved, path):
                continue
            stat = resolved.stat()
            entries.append(
                {
                    "name": item.name,
                    "relative_path": str(item.relative_to(path)),
                    "kind": "directory" if resolved.is_dir() else "file",
                    "size_bytes": stat.st_size if resolved.is_file() else None,
                    "modified_at_utc": _timestamp(stat.st_mtime),
                }
            )
        return ControllerResult(
            data={"entries": entries, "truncated": truncated, "root": str(path)},
            resource=str(path),
        )

    @staticmethod
    def _read(path: Path, arguments: dict[str, Any]) -> ControllerResult:
        if not path.is_file():
            raise QError(QErrorCode.VALIDATION_ERROR, "The read target is not a file.")
        limit = int(arguments.get("max_bytes", _MAX_TEXT_BYTES))
        size = path.stat().st_size
        if size > limit:
            raise QError(
                QErrorCode.VALIDATION_ERROR,
                "File exceeds the requested read limit.",
                details={"size_bytes": size, "max_bytes": limit},
            )
        content = path.read_text(encoding="utf-8")
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
        return ControllerResult(
            data={"content": content, "sha256": digest, "size_bytes": size},
            resource=str(path),
            provenance_inputs=[{"path": str(path), "sha256": digest}],
        )

    @staticmethod
    def _write_new(path: Path, arguments: dict[str, Any]) -> ControllerResult:
        if path.exists():
            raise QError(QErrorCode.VALIDATION_ERROR, "write_new never overwrites a file.")
        content = str(arguments["content"])
        path.write_text(content, encoding="utf-8", newline="\n")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        return ControllerResult(
            data={"path": str(path), "sha256": digest, "size_bytes": path.stat().st_size},
            resource=str(path),
            provenance_outputs=[{"path": str(path), "sha256": digest}],
        )

    @staticmethod
    def _update(path: Path, arguments: dict[str, Any]) -> ControllerResult:
        if not path.is_file():
            raise QError(QErrorCode.VALIDATION_ERROR, "The update target is not a file.")
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        expected = arguments.get("expected_sha256")
        if expected is not None and expected != before:
            raise QError(QErrorCode.VALIDATION_ERROR, "File changed since it was read.")
        path.write_text(str(arguments["content"]), encoding="utf-8", newline="\n")
        after = hashlib.sha256(path.read_bytes()).hexdigest()
        return ControllerResult(
            data={"path": str(path), "sha256": after, "previous_sha256": before},
            resource=str(path),
            provenance_inputs=[{"path": str(path), "sha256": before}],
            provenance_outputs=[{"path": str(path), "sha256": after}],
        )

    @staticmethod
    def _delete(path: Path) -> ControllerResult:
        if path.is_symlink():
            path.unlink()
        elif path.is_file():
            path.unlink()
        elif path.is_dir():
            try:
                path.rmdir()
            except OSError as exc:
                raise QError(
                    QErrorCode.VALIDATION_ERROR,
                    "Only empty directories can be deleted by this method.",
                ) from exc
        else:
            raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Delete target not found.")
        return ControllerResult(data={"deleted": True, "path": str(path)}, resource=str(path))


def _object_schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root.resolve(strict=True))
        return True
    except ValueError:
        return False


def _timestamp(value: float) -> str:
    from datetime import UTC, datetime

    return datetime.fromtimestamp(value, tz=UTC).isoformat()
