"""P2 Python code execution routed through the fixed Rust-owned worker."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from q_backend.controllers.base import ControllerResult
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity
from q_backend.projects.service import ProjectService
from q_backend.supervisor.client import SupervisorClient


class PythonSandbox:
    def __init__(self, supervisor: SupervisorClient, projects: ProjectService) -> None:
        self._supervisor = supervisor
        self._projects = projects

    async def normalize(
        self,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        if identity.project_id is None:
            raise QError(QErrorCode.VALIDATION_ERROR, "Python execution requires project_id.")
        project = await self._projects.get(identity.project_id)
        sandbox = Path(project.root_path) / "Sandbox"
        normalized = dict(arguments)
        normalized["working_directory"] = str(sandbox.resolve(strict=True))
        normalized["_policy"] = {"resource": str(sandbox), "outside_workspace": False}
        return normalized

    async def run(self, arguments: dict[str, Any]) -> ControllerResult:
        payload = json.dumps(
            {"code": str(arguments["code"])},
            ensure_ascii=False,
            separators=(",", ":"),
        )
        timeout = int(arguments.get("timeout_seconds", 30))
        worker = await self._supervisor.run_worker(
            "python",
            payload,
            str(arguments["working_directory"]),
            timeout,
        )
        if worker.timed_out:
            raise QError(QErrorCode.TIMEOUT, "Python worker exceeded its time limit.")
        if worker.exit_code != 0:
            try:
                body = json.loads(worker.stdout)
                detail = str(body.get("error", "worker_failed"))
            except (json.JSONDecodeError, AttributeError):
                detail = "worker_failed"
            raise QError(
                QErrorCode.SANDBOX_VIOLATION,
                "Python worker rejected or failed the code.",
                details={"worker_error": detail[:4000]},
            )
        try:
            body = json.loads(worker.stdout)
        except json.JSONDecodeError as exc:
            raise QError(QErrorCode.INTERNAL_ERROR, "Python worker returned invalid JSON.") from exc
        if body.get("status") != "ok":
            raise QError(QErrorCode.SANDBOX_VIOLATION, "Python worker rejected the code.")
        return ControllerResult(
            data={"stdout": body.get("stdout", ""), "result": body.get("result")},
            resource=str(arguments["working_directory"]),
            provenance_parameters={"code_sha256": _sha256(str(arguments["code"]))},
            provenance_outputs=[{"type": "python_execution_result"}],
        )


def _sha256(value: str) -> str:
    import hashlib

    return hashlib.sha256(value.encode("utf-8")).hexdigest()
