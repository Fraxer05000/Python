"""Hash-allowlisted, offline project wheel installation controller."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.path_policy import PathPolicy
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity
from q_backend.projects.service import ProjectService
from q_backend.supervisor.client import SupervisorClient


class PackageController(BaseController):
    def __init__(
        self,
        supervisor: SupervisorClient,
        projects: ProjectService,
        paths: PathPolicy,
        allowlist_path: Path,
    ) -> None:
        self._supervisor = supervisor
        self._projects = projects
        self._paths = paths
        try:
            document = json.loads(allowlist_path.read_text(encoding="utf-8"))
            wheels = document["wheels"]
        except (OSError, json.JSONDecodeError, KeyError) as exc:
            raise QError(QErrorCode.VALIDATION_ERROR, "Package allowlist is invalid.") from exc
        if not isinstance(wheels, dict):
            raise QError(QErrorCode.VALIDATION_ERROR, "Package allowlist is invalid.")
        self._allowlist: dict[str, object] = wheels

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method != "install":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown PackageController method.")
        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "required": ["wheel_path", "sha256"],
            "properties": {
                "wheel_path": {"type": "string", "maxLength": 32767},
                "sha256": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
            },
            "additionalProperties": False,
        }

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        del method
        if identity.project_id is None:
            raise QError(QErrorCode.VALIDATION_ERROR, "Package install requires project_id.")
        resolved = await self._paths.resolve(
            str(arguments["wheel_path"]), identity, must_exist=True
        )
        if resolved.path.suffix.lower() != ".whl" or not resolved.path.is_file():
            raise QError(QErrorCode.VALIDATION_ERROR, "Package must be a local .whl file.")
        digest = _hash(resolved.path)
        if digest != arguments["sha256"] or digest not in self._allowlist:
            raise QError(
                QErrorCode.PERMISSION_DENIED,
                "Wheel is not present in the administrator-managed hash allowlist.",
            )
        project = await self._projects.get(identity.project_id)
        destination = Path(project.root_path) / "Sandbox" / "packages"
        destination.mkdir(exist_ok=True)
        normalized = dict(arguments)
        normalized.update(
            {
                "wheel_path": str(resolved.path),
                "destination": str(destination.resolve(strict=True)),
                "_policy": {"resource": str(resolved.path)},
            }
        )
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        if method != "install":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown PackageController method.")
        payload = json.dumps(
            {
                "wheel_path": arguments["wheel_path"],
                "destination": arguments["destination"],
                "sha256": arguments["sha256"],
            },
            separators=(",", ":"),
        )
        worker = await self._supervisor.run_worker(
            "package",
            payload,
            str(arguments["destination"]),
            120,
        )
        try:
            body = json.loads(worker.stdout)
        except json.JSONDecodeError as exc:
            raise QError(
                QErrorCode.INTERNAL_ERROR,
                "Package worker returned invalid JSON.",
            ) from exc
        if worker.timed_out:
            raise QError(QErrorCode.TIMEOUT, "Package worker timed out.")
        if worker.exit_code != 0 or body.get("status") != "ok":
            raise QError(QErrorCode.SANDBOX_VIOLATION, "Package installation failed safely.")
        return ControllerResult(
            data=body,
            resource=str(arguments["wheel_path"]),
            provenance_inputs=[
                {"path": str(arguments["wheel_path"]), "sha256": arguments["sha256"]}
            ],
            provenance_outputs=[{"path": body.get("path"), "type": "project_package"}],
        )


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
