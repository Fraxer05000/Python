"""Optional R structured operations routed through the Rust supervisor."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity
from q_backend.projects.service import ProjectService
from q_backend.supervisor.client import SupervisorClient


class RController(BaseController):
    def __init__(self, supervisor: SupervisorClient, projects: ProjectService) -> None:
        self._supervisor = supervisor
        self._projects = projects

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method != "run_structured":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown RController method.")
        values = {
            "type": "array",
            "items": {"type": "number"},
            "minItems": 1,
            "maxItems": 1000000,
        }
        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "required": ["operation", "x"],
            "properties": {
                "operation": {"enum": ["descriptive_statistics", "correlation"]},
                "x": values,
                "y": values,
                "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120},
            },
            "additionalProperties": False,
        }

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        del method
        if identity.project_id is None:
            raise QError(QErrorCode.VALIDATION_ERROR, "R execution requires project_id.")
        project = await self._projects.get(identity.project_id)
        sandbox = (Path(project.root_path) / "Sandbox").resolve(strict=True)
        normalized = dict(arguments)
        normalized["working_directory"] = str(sandbox)
        normalized["_policy"] = {"resource": str(sandbox)}
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        if method != "run_structured":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown RController method.")
        worker = await self._supervisor.run_worker(
            "r",
            json.dumps(
                {
                    "operation": arguments["operation"],
                    "x": arguments["x"],
                    "y": arguments.get("y"),
                },
                separators=(",", ":"),
            ),
            str(arguments["working_directory"]),
            int(arguments.get("timeout_seconds", 60)),
        )
        if worker.timed_out:
            raise QError(QErrorCode.TIMEOUT, "R worker exceeded its time limit.")
        try:
            body = json.loads(worker.stdout)
        except json.JSONDecodeError as exc:
            raise QError(QErrorCode.INTERNAL_ERROR, "R worker returned invalid JSON.") from exc
        if worker.exit_code != 0 or body.get("status") != "ok":
            raise QError(QErrorCode.RUNTIME_UNAVAILABLE, "R operation failed.")
        return ControllerResult(
            data=body.get("result"),
            resource=str(arguments["working_directory"]),
            provenance_outputs=[{"type": "r_analysis_result"}],
            provenance_parameters={"operation": arguments["operation"]},
        )
