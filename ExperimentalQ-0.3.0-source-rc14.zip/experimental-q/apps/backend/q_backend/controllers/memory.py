"""Tool-facing memory operations with explicit persistence semantics."""

from __future__ import annotations

from typing import Any

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.errors import QError, QErrorCode
from q_backend.memory.service import MemoryService
from q_backend.models.memory import MemoryScope
from q_backend.models.permissions import InvocationIdentity


class MemoryController(BaseController):
    def __init__(self, memory: MemoryService) -> None:
        self._memory = memory

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method == "search":
            return _schema(
                {
                    "query": {"type": "string", "minLength": 1, "maxLength": 10000},
                    "scope": {"enum": ["user", "project", "knowledge"]},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 50},
                },
                ["query", "scope"],
            )
        if method in {"save_user", "save_project"}:
            return _schema(
                {
                    "content": {"type": "string", "minLength": 1, "maxLength": 100000},
                    "source": {"type": "string", "minLength": 1, "maxLength": 32767},
                    "sensitivity": {"type": "boolean"},
                    "explicit_user_request": {"type": "boolean"},
                },
                ["content", "source", "sensitivity", "explicit_user_request"],
            )
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown MemoryController method.")

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        normalized = dict(arguments)
        resource = "user_profile" if method == "save_user" else identity.project_id
        normalized["_policy"] = {"resource": resource}
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        if method == "search":
            scope = MemoryScope(str(arguments["scope"]))
            results = await self._memory.search(
                str(arguments["query"]),
                scope=scope,
                project_id=identity.project_id,
                user_id=identity.user_id,
                limit=int(arguments.get("limit", 10)),
            )
            return ControllerResult(data=[item.model_dump(mode="json") for item in results])
        if method in {"save_user", "save_project"}:
            if arguments.get("explicit_user_request") is not True:
                raise QError(
                    QErrorCode.PERMISSION_DENIED,
                    "Persistent memory requires an explicit user request.",
                )
            scope = MemoryScope.USER if method == "save_user" else MemoryScope.PROJECT
            record = await self._memory.save(
                scope=scope,
                content=str(arguments["content"]),
                source=str(arguments["source"]),
                project_id=identity.project_id,
                user_id=identity.user_id,
                sensitivity=bool(arguments["sensitivity"]),
            )
            return ControllerResult(
                data=record.model_dump(mode="json"),
                resource=identity.project_id if scope is MemoryScope.PROJECT else "user_profile",
                provenance_outputs=[{"type": "memory_record", "memory_id": str(record.memory_id)}],
            )
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown MemoryController method.")


def _schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }
