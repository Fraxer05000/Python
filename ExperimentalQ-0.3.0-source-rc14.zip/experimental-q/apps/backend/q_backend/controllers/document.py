"""DOCX and text document operations without Office automation."""

from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
from typing import Any

from docx import Document

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.path_policy import PathPolicy
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity


class DocumentController(BaseController):
    def __init__(self, paths: PathPolicy) -> None:
        self._paths = paths

    def argument_schema(self, method: str) -> dict[str, Any]:
        common = {"path": {"type": "string", "maxLength": 32767}}
        if method == "read":
            return _schema(common, ["path"])
        if method == "create":
            return _schema(
                {
                    **common,
                    "format": {"enum": ["docx", "markdown", "text", "latex"]},
                    "title": {"type": "string", "maxLength": 500},
                    "sections": {
                        "type": "array",
                        "maxItems": 1000,
                        "items": {
                            "type": "object",
                            "required": ["heading", "paragraphs"],
                            "properties": {
                                "heading": {"type": "string", "maxLength": 500},
                                "paragraphs": {
                                    "type": "array",
                                    "items": {"type": "string", "maxLength": 100000},
                                    "maxItems": 1000,
                                },
                            },
                            "additionalProperties": False,
                        },
                    },
                },
                ["path", "format", "title", "sections"],
            )
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown DocumentController method.")

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        resolved = await self._paths.resolve(
            str(arguments["path"]), identity, must_exist=method == "read"
        )
        normalized = dict(arguments)
        normalized["path"] = str(resolved.path)
        normalized["_policy"] = {
            "resource": str(resolved.path),
            "outside_workspace": resolved.outside_workspace,
            "overwrite": resolved.path.exists(),
        }
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        if method == "read":
            return await asyncio.to_thread(self._read, Path(str(arguments["path"])))
        if method == "create":
            return await asyncio.to_thread(self._create, arguments)
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown DocumentController method.")

    @staticmethod
    def _read(path: Path) -> ControllerResult:
        suffix = path.suffix.lower()
        if suffix == ".docx":
            document = Document(str(path))
            blocks: list[dict[str, object]] = []
            for paragraph in document.paragraphs:
                if paragraph.text:
                    blocks.append(
                        {
                            "type": "paragraph",
                            "style": paragraph.style.name if paragraph.style else None,
                            "text": paragraph.text,
                        }
                    )
            for table in document.tables:
                blocks.append(
                    {
                        "type": "table",
                        "rows": [[cell.text for cell in row.cells] for row in table.rows],
                    }
                )
            data: dict[str, object] = {"format": "docx", "blocks": blocks}
        elif suffix in {".md", ".txt", ".tex"}:
            data = {"format": suffix.lstrip("."), "content": path.read_text(encoding="utf-8")}
        else:
            raise QError(QErrorCode.VALIDATION_ERROR, "Unsupported document format.")
        digest = _hash(path)
        return ControllerResult(
            data={**data, "sha256": digest},
            resource=str(path),
            provenance_inputs=[{"path": str(path), "sha256": digest}],
        )

    @staticmethod
    def _create(arguments: dict[str, Any]) -> ControllerResult:
        path = Path(str(arguments["path"]))
        if path.exists():
            raise QError(QErrorCode.VALIDATION_ERROR, "Document creation never overwrites.")
        requested_format = str(arguments["format"])
        expected = {"docx": ".docx", "markdown": ".md", "text": ".txt", "latex": ".tex"}
        if path.suffix.lower() != expected[requested_format]:
            raise QError(QErrorCode.VALIDATION_ERROR, "Path extension does not match format.")
        title = str(arguments["title"])
        sections = arguments["sections"]
        if not isinstance(sections, list):
            raise QError(QErrorCode.VALIDATION_ERROR, "sections must be a list.")
        if requested_format == "docx":
            document = Document()
            document.add_heading(title, level=0)
            for section in sections:
                if not isinstance(section, dict):
                    raise QError(QErrorCode.VALIDATION_ERROR, "A section is invalid.")
                document.add_heading(str(section["heading"]), level=1)
                for paragraph in section["paragraphs"]:
                    document.add_paragraph(str(paragraph))
            document.save(str(path))
        else:
            lines = _render_text(requested_format, title, sections)
            path.write_text(lines, encoding="utf-8", newline="\n")
        digest = _hash(path)
        return ControllerResult(
            data={"path": str(path), "sha256": digest, "format": requested_format},
            resource=str(path),
            provenance_outputs=[{"path": str(path), "sha256": digest}],
            provenance_parameters={"format": requested_format, "title": title},
        )


def _render_text(requested_format: str, title: str, sections: list[object]) -> str:
    if requested_format == "latex":
        output = ["\\documentclass{article}", "\\begin{document}", f"\\section*{{{title}}}"]
        for item in sections:
            section = _section(item)
            output.append(f"\\section{{{section['heading']}}}")
            output.extend(str(value) for value in section["paragraphs"])
        output.append("\\end{document}")
        return "\n\n".join(output) + "\n"
    heading = f"# {title}" if requested_format == "markdown" else title
    output = [heading]
    for item in sections:
        section = _section(item)
        prefix = "## " if requested_format == "markdown" else ""
        output.extend([f"{prefix}{section['heading']}", *map(str, section["paragraphs"])])
    return "\n\n".join(output) + "\n"


def _section(value: object) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise QError(QErrorCode.VALIDATION_ERROR, "A section is invalid.")
    return value


def _schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
