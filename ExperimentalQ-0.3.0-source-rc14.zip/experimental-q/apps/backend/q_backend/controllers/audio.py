"""Ephemeral local WAV transcription routed through the Rust supervisor."""

from __future__ import annotations

import json
from pathlib import Path
from uuid import uuid4

from q_backend.errors import QError, QErrorCode
from q_backend.models.audio import TranscriptionResponse
from q_backend.supervisor.client import SupervisorClient

_MAX_AUDIO_BYTES = 25 * 1024 * 1024


class AudioController:
    def __init__(self, supervisor: SupervisorClient, temp_root: Path) -> None:
        self._supervisor = supervisor
        self._temp_root = temp_root.resolve()

    async def transcribe(self, audio: bytes, language: str) -> TranscriptionResponse:
        if len(audio) > _MAX_AUDIO_BYTES:
            raise QError(QErrorCode.VALIDATION_ERROR, "Audio exceeds the 25 MB limit.")
        if len(audio) < 44 or audio[:4] != b"RIFF" or audio[8:12] != b"WAVE":
            raise QError(QErrorCode.VALIDATION_ERROR, "Microphone input must be PCM WAV.")
        if len(language) != 2 or not language.isalpha():
            raise QError(QErrorCode.VALIDATION_ERROR, "Transcription language is invalid.")
        path = self._temp_root / f"microphone-{uuid4()}.wav"
        path.write_bytes(audio)
        try:
            worker = await self._supervisor.run_worker(
                "audio",
                json.dumps(
                    {"audio_path": str(path), "language": language.lower()},
                    separators=(",", ":"),
                ),
                str(self._temp_root),
                120,
            )
            if worker.timed_out:
                raise QError(QErrorCode.TIMEOUT, "Local transcription timed out.")
            try:
                body = json.loads(worker.stdout)
            except json.JSONDecodeError as exc:
                raise QError(
                    QErrorCode.INTERNAL_ERROR,
                    "Local transcription worker returned invalid JSON.",
                ) from exc
            if worker.exit_code != 0 or body.get("status") != "ok":
                raise QError(
                    QErrorCode.RUNTIME_UNAVAILABLE,
                    "Local whisper.cpp runtime or model is unavailable.",
                )
            return TranscriptionResponse(
                text=str(body.get("text", "")).strip(),
                language=language.lower(),
                duration_ms=(
                    int(body["duration_ms"]) if body.get("duration_ms") is not None else None
                ),
            )
        finally:
            path.unlink(missing_ok=True)
