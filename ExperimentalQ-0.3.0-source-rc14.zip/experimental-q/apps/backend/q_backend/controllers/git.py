"""Typed Git operations using Dulwich; no command strings or shell."""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any
from uuid import UUID

from dulwich import porcelain
from dulwich.errors import NotGitRepository

from q_backend.connectors.service import ConnectorService
from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.path_policy import PathPolicy
from q_backend.controllers.web import validate_public_destination
from q_backend.errors import QError, QErrorCode
from q_backend.models.connector import ConnectorType
from q_backend.models.permissions import ApplicationMode, InvocationIdentity
from q_backend.supervisor.client import SupervisorClient


class GitController(BaseController):
    def __init__(
        self,
        paths: PathPolicy,
        connectors: ConnectorService,
        supervisor: SupervisorClient,
    ) -> None:
        self._paths = paths
        self._connectors = connectors
        self._supervisor = supervisor

    def argument_schema(self, method: str) -> dict[str, Any]:
        path = {"type": "string", "maxLength": 32767}
        if method == "status":
            return _schema({"path": path}, ["path"])
        if method == "commit":
            return _schema(
                {
                    "path": path,
                    "message": {"type": "string", "minLength": 1, "maxLength": 500},
                    "paths": {
                        "type": "array",
                        "items": {"type": "string", "maxLength": 32767},
                        "minItems": 1,
                        "maxItems": 1000,
                    },
                },
                ["path", "message", "paths"],
            )
        if method == "push":
            return _schema(
                {
                    "path": path,
                    "connector_id": {"type": "string", "format": "uuid"},
                    "branch": {
                        "type": "string",
                        "pattern": "^[A-Za-z0-9][A-Za-z0-9._/-]{0,199}$",
                    },
                },
                ["path", "connector_id"],
            )
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown GitController method.")

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        resolved = await self._paths.resolve(str(arguments["path"]), identity, must_exist=True)
        repo = resolved.path
        if not repo.is_dir() or not (repo / ".git").exists():
            raise QError(QErrorCode.VALIDATION_ERROR, "Path is not a Git working tree.")
        normalized = dict(arguments)
        normalized["path"] = str(repo)
        resource = str(repo)
        if method == "commit":
            normalized["paths"] = _normalize_repo_paths(repo, arguments["paths"])
        if method == "push":
            connector = await self._connectors.resolve(UUID(str(arguments["connector_id"])))
            if connector.connector.connector_type is not ConnectorType.GIT_HTTPS:
                raise QError(QErrorCode.VALIDATION_ERROR, "Connector is not Git HTTPS.")
            host = connector.endpoint.split("/", 3)[2].split(":", 1)[0].lower()
            normalized.update(
                {
                    "endpoint": connector.endpoint,
                    "username": connector.username,
                    "credential_ref": connector.credential_ref,
                }
            )
            resource = host
        normalized["_policy"] = {
            "resource": resource,
            "outside_workspace": resolved.outside_workspace,
        }
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        repo = str(arguments["path"])
        try:
            if method == "status":
                status = porcelain.status(repo, untracked_files="all")
                return ControllerResult(data=_status(status), resource=repo)
            if method == "commit":
                porcelain.add(repo, paths=list(arguments["paths"]))
                commit_id = porcelain.commit(repo, message=str(arguments["message"]))
                commit_text = commit_id.decode("ascii")
                return ControllerResult(
                    data={"commit_id": commit_text},
                    resource=repo,
                    provenance_outputs=[{"type": "git_commit", "commit_id": commit_text}],
                )
            if method == "push":
                if identity.mode is ApplicationMode.LOCAL_ONLY:
                    raise QError(
                        QErrorCode.NETWORK_DISABLED,
                        "Network is disabled in Local Only mode.",
                    )
                endpoint = str(arguments["endpoint"])
                await validate_public_destination(endpoint)
                credential_ref = arguments.get("credential_ref")
                if not isinstance(credential_ref, str):
                    raise QError(
                        QErrorCode.RUNTIME_UNAVAILABLE,
                        "Git push connector has no credential reference.",
                    )
                secret = await self._supervisor.resolve_credential(credential_ref)
                output = io.BytesIO()
                refspecs = str(arguments["branch"]) if "branch" in arguments else None
                try:
                    porcelain.push(
                        repo,
                        remote_location=endpoint,
                        refspecs=refspecs,
                        outstream=output,
                        errstream=output,
                        username=str(arguments.get("username") or "git"),
                        password=secret,
                    )
                finally:
                    secret = ""
                return ControllerResult(
                    data={"pushed": True, "detail": output.getvalue().decode(errors="replace")},
                    resource=endpoint.split("/", 3)[2],
                    provenance_outputs=[{"type": "git_push"}],
                )
        except QError:
            raise
        except (NotGitRepository, OSError, ValueError, KeyError) as exc:
            raise QError(QErrorCode.RUNTIME_UNAVAILABLE, "Git operation failed.") from exc
        raise QError(QErrorCode.VALIDATION_ERROR, "Unknown GitController method.")


def _normalize_repo_paths(repo: Path, value: object) -> list[str]:
    if not isinstance(value, list):
        raise QError(QErrorCode.VALIDATION_ERROR, "Git paths must be a list.")
    normalized: list[str] = []
    for item in value:
        relative = Path(str(item))
        if relative.is_absolute() or ".." in relative.parts:
            raise QError(QErrorCode.SANDBOX_VIOLATION, "Git path escapes the repository.")
        candidate = (repo / relative).resolve(strict=False)
        try:
            candidate.relative_to(repo.resolve(strict=True))
        except ValueError as exc:
            raise QError(QErrorCode.SANDBOX_VIOLATION, "Git path escapes the repository.") from exc
        normalized.append(relative.as_posix())
    return normalized


def _status(status: porcelain.GitStatus) -> dict[str, object]:
    staged = {
        str(kind): [_decode(path) for path in paths]
        for kind, paths in status.staged.items()
    }
    return {
        "staged": staged,
        "unstaged": [_decode(path) for path in status.unstaged],
        "untracked": [_decode(path) for path in status.untracked],
    }


def _decode(value: bytes | str) -> str:
    return value.decode("utf-8", errors="replace") if isinstance(value, bytes) else value


def _schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": properties,
        "required": required,
        "additionalProperties": False,
    }
