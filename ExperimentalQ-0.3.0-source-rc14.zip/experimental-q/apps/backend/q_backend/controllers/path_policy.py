"""Canonical path normalization and authorized-root enforcement."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath

from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity
from q_backend.projects.service import ProjectService


@dataclass(frozen=True, slots=True)
class ResolvedPath:
    path: Path
    root: Path
    outside_workspace: bool
    leaf_link: Path | None = None


class PathPolicy:
    def __init__(self, projects: ProjectService, workspace: Path) -> None:
        self._projects = projects
        self._workspace = workspace.resolve()

    async def resolve(
        self,
        value: str,
        identity: InvocationIdentity,
        *,
        must_exist: bool,
    ) -> ResolvedPath:
        if identity.project_id is None:
            raise QError(QErrorCode.VALIDATION_ERROR, "A project_id is required.")
        if not value or "\x00" in value or len(value) > 32_767:
            raise QError(QErrorCode.VALIDATION_ERROR, "Path is invalid.")
        if _is_forbidden_windows_path(value):
            raise QError(QErrorCode.SANDBOX_VIOLATION, "Device and UNC paths are denied.")
        roots = await self._projects.roots(identity.project_id)
        project_root = roots[0]
        raw = Path(value)
        if raw.is_absolute():
            candidate = raw
        else:
            if any(part == ".." for part in raw.parts):
                raise QError(QErrorCode.SANDBOX_VIOLATION, "Path traversal is denied.")
            candidate = project_root / raw
        try:
            if must_exist:
                lexical = candidate.parent.resolve(strict=True) / candidate.name
                resolved = candidate.resolve(strict=True)
            else:
                parent = candidate.parent.resolve(strict=True)
                lexical = parent / candidate.name
                resolved = parent / candidate.name
        except OSError as exc:
            raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Path does not exist.") from exc
        for root in roots:
            canonical_root = root.resolve(strict=True)
            if _is_within(resolved, canonical_root) and _is_within(lexical, canonical_root):
                return ResolvedPath(
                    path=resolved,
                    root=canonical_root,
                    outside_workspace=not _is_within(canonical_root, self._workspace),
                    leaf_link=(
                        lexical
                        if lexical.is_symlink()
                        or (hasattr(lexical, "is_junction") and lexical.is_junction())
                        else None
                    ),
                )
        raise QError(
            QErrorCode.SANDBOX_VIOLATION,
            "Path is outside authorized roots.",
        )


def _is_within(path: Path, root: Path) -> bool:
    try:
        return os.path.commonpath(
            (os.path.normcase(path), os.path.normcase(root))
        ) == os.path.normcase(root)
    except ValueError:
        return False


def _is_forbidden_windows_path(value: str) -> bool:
    normalized = value.replace("/", "\\")
    lowered = normalized.lower()
    if lowered.startswith(("\\\\", "\\?\\", "\\.\\")):
        return True
    path = PureWindowsPath(normalized)
    if path.drive and path.drive.lower() in {"c:", "c:\\"}:
        protected = ("windows", "program files", "program files (x86)")
        parts = tuple(part.lower() for part in path.parts[1:])
        return bool(parts and parts[0] in protected)
    return False
