"""Structured scholarly metadata search over a fixed HTTPS provider."""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlencode

import httpx

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.controllers.web import bounded_https_get
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import ApplicationMode, InvocationIdentity

_CROSSREF = "https://api.crossref.org/works"


class ResearchController(BaseController):
    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=8.0),
            follow_redirects=False,
            trust_env=False,
            headers={"User-Agent": "ExperimentalQ/3.0 (local research client)"},
        )

    def argument_schema(self, method: str) -> dict[str, Any]:
        if method != "search":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown ResearchController method.")
        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "required": ["query"],
            "properties": {
                "query": {"type": "string", "minLength": 1, "maxLength": 1000},
                "limit": {"type": "integer", "minimum": 1, "maximum": 50},
                "from_year": {"type": "integer", "minimum": 1000, "maximum": 9999},
            },
            "additionalProperties": False,
        }

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        del method, identity
        normalized = dict(arguments)
        normalized["_policy"] = {"resource": "api.crossref.org", "domain": "api.crossref.org"}
        return normalized

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        if identity.mode is ApplicationMode.LOCAL_ONLY:
            raise QError(QErrorCode.NETWORK_DISABLED, "Network is disabled in Local Only mode.")
        if method != "search":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown ResearchController method.")
        limit = int(arguments.get("limit", 10))
        parameters = {"query": str(arguments["query"]), "rows": str(limit)}
        if "from_year" in arguments:
            parameters["filter"] = f"from-pub-date:{int(arguments['from_year'])}-01-01"
        url = f"{_CROSSREF}?{urlencode(parameters)}"
        _final, content, _content_type = await bounded_https_get(
            self._client,
            url,
            5 * 1024 * 1024,
        )
        try:
            body = json.loads(content)
            items = body["message"]["items"]
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            raise QError(
                QErrorCode.INTERNAL_ERROR,
                "Research provider returned invalid data.",
            ) from exc
        results: list[dict[str, object]] = []
        for item in items[:limit]:
            if not isinstance(item, dict):
                continue
            title_value = item.get("title") or []
            title = str(title_value[0]) if isinstance(title_value, list) and title_value else ""
            authors = item.get("author") or []
            results.append(
                {
                    "title": title,
                    "doi": item.get("DOI"),
                    "url": item.get("URL"),
                    "type": item.get("type"),
                    "published": item.get("published"),
                    "authors": [
                        " ".join(
                            str(author.get(key, "")) for key in ("given", "family")
                        ).strip()
                        for author in authors
                        if isinstance(author, dict)
                    ],
                }
            )
        return ControllerResult(
            data={"provider": "Crossref", "query": arguments["query"], "results": results},
            resource="api.crossref.org",
            provenance_inputs=[{"url": _CROSSREF}],
            provenance_outputs=[{"type": "research_results", "count": len(results)}],
        )

    async def close(self) -> None:
        await self._client.aclose()
