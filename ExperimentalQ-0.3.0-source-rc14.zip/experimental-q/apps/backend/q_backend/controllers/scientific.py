"""Deterministic, enumerated scientific analyses without arbitrary code."""

from __future__ import annotations

import asyncio
import math
from collections.abc import Mapping
from typing import Any

import numpy as np
from scipy import stats
from sklearn.linear_model import LinearRegression

from q_backend.controllers.base import BaseController, ControllerResult
from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import InvocationIdentity


class ScientificController(BaseController):
    def argument_schema(self, method: str) -> dict[str, Any]:
        if method != "analyze":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown scientific method.")
        number_array = {
            "type": "array",
            "items": {"type": "number"},
            "minItems": 1,
            "maxItems": 1_000_000,
        }
        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "required": ["operation", "x"],
            "properties": {
                "operation": {
                    "enum": [
                        "descriptive_statistics",
                        "correlation",
                        "linear_regression",
                        "t_test_independent",
                        "normality_test",
                        "bootstrap_mean_ci",
                    ]
                },
                "x": number_array,
                "y": number_array,
                "confidence": {"type": "number", "minimum": 0.5, "maximum": 0.999},
                "seed": {"type": "integer", "minimum": 0, "maximum": 4294967295},
                "resamples": {"type": "integer", "minimum": 100, "maximum": 100000},
            },
            "additionalProperties": False,
        }

    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        del identity
        if method != "analyze":
            raise QError(QErrorCode.VALIDATION_ERROR, "Unknown scientific method.")
        return await asyncio.to_thread(self._analyze, arguments)

    @staticmethod
    def _analyze(arguments: dict[str, Any]) -> ControllerResult:
        operation = str(arguments["operation"])
        x = _finite_array(arguments["x"], "x")
        confidence_value = float(arguments.get("confidence", 0.95))
        seed_value = int(arguments.get("seed", 0))
        parameters: dict[str, object] = {
            "operation": operation,
            "confidence": confidence_value,
            "seed": seed_value,
        }
        if operation == "descriptive_statistics":
            result: dict[str, object] = dict(_descriptive(x))
        elif operation == "normality_test":
            if not 3 <= x.size <= 5000:
                raise QError(
                    QErrorCode.VALIDATION_ERROR,
                    "normality_test requires between 3 and 5000 observations.",
                )
            statistic, p_value = stats.shapiro(x)
            result = {"test": "Shapiro-Wilk", "statistic": statistic, "p_value": p_value}
        elif operation == "bootstrap_mean_ci":
            confidence = confidence_value
            seed = seed_value
            resamples = int(arguments.get("resamples", 10_000))
            parameters["resamples"] = resamples
            rng = np.random.default_rng(seed)
            indices = rng.integers(0, x.size, size=(resamples, x.size))
            means = x[indices].mean(axis=1)
            alpha = (1.0 - confidence) / 2.0
            result = {
                "mean": float(x.mean()),
                "confidence": confidence,
                "ci_low": float(np.quantile(means, alpha)),
                "ci_high": float(np.quantile(means, 1.0 - alpha)),
                "seed": seed,
            }
        else:
            if "y" not in arguments:
                raise QError(QErrorCode.VALIDATION_ERROR, f"{operation} requires y.")
            y = _finite_array(arguments["y"], "y")
            if operation in {"correlation", "linear_regression"} and x.size != y.size:
                raise QError(QErrorCode.VALIDATION_ERROR, "x and y must have equal length.")
            if operation == "correlation":
                if x.size < 2:
                    raise QError(QErrorCode.VALIDATION_ERROR, "Correlation requires two rows.")
                pearson = stats.pearsonr(x, y)
                spearman = stats.spearmanr(x, y)
                result = {
                    "pearson_r": pearson.statistic,
                    "pearson_p_value": pearson.pvalue,
                    "spearman_rho": spearman.statistic,
                    "spearman_p_value": spearman.pvalue,
                }
            elif operation == "linear_regression":
                if x.size < 2:
                    raise QError(QErrorCode.VALIDATION_ERROR, "Regression requires two rows.")
                model = LinearRegression().fit(x.reshape(-1, 1), y)
                result = {
                    "intercept": float(model.intercept_),
                    "slope": float(model.coef_[0]),
                    "r_squared": float(model.score(x.reshape(-1, 1), y)),
                    "n": int(x.size),
                }
            elif operation == "t_test_independent":
                test = stats.ttest_ind(x, y, equal_var=False)
                result = {
                    "test": "Welch independent t-test",
                    "statistic": test.statistic,
                    "p_value": test.pvalue,
                    "n_x": int(x.size),
                    "n_y": int(y.size),
                }
            else:
                raise QError(QErrorCode.VALIDATION_ERROR, "Unknown scientific operation.")
        return ControllerResult(
            data=_json_numbers(result),
            provenance_parameters=parameters,
            provenance_outputs=[{"type": "analysis_result", "operation": operation}],
        )


def _finite_array(value: object, name: str) -> np.ndarray[Any, np.dtype[np.float64]]:
    data = np.asarray(value, dtype=np.float64)
    if data.ndim != 1 or data.size == 0 or not np.isfinite(data).all():
        raise QError(QErrorCode.VALIDATION_ERROR, f"{name} must contain finite numbers.")
    return data


def _descriptive(data: np.ndarray[Any, np.dtype[np.float64]]) -> dict[str, float | int]:
    return {
        "count": int(data.size),
        "mean": float(data.mean()),
        "standard_deviation": float(data.std(ddof=1)) if data.size > 1 else 0.0,
        "minimum": float(data.min()),
        "q1": float(np.quantile(data, 0.25)),
        "median": float(np.median(data)),
        "q3": float(np.quantile(data, 0.75)),
        "maximum": float(data.max()),
    }


def _json_numbers(values: Mapping[str, object]) -> dict[str, object]:
    normalized: dict[str, object] = {}
    for key, value in values.items():
        if isinstance(value, np.generic):
            value = value.item()
        if isinstance(value, float) and not math.isfinite(value):
            normalized[key] = None
        else:
            normalized[key] = value
    return normalized
