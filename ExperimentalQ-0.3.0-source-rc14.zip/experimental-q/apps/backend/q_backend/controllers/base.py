"""Base controller contract. Controllers are the only backend OS-resource boundary."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from q_backend.models.permissions import InvocationIdentity


@dataclass(slots=True)
class ControllerResult:
    data: Any
    resource: str | None = None
    provenance_inputs: list[dict[str, Any]] = field(default_factory=list)
    provenance_outputs: list[dict[str, Any]] = field(default_factory=list)
    provenance_parameters: dict[str, Any] = field(default_factory=dict)


class BaseController(ABC):
    @abstractmethod
    def argument_schema(self, method: str) -> dict[str, Any]:
        """Return the method's Draft 2020-12 JSON schema."""

    async def normalize_arguments(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> dict[str, Any]:
        del method, identity
        return arguments

    @abstractmethod
    async def invoke(
        self,
        method: str,
        arguments: dict[str, Any],
        identity: InvocationIdentity,
    ) -> ControllerResult:
        """Execute only a typed method with already-normalized arguments."""
