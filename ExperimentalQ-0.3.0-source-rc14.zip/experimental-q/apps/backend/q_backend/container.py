"""Application composition root; owns backend service lifecycles."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from q_backend.artifacts.service import ArtifactService
from q_backend.audit.service import AuditService
from q_backend.config import Settings
from q_backend.connectors.service import ConnectorService
from q_backend.controllers.audio import AudioController
from q_backend.controllers.base import BaseController
from q_backend.controllers.document import DocumentController
from q_backend.controllers.file import FileController
from q_backend.controllers.git import GitController
from q_backend.controllers.memory import MemoryController
from q_backend.controllers.package import PackageController
from q_backend.controllers.path_policy import PathPolicy
from q_backend.controllers.pdf import PDFController
from q_backend.controllers.python_sandbox import PythonSandbox
from q_backend.controllers.python_scientific import StructuredPythonController
from q_backend.controllers.r import RController
from q_backend.controllers.research import ResearchController
from q_backend.controllers.scientific import ScientificController
from q_backend.controllers.spreadsheet import SpreadsheetController
from q_backend.controllers.sql import SQLController
from q_backend.controllers.system_resource import SystemResourceController
from q_backend.controllers.visualization import VisualizationController
from q_backend.controllers.web import WebController
from q_backend.memory.service import MemoryService
from q_backend.memory.vector_store import QdrantLocalVectorStore
from q_backend.models.permissions import ApplicationMode
from q_backend.notebook.service import NotebookService
from q_backend.orchestrator.context import ContextBuilder
from q_backend.orchestrator.service import ChatOrchestrator
from q_backend.permissions.manager import PermissionManager
from q_backend.policy.engine import PolicyEngine
from q_backend.projects.service import ProjectService
from q_backend.provenance.service import ProvenanceService
from q_backend.runtimes.llama_cpp import LlamaCppAdapter
from q_backend.services.model import ModelService
from q_backend.storage.database import Database
from q_backend.supervisor.client import OfflineSupervisorClient, SocketSupervisorClient
from q_backend.tools.manager import ToolManager
from q_backend.tools.registry import ToolRegistry


@dataclass(slots=True)
class AppContainer:
    settings: Settings
    database: Database
    supervisor: SocketSupervisorClient | OfflineSupervisorClient
    runtime: LlamaCppAdapter
    models: ModelService
    registry: ToolRegistry
    permissions: PermissionManager
    policy: PolicyEngine
    audit: AuditService
    provenance: ProvenanceService
    artifacts: ArtifactService
    memory: MemoryService
    web: WebController
    research: ResearchController
    connectors: ConnectorService
    audio: AudioController
    projects: ProjectService
    chat: ChatOrchestrator
    notebooks: NotebookService
    tools: ToolManager

    async def close(self) -> None:
        await self.models.close()
        await self.web.close()
        await self.research.close()
        self.memory.close()
        self.database.close()


def build_container(settings: Settings) -> AppContainer:
    settings.ensure_directories()
    root = settings.resource_root or Path(__file__).resolve().parents[3]
    database = Database(settings.database_path)
    database.initialize()
    if settings.supervisor_port is not None and settings.supervisor_token is not None:
        supervisor: SocketSupervisorClient | OfflineSupervisorClient = SocketSupervisorClient(
            settings.supervisor_port,
            settings.supervisor_token,
        )
    else:
        supervisor = OfflineSupervisorClient()
    runtime = LlamaCppAdapter(supervisor)
    models = ModelService(supervisor, runtime, database)
    permissions = PermissionManager(database, settings.session_token)
    registry = ToolRegistry.from_file(root / "config" / "tool_registry.json")
    policy = PolicyEngine.from_file(root / "config" / "permission_policy.yaml", permissions)
    audit = AuditService(database, settings.audit_log_path)
    provenance = ProvenanceService(database)
    artifacts = ArtifactService(database)
    projects = ProjectService(database, settings.workspace)
    connectors = ConnectorService(database)
    paths = PathPolicy(projects, settings.workspace)
    vectors = QdrantLocalVectorStore(settings.workspace / "Metadata" / "Qdrant")
    memory = MemoryService(database, vectors)
    memory.bootstrap_seed(root / "config" / "personal_context.seed.json")
    scientific = ScientificController()
    python_sandbox = PythonSandbox(supervisor, projects)
    web = WebController(paths)
    research = ResearchController()
    audio = AudioController(supervisor, settings.workspace / "Temp")
    controllers: dict[str, BaseController] = {
        "FileController": FileController(paths),
        "GitController": GitController(paths, connectors, supervisor),
        "MemoryController": MemoryController(memory),
        "DocumentController": DocumentController(paths),
        "PDFController": PDFController(paths),
        "PythonController": StructuredPythonController(scientific, python_sandbox),
        "RController": RController(supervisor, projects),
        "SQLController": SQLController(supervisor, projects),
        "PackageController": PackageController(
            supervisor,
            projects,
            paths,
            root / "config" / "package_allowlist.json",
        ),
        "SystemResourceController": SystemResourceController(supervisor),
        "ScientificController": scientific,
        "WebController": web,
        "ResearchController": research,
        "SpreadsheetController": SpreadsheetController(paths),
        "VisualizationController": VisualizationController(paths),
    }
    tools = ToolManager(
        registry,
        controllers=controllers,
        policy=policy,
        permissions=permissions,
        audit=audit,
        provenance=provenance,
    )
    chat = ChatOrchestrator(
        database,
        runtime,
        tools,
        ContextBuilder(),
        memory,
        mode=ApplicationMode(settings.mode),
        max_tool_iterations=settings.max_tool_iterations,
    )
    notebooks = NotebookService(database, projects, tools, chat)
    return AppContainer(
        settings=settings,
        database=database,
        supervisor=supervisor,
        runtime=runtime,
        models=models,
        registry=registry,
        permissions=permissions,
        policy=policy,
        audit=audit,
        provenance=provenance,
        artifacts=artifacts,
        memory=memory,
        web=web,
        research=research,
        connectors=connectors,
        audio=audio,
        projects=projects,
        chat=chat,
        notebooks=notebooks,
        tools=tools,
    )
