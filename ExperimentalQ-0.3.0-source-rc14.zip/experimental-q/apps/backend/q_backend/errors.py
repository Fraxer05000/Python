"""Typed errors shared by API and internal services."""

from __future__ import annotations

from enum import StrEnum
from typing import Any
from uuid import uuid4


class QErrorCode(StrEnum):
    VALIDATION_ERROR = "validation_error"
    PERMISSION_DENIED = "permission_denied"
    CONFIRMATION_REQUIRED = "confirmation_required"
    RESOURCE_NOT_FOUND = "resource_not_found"
    SANDBOX_VIOLATION = "sandbox_violation"
    NETWORK_DISABLED = "network_disabled"
    RUNTIME_UNAVAILABLE = "runtime_unavailable"
    MODEL_UNAVAILABLE = "model_unavailable"
    TIMEOUT = "timeout"
    INTERNAL_ERROR = "internal_error"


class QError(Exception):
    """Base exception whose public representation never contains a stack trace."""

    def __init__(
        self,
        code: QErrorCode,
        message: str,
        *,
        details: dict[str, Any] | None = None,
        correlation_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}
        self.correlation_id = correlation_id or str(uuid4())

    def as_dict(self) -> dict[str, Any]:
        return {
            "code": self.code.value,
            "message": self.message,
            "details": self.details,
            "correlation_id": self.correlation_id,
        }
