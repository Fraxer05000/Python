"""Local memory and retrieval adapters."""
