"""VectorStore interface and local Qdrant implementation."""

from __future__ import annotations

import hashlib
import math
import re
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Protocol, cast

from qdrant_client import QdrantClient, models

_DIMENSIONS = 384
_TOKEN = re.compile(r"[\wáéíóúñüÁÉÍÓÚÑÜ]+", re.UNICODE)


class VectorHit(Protocol):
    id: object
    score: float


class VectorStore(Protocol):
    def put(self, record_id: str, text: str, payload: dict[str, str]) -> None: ...

    def search(
        self,
        text: str,
        *,
        filters: dict[str, str],
        limit: int,
    ) -> list[tuple[str, float]]: ...

    def remove(self, record_ids: Sequence[str]) -> None: ...

    def close(self) -> None: ...


class QdrantLocalVectorStore:
    _COLLECTION = "experimental_q_memory_v1"

    def __init__(self, path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)
        self._client = QdrantClient(path=str(path))
        if not self._client.collection_exists(self._COLLECTION):
            self._client.create_collection(
                self._COLLECTION,
                vectors_config=models.VectorParams(
                    size=_DIMENSIONS,
                    distance=models.Distance.COSINE,
                ),
            )

    def put(self, record_id: str, text: str, payload: dict[str, str]) -> None:
        self._client.upsert(
            collection_name=self._COLLECTION,
            points=[
                models.PointStruct(
                    id=record_id,
                    vector=_embedding(text),
                    payload=payload,
                )
            ],
            wait=True,
        )

    def search(
        self,
        text: str,
        *,
        filters: dict[str, str],
        limit: int,
    ) -> list[tuple[str, float]]:
        conditions = [
            models.FieldCondition(key=key, match=models.MatchValue(value=value))
            for key, value in filters.items()
        ]
        response = self._client.query_points(
            collection_name=self._COLLECTION,
            query=_embedding(text),
            query_filter=models.Filter(must=cast(Any, conditions)),
            limit=limit,
            with_payload=False,
        )
        return [
            (str(point.id), max(0.0, min(1.0, float(point.score))))
            for point in response.points
        ]

    def remove(self, record_ids: Sequence[str]) -> None:
        if record_ids:
            self._client.delete(
                collection_name=self._COLLECTION,
                points_selector=models.PointIdsList(points=list(record_ids)),
                wait=True,
            )

    def close(self) -> None:
        self._client.close()


def _embedding(text: str) -> list[float]:
    vector = [0.0] * _DIMENSIONS
    for token in _TOKEN.findall(text.casefold()):
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        index = int.from_bytes(digest[:4], "little") % _DIMENSIONS
        sign = 1.0 if digest[4] & 1 else -1.0
        vector[index] += sign
    norm = math.sqrt(sum(value * value for value in vector))
    if norm == 0:
        vector[0] = 1.0
        return vector
    return [value / norm for value in vector]
