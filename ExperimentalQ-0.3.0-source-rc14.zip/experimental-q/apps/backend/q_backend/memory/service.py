"""Explicit persistent memory, project isolation, and local retrieval."""

from __future__ import annotations

import asyncio
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID, uuid4

from sqlalchemy import select

from q_backend.errors import QError, QErrorCode
from q_backend.memory.vector_store import VectorStore
from q_backend.models.memory import (
    KnowledgeIndexRequest,
    KnowledgeIndexResult,
    MemoryRecord,
    MemoryScope,
    MemorySearchResult,
)
from q_backend.storage.database import Database, MemoryRecordRow

_HEADING = re.compile(r"^(#{1,6}\s+.+|[^\n]{1,160}\n[-=]{3,})$", re.MULTILINE)


class MemoryService:
    def __init__(self, database: Database, vectors: VectorStore) -> None:
        self._database = database
        self._vectors = vectors
        self._lock = asyncio.Lock()
        self._session: dict[str, dict[str, str]] = {}

    def bootstrap_seed(self, path: Path) -> None:
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise QError(QErrorCode.VALIDATION_ERROR, "Personal context seed is invalid.") from exc
        if document.get("authorization") != "explicit_user_request_2026-08-19":
            raise QError(QErrorCode.PERMISSION_DENIED, "Personal context seed lacks authorization.")
        records = document.get("records")
        if not isinstance(records, list):
            raise QError(QErrorCode.VALIDATION_ERROR, "Personal context seed has no records.")
        for item in records:
            if not isinstance(item, dict):
                raise QError(
                    QErrorCode.VALIDATION_ERROR,
                    "Personal context seed record is invalid.",
                )
            category = str(item.get("category", "preference"))
            content = str(item.get("content", "")).strip()
            if not content:
                continue
            source = f"personal_context.seed.json#{category}"
            self._save_sync(
                scope=MemoryScope.USER,
                content=content,
                source=source,
                project_id=None,
                user_id="local_user",
                sensitivity=False,
                deduplicate_source=True,
            )

    async def save(
        self,
        *,
        scope: MemoryScope,
        content: str,
        source: str,
        project_id: str | None,
        user_id: str,
        sensitivity: bool,
    ) -> MemoryRecord:
        if sensitivity:
            raise QError(
                QErrorCode.RUNTIME_UNAVAILABLE,
                "Sensitive memory requires an encrypted vault and was not stored.",
            )
        if scope in {MemoryScope.PROJECT, MemoryScope.KNOWLEDGE} and project_id is None:
            raise QError(QErrorCode.VALIDATION_ERROR, "Project memory requires project_id.")
        async with self._lock:
            return await asyncio.to_thread(
                self._save_sync,
                scope,
                content,
                source,
                project_id,
                user_id,
                sensitivity,
                False,
            )

    def _save_sync(
        self,
        scope: MemoryScope,
        content: str,
        source: str,
        project_id: str | None,
        user_id: str,
        sensitivity: bool,
        deduplicate_source: bool,
    ) -> MemoryRecord:
        if deduplicate_source:
            with self._database.session() as session:
                existing = session.scalar(
                    select(MemoryRecordRow).where(
                        MemoryRecordRow.scope == scope.value,
                        MemoryRecordRow.user_id == user_id,
                        MemoryRecordRow.source == source,
                        MemoryRecordRow.deleted.is_(False),
                    )
                )
                if existing is not None:
                    return _record(existing)
        memory_id = str(uuid4())
        timestamp = datetime.now(UTC).isoformat()
        payload = {
            "scope": scope.value,
            "user_id": user_id,
            "project_id": project_id or "",
        }
        self._vectors.put(memory_id, content, payload)
        row = MemoryRecordRow(
            memory_id=memory_id,
            scope=scope.value,
            user_id=user_id,
            project_id=project_id,
            content=content,
            source=source,
            sensitivity=sensitivity,
            vector_ref=memory_id,
            created_at_utc=timestamp,
            updated_at_utc=timestamp,
            deleted=False,
        )
        with self._database.session() as session:
            session.add(row)
        return _record(row)

    async def search(
        self,
        query: str,
        *,
        scope: MemoryScope,
        project_id: str | None,
        user_id: str,
        limit: int,
    ) -> list[MemorySearchResult]:
        if scope in {MemoryScope.PROJECT, MemoryScope.KNOWLEDGE} and project_id is None:
            raise QError(QErrorCode.VALIDATION_ERROR, "Project search requires project_id.")
        filters = {"scope": scope.value, "user_id": user_id}
        if project_id is not None:
            filters["project_id"] = project_id
        async with self._lock:
            hits = await asyncio.to_thread(
                self._vectors.search,
                query,
                filters=filters,
                limit=limit,
            )
            return await asyncio.to_thread(self._records_for_hits_sync, hits)

    def _records_for_hits_sync(
        self,
        hits: list[tuple[str, float]],
    ) -> list[MemorySearchResult]:
        if not hits:
            return []
        scores = dict(hits)
        with self._database.session() as session:
            rows = session.scalars(
                select(MemoryRecordRow).where(
                    MemoryRecordRow.memory_id.in_(scores),
                    MemoryRecordRow.deleted.is_(False),
                )
            ).all()
            by_id = {row.memory_id: row for row in rows}
            return [
                MemorySearchResult(record=_record(by_id[item_id]), score=score)
                for item_id, score in hits
                if item_id in by_id
            ]

    async def context(self, query: str, project_id: str | None) -> list[MemorySearchResult]:
        user = await self.search(
            query,
            scope=MemoryScope.USER,
            project_id=None,
            user_id="local_user",
            limit=5,
        )
        if project_id is None:
            return user
        project = await self.search(
            query,
            scope=MemoryScope.PROJECT,
            project_id=project_id,
            user_id="local_user",
            limit=5,
        )
        knowledge = await self.search(
            query,
            scope=MemoryScope.KNOWLEDGE,
            project_id=project_id,
            user_id="local_user",
            limit=5,
        )
        return sorted([*user, *project, *knowledge], key=lambda item: item.score, reverse=True)[:10]

    async def index_knowledge(self, request: KnowledgeIndexRequest) -> KnowledgeIndexResult:
        if not request.explicit_user_confirmation:
            raise QError(
                QErrorCode.CONFIRMATION_REQUIRED,
                "Indexing persistent knowledge requires explicit user confirmation.",
            )
        chunks = _structural_chunks(request.content)
        records = [
            await self.save(
                scope=MemoryScope.KNOWLEDGE,
                content=chunk,
                source=f"{request.source}#chunk={index + 1}",
                project_id=str(request.project_id),
                user_id="local_user",
                sensitivity=False,
            )
            for index, chunk in enumerate(chunks)
        ]
        return KnowledgeIndexResult(
            memory_ids=[record.memory_id for record in records],
            chunk_count=len(records),
        )

    async def delete(self, memory_id: UUID, *, explicit_confirmation: bool) -> None:
        if not explicit_confirmation:
            raise QError(QErrorCode.CONFIRMATION_REQUIRED, "Memory deletion requires confirmation.")
        async with self._lock:
            await asyncio.to_thread(self._delete_sync, str(memory_id))

    def _delete_sync(self, memory_id: str) -> None:
        with self._database.session() as session:
            row = session.get(MemoryRecordRow, memory_id)
            if row is None or row.deleted:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Memory record not found.")
            row.deleted = True
            row.updated_at_utc = datetime.now(UTC).isoformat()
            vector_ref = row.vector_ref
        self._vectors.remove([vector_ref])

    def session_put(self, session_id: str, key: str, value: str) -> None:
        self._session.setdefault(session_id, {})[key] = value

    def session_get(self, session_id: str, key: str) -> str | None:
        return self._session.get(session_id, {}).get(key)

    def session_clear(self, session_id: str) -> None:
        self._session.pop(session_id, None)

    def close(self) -> None:
        self._vectors.close()


def _record(row: MemoryRecordRow) -> MemoryRecord:
    return MemoryRecord(
        memory_id=UUID(row.memory_id),
        scope=MemoryScope(row.scope),
        project_id=UUID(row.project_id) if row.project_id else None,
        content=row.content,
        source=row.source,
        sensitivity=row.sensitivity,
        created_at_utc=datetime.fromisoformat(row.created_at_utc),
        updated_at_utc=datetime.fromisoformat(row.updated_at_utc),
    )


def _structural_chunks(content: str, maximum: int = 4000) -> list[str]:
    blocks = [block.strip() for block in re.split(r"\n\s*\n", content) if block.strip()]
    chunks: list[str] = []
    current = ""
    heading = ""
    for block in blocks:
        if _HEADING.match(block):
            heading = block
        candidate = "\n\n".join(value for value in (heading, current, block) if value)
        if current and len(candidate) > maximum:
            chunks.append("\n\n".join(value for value in (heading, current) if value))
            current = block
        else:
            current = "\n\n".join(value for value in (current, block) if value)
    if current:
        chunks.append("\n\n".join(value for value in (heading, current) if value))
    if not chunks:
        raise QError(QErrorCode.VALIDATION_ERROR, "Knowledge content is empty.")
    return chunks
