"""Model profile and lifecycle service."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

from sqlalchemy import select

from q_backend.errors import QError, QErrorCode
from q_backend.models.lifecycle import LifecycleSnapshot, ResourceSnapshot
from q_backend.models.runtime import ModelProfile
from q_backend.runtimes.base import ModelRuntimeAdapter
from q_backend.storage.database import Database, ModelProfileRow
from q_backend.supervisor.client import SupervisorClient


class ModelService:
    def __init__(
        self,
        supervisor: SupervisorClient,
        runtime: ModelRuntimeAdapter,
        database: Database,
    ) -> None:
        self._supervisor = supervisor
        self._runtime = runtime
        self._database = database
        self._lock = asyncio.Lock()

    async def put_profile(self, profile: ModelProfile) -> ModelProfile:
        async with self._lock:
            await asyncio.to_thread(self._put_profile_sync, profile)
        return profile

    def _put_profile_sync(self, profile: ModelProfile) -> None:
        now = datetime.now(UTC).isoformat()
        with self._database.session() as session:
            row = session.get(ModelProfileRow, profile.profile_id)
            if row is None:
                session.add(
                    ModelProfileRow(
                        profile_id=profile.profile_id,
                        profile_json=profile.model_dump_json(),
                        updated_at_utc=now,
                    )
                )
            else:
                row.profile_json = profile.model_dump_json()
                row.updated_at_utc = now

    async def list_profiles(self) -> list[ModelProfile]:
        async with self._lock:
            return await asyncio.to_thread(self._list_profiles_sync)

    def _list_profiles_sync(self) -> list[ModelProfile]:
        with self._database.session() as session:
            rows = session.scalars(select(ModelProfileRow)).all()
            profiles = [ModelProfile.model_validate_json(row.profile_json) for row in rows]
            return sorted(profiles, key=lambda item: item.name.casefold())

    async def start(self, profile_id: str) -> LifecycleSnapshot:
        async with self._lock:
            profile = await asyncio.to_thread(self._get_profile_sync, profile_id)
        if profile is None:
            raise QError(
                QErrorCode.RESOURCE_NOT_FOUND,
                "The requested model profile does not exist.",
                details={"profile_id": profile_id},
            )
        await self._runtime.load(profile)
        return await self._supervisor.state()

    def _get_profile_sync(self, profile_id: str) -> ModelProfile | None:
        with self._database.session() as session:
            row = session.get(ModelProfileRow, profile_id)
            return ModelProfile.model_validate_json(row.profile_json) if row else None

    async def sleep(self) -> LifecycleSnapshot:
        return await self._supervisor.sleep()

    async def stop(self) -> LifecycleSnapshot:
        await self._runtime.unload()
        return await self._supervisor.state()

    async def state(self) -> LifecycleSnapshot:
        return await self._supervisor.state()

    async def resources(self) -> ResourceSnapshot:
        return await self._supervisor.resources()

    async def close(self) -> None:
        await self._runtime.close()
