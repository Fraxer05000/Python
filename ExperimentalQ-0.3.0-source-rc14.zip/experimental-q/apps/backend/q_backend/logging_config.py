"""Structured JSON logging with value redaction."""

from __future__ import annotations

import json
import logging
from collections.abc import Iterable
from datetime import UTC, datetime
from typing import Any

_SENSITIVE_KEY_FRAGMENTS = frozenset(
    {
        "api_key",
        "apikey",
        "authorization",
        "credential",
        "password",
        "private_key",
        "secret",
        "token",
    }
)


def _sensitive_key(value: object) -> bool:
    normalized = str(value).casefold().replace("-", "_")
    return any(fragment in normalized for fragment in _SENSITIVE_KEY_FRAGMENTS)


def redact(value: Any, secret_values: tuple[str, ...] = ()) -> Any:
    if isinstance(value, dict):
        return {
            key: "[REDACTED]" if _sensitive_key(key) else redact(item, secret_values)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [redact(item, secret_values) for item in value]
    if isinstance(value, tuple):
        return tuple(redact(item, secret_values) for item in value)
    if isinstance(value, str):
        safe = value
        for secret in secret_values:
            safe = safe.replace(secret, "[REDACTED]")
        return safe
    return value


class JsonFormatter(logging.Formatter):
    def __init__(self, secret_values: Iterable[str] = ()) -> None:
        super().__init__()
        self._secret_values = tuple(
            sorted(
                {item for item in secret_values if len(item) >= 8},
                key=len,
                reverse=True,
            )
        )

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp_utc": datetime.now(UTC).isoformat(),
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": redact(record.getMessage(), self._secret_values),
        }
        context = getattr(record, "context", None)
        if isinstance(context, dict):
            payload["context"] = redact(context, self._secret_values)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def configure_logging(
    level: int = logging.INFO,
    *,
    secret_values: Iterable[str] = (),
) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter(secret_values))
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
