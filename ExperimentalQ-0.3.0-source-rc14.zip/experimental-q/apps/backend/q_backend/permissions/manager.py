"""One-time confirmation challenges; secrets are stored only as hashes."""

from __future__ import annotations

import asyncio
import hashlib
import json
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import UUID, uuid4

from sqlalchemy import select

from q_backend.errors import QError, QErrorCode
from q_backend.models.permissions import (
    InvocationIdentity,
    PermissionChallenge,
    PermissionConfirmation,
    PermissionGrant,
    PolicyOutcome,
)
from q_backend.models.tool import ToolDefinition, ToolRequest
from q_backend.storage.database import Database, PermissionChallengeRow, PermissionGrantRow


@dataclass(frozen=True, slots=True)
class ConfirmedInvocation:
    request: ToolRequest
    identity: InvocationIdentity
    normalized_arguments: dict[str, object]


class PermissionManager:
    def __init__(self, database: Database, secret_pepper: str) -> None:
        if len(secret_pepper) < 16:
            raise QError(QErrorCode.RUNTIME_UNAVAILABLE, "Permission secret pepper is weak.")
        self._database = database
        self._pepper = secret_pepper
        self._session_grants: set[tuple[str, str]] = set()
        self._lock = asyncio.Lock()

    async def issue(
        self,
        request: ToolRequest,
        definition: ToolDefinition,
        arguments: dict[str, object],
        identity: InvocationIdentity,
        outcome: PolicyOutcome,
    ) -> PermissionChallenge:
        async with self._lock:
            return await asyncio.to_thread(
                self._issue_sync,
                request,
                definition,
                arguments,
                identity,
                outcome,
            )

    def _issue_sync(
        self,
        request: ToolRequest,
        definition: ToolDefinition,
        arguments: dict[str, object],
        identity: InvocationIdentity,
        outcome: PolicyOutcome,
    ) -> PermissionChallenge:
        now = datetime.now(UTC)
        expires = now + timedelta(minutes=5)
        challenge_id = str(uuid4())
        confirmation_secret = secrets.token_urlsafe(48)
        resource = _resource(arguments)
        with self._database.session() as session:
            existing = session.scalar(
                select(PermissionChallengeRow).where(
                    PermissionChallengeRow.request_id == str(request.request_id)
                )
            )
            if existing is not None:
                raise QError(
                    QErrorCode.VALIDATION_ERROR,
                    "A confirmation challenge already exists for this request.",
                )
            session.add(
                PermissionChallengeRow(
                    challenge_id=challenge_id,
                    request_id=str(request.request_id),
                    secret_hash=self._hash_secret(confirmation_secret),
                    tool_name=definition.name,
                    resource=resource,
                    expires_at_utc=expires.isoformat(),
                    used=False,
                    request_json=request.model_dump_json(),
                    identity_json=identity.model_dump_json(),
                    normalized_arguments_json=json.dumps(arguments, separators=(",", ":")),
                    outcome_json=outcome.model_dump_json(),
                )
            )
        return PermissionChallenge(
            challenge_id=challenge_id,
            confirmation_secret=confirmation_secret,
            request_id=str(request.request_id),
            tool=definition.name,
            action=definition.method,
            resource=resource,
            reason=request.reason,
            destructive=outcome.destructive,
            allowed_scopes=_allowed_scopes(definition, resource),
            expires_at_utc=expires,
        )

    async def confirm(
        self,
        confirmation: PermissionConfirmation,
    ) -> ConfirmedInvocation | None:
        async with self._lock:
            return await asyncio.to_thread(self._confirm_sync, confirmation)

    def _confirm_sync(
        self,
        confirmation: PermissionConfirmation,
    ) -> ConfirmedInvocation | None:
        now = datetime.now(UTC)
        with self._database.session() as session:
            row = session.get(PermissionChallengeRow, confirmation.challenge_id)
            if row is None:
                raise QError(QErrorCode.RESOURCE_NOT_FOUND, "Confirmation challenge not found.")
            if row.used:
                raise QError(
                    QErrorCode.PERMISSION_DENIED,
                    "Confirmation challenge was already used.",
                )
            if datetime.fromisoformat(row.expires_at_utc) <= now:
                row.used = True
                raise QError(QErrorCode.PERMISSION_DENIED, "Confirmation challenge expired.")
            if not secrets.compare_digest(
                row.secret_hash,
                self._hash_secret(confirmation.confirmation_secret),
            ):
                raise QError(QErrorCode.PERMISSION_DENIED, "Confirmation secret is invalid.")
            row.used = True
            if not confirmation.allow:
                return None
            request = ToolRequest.model_validate_json(row.request_json)
            identity = InvocationIdentity.model_validate_json(row.identity_json)
            arguments_raw = json.loads(row.normalized_arguments_json)
            if not isinstance(arguments_raw, dict):
                raise QError(QErrorCode.INTERNAL_ERROR, "Stored confirmation data is invalid.")
            arguments: dict[str, object] = arguments_raw
            if confirmation.grant_scope is not None:
                allowed = _allowed_scopes_for_values(row.tool_name, row.resource)
                if confirmation.grant_scope not in allowed:
                    raise QError(
                        QErrorCode.VALIDATION_ERROR,
                        "The requested persistent grant scope is not allowed.",
                    )
                resource = _grant_resource(
                    confirmation.grant_scope,
                    row.resource,
                    identity,
                    arguments,
                )
                if (
                    confirmation.grant_resource is not None
                    and confirmation.grant_resource != resource
                ):
                    raise QError(
                        QErrorCode.PERMISSION_DENIED,
                        "The requested grant resource exceeds the confirmed scope.",
                    )
                expires = confirmation.expires_at_utc
                session.add(
                    PermissionGrantRow(
                        grant_id=str(uuid4()),
                        user_id=identity.user_id,
                        tool_name=row.tool_name,
                        scope=confirmation.grant_scope,
                        resource=resource,
                        created_at_utc=now.isoformat(),
                        expires_at_utc=expires.isoformat() if expires else None,
                        revoked=False,
                    )
                )
            self._session_grants.add((identity.session_id, row.tool_name))
        return ConfirmedInvocation(
            request=request,
            identity=identity,
            normalized_arguments=arguments,
        )

    async def has_grant(
        self,
        definition: ToolDefinition,
        identity: InvocationIdentity,
        resource: str | None,
    ) -> bool:
        if (identity.session_id, definition.name) in self._session_grants:
            return True
        return await asyncio.to_thread(
            self._has_persistent_grant_sync,
            definition,
            identity,
            resource,
        )

    def _has_persistent_grant_sync(
        self,
        definition: ToolDefinition,
        identity: InvocationIdentity,
        resource: str | None,
    ) -> bool:
        now = datetime.now(UTC)
        with self._database.session() as session:
            grants = session.scalars(
                select(PermissionGrantRow).where(
                    PermissionGrantRow.user_id == identity.user_id,
                    PermissionGrantRow.tool_name == definition.name,
                    PermissionGrantRow.revoked.is_(False),
                )
            ).all()
            for grant in grants:
                if grant.expires_at_utc and datetime.fromisoformat(grant.expires_at_utc) <= now:
                    continue
                if _resource_matches(grant.scope, grant.resource, resource, identity):
                    return True
        return False

    async def revoke(self, grant_id: str) -> bool:
        return await asyncio.to_thread(self._revoke_sync, grant_id)

    async def grants(self, user_id: str = "local_user") -> list[PermissionGrant]:
        return await asyncio.to_thread(self._grants_sync, user_id)

    def _grants_sync(self, user_id: str) -> list[PermissionGrant]:
        with self._database.session() as session:
            rows = session.scalars(
                select(PermissionGrantRow)
                .where(
                    PermissionGrantRow.user_id == user_id,
                    PermissionGrantRow.revoked.is_(False),
                )
                .order_by(PermissionGrantRow.created_at_utc.desc())
            ).all()
            return [
                PermissionGrant(
                    grant_id=UUID(row.grant_id),
                    tool_name=row.tool_name,
                    scope=row.scope,
                    resource=row.resource,
                    created_at_utc=datetime.fromisoformat(row.created_at_utc),
                    expires_at_utc=(
                        datetime.fromisoformat(row.expires_at_utc)
                        if row.expires_at_utc
                        else None
                    ),
                )
                for row in rows
            ]

    def _revoke_sync(self, grant_id: str) -> bool:
        with self._database.session() as session:
            grant = session.get(PermissionGrantRow, grant_id)
            if grant is None:
                return False
            grant.revoked = True
            return True

    def _hash_secret(self, secret: str) -> str:
        return hashlib.sha256(f"{self._pepper}:{secret}".encode()).hexdigest()


def _resource(arguments: dict[str, object]) -> str | None:
    policy = arguments.get("_policy")
    if isinstance(policy, dict):
        value = policy.get("resource")
        if isinstance(value, str):
            return value
    for key in ("path", "url", "repository", "database"):
        value = arguments.get(key)
        if isinstance(value, str):
            return value
    return None


def _allowed_scopes(definition: ToolDefinition, resource: str | None) -> list[str]:
    if definition.confirmation == "always":
        return []
    return _allowed_scopes_for_values(definition.name, resource)


def _allowed_scopes_for_values(tool_name: str, resource: str | None) -> list[str]:
    if resource is None:
        return []
    if tool_name in {
        "files.delete",
        "git.commit",
        "git.push",
        "memory.save_user",
        "packages.install",
    }:
        return []
    if tool_name.startswith("web.") or tool_name in {"git.push", "research.search"}:
        return ["domain"]
    if tool_name.startswith("files.") or tool_name.startswith("documents."):
        return ["folder", "project"]
    return ["project"]


def _grant_resource(
    scope: str,
    challenged_resource: str | None,
    identity: InvocationIdentity,
    arguments: dict[str, object],
) -> str:
    if scope == "project":
        if identity.project_id is None:
            raise QError(QErrorCode.VALIDATION_ERROR, "Project grant requires project scope.")
        return identity.project_id
    if challenged_resource is None:
        raise QError(QErrorCode.VALIDATION_ERROR, "Grant has no confirmed resource.")
    if scope in {"domain", "connector"}:
        return challenged_resource
    if scope == "folder":
        policy = arguments.get("_policy")
        policy_map = policy if isinstance(policy, dict) else {}
        scope_root = policy_map.get("scope_root")
        if isinstance(scope_root, str):
            return scope_root
        path = Path(challenged_resource)
        return str(path if path.is_dir() else path.parent)
    raise QError(QErrorCode.VALIDATION_ERROR, "Grant scope is invalid.")


def _resource_matches(
    scope: str,
    granted: str,
    requested: str | None,
    identity: InvocationIdentity,
) -> bool:
    if scope == "project":
        return identity.project_id is not None and granted == identity.project_id
    if requested is None:
        return False
    if scope == "folder":
        return (
            requested == granted
            or requested.startswith(f"{granted}\\")
            or requested.startswith(f"{granted}/")
        )
    if scope in {"domain", "connector"}:
        return requested == granted
    return False
