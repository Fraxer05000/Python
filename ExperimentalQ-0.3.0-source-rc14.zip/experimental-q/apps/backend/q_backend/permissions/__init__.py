"""One-time confirmations and revocable scoped grants."""

from q_backend.permissions.manager import ConfirmedInvocation, PermissionManager

__all__ = ["ConfirmedInvocation", "PermissionManager"]
