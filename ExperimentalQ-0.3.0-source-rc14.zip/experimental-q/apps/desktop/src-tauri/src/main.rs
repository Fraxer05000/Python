#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    experimental_q_desktop::run();
}
