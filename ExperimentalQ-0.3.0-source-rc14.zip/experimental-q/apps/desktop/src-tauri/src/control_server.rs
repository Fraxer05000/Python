use crate::supervisor::{
    resolve_credential, ModelProfileWire, Supervisor, WorkerCommand, WorkerKind,
};
use serde::{Deserialize, Serialize};
use std::io::{BufRead, BufReader, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread::{self, JoinHandle};
use std::time::Duration;

const MAX_REQUEST_BYTES: u64 = 10 * 1024 * 1024;

#[derive(Clone)]
pub struct WorkerCommands {
    pub python: WorkerCommand,
    pub sql: WorkerCommand,
    pub package: WorkerCommand,
    pub r: WorkerCommand,
    pub audio: WorkerCommand,
}

impl WorkerCommands {
    fn resolve(&self, kind: WorkerKind) -> &WorkerCommand {
        match kind {
            WorkerKind::Python => &self.python,
            WorkerKind::Sql => &self.sql,
            WorkerKind::Package => &self.package,
            WorkerKind::R => &self.r,
            WorkerKind::Audio => &self.audio,
        }
    }
}

#[derive(Debug, Deserialize)]
pub struct ControlRequest {
    token: String,
    #[serde(flatten)]
    action: ControlAction,
}

#[derive(Debug, Deserialize)]
#[serde(tag = "action", rename_all = "snake_case")]
enum ControlAction {
    State,
    Resources,
    RuntimeConnection,
    Start {
        profile: ModelProfileWire,
    },
    RunWorker {
        kind: WorkerKind,
        payload: String,
        working_directory: String,
        timeout_seconds: u64,
    },
    ResolveCredential {
        credential_ref: String,
    },
    Sleep,
    Stop,
}

#[derive(Debug, Serialize)]
struct ControlResponse {
    status: &'static str,
    data: Option<serde_json::Value>,
    error: Option<ControlError>,
}

#[derive(Debug, Serialize)]
struct ControlError {
    code: &'static str,
    message: String,
}

pub struct ControlServer {
    port: u16,
    token: String,
    shutdown: Arc<AtomicBool>,
    thread: Option<JoinHandle<()>>,
}

impl ControlServer {
    pub fn start(
        supervisor: Arc<Mutex<Supervisor>>,
        token: String,
        runtime_executable: PathBuf,
        worker_commands: WorkerCommands,
    ) -> Result<Self, String> {
        let listener = TcpListener::bind(("127.0.0.1", 0))
            .map_err(|error| format!("Could not bind supervisor control server: {error}"))?;
        let port = listener
            .local_addr()
            .map_err(|error| format!("Could not inspect supervisor control server: {error}"))?
            .port();
        listener
            .set_nonblocking(true)
            .map_err(|error| format!("Could not configure supervisor control server: {error}"))?;
        let shutdown = Arc::new(AtomicBool::new(false));
        let shutdown_thread = Arc::clone(&shutdown);
        let expected_token = token.clone();
        let thread = thread::Builder::new()
            .name("q-supervisor-control".to_owned())
            .spawn(move || {
                while !shutdown_thread.load(Ordering::Acquire) {
                    match listener.accept() {
                        Ok((stream, _address)) => {
                            let connection_token = expected_token.clone();
                            let connection_supervisor = Arc::clone(&supervisor);
                            let connection_runtime = runtime_executable.clone();
                            let connection_workers = worker_commands.clone();
                            let _ = thread::Builder::new()
                                .name("q-supervisor-request".to_owned())
                                .spawn(move || {
                                    handle_connection(
                                        stream,
                                        &connection_token,
                                        &connection_supervisor,
                                        &connection_runtime,
                                        &connection_workers,
                                    );
                                });
                        }
                        Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => {
                            thread::sleep(Duration::from_millis(30));
                        }
                        Err(error) => {
                            tracing::error!(%error, "Supervisor control listener failed");
                            break;
                        }
                    }
                }
            })
            .map_err(|error| format!("Could not start supervisor control thread: {error}"))?;
        Ok(Self {
            port,
            token,
            shutdown,
            thread: Some(thread),
        })
    }

    pub fn port(&self) -> u16 {
        self.port
    }

    pub fn token(&self) -> &str {
        &self.token
    }
}

impl Drop for ControlServer {
    fn drop(&mut self) {
        self.shutdown.store(true, Ordering::Release);
        let _ = TcpStream::connect(("127.0.0.1", self.port));
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

fn handle_connection(
    mut stream: TcpStream,
    expected_token: &str,
    supervisor: &Arc<Mutex<Supervisor>>,
    runtime_executable: &std::path::Path,
    worker_commands: &WorkerCommands,
) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(3)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(130)));
    let mut line = String::new();
    let read_result = BufReader::new(&stream)
        .take(MAX_REQUEST_BYTES)
        .read_line(&mut line);
    let response = match read_result {
        Ok(0) => error_response("validation_error", "Empty control request."),
        Ok(_) => match serde_json::from_str::<ControlRequest>(&line) {
            Ok(request) if constant_time_equal(&request.token, expected_token) => dispatch(
                request.action,
                supervisor,
                runtime_executable,
                worker_commands,
            ),
            Ok(_) => error_response("permission_denied", "Invalid supervisor token."),
            Err(error) => error_response("validation_error", &format!("Invalid request: {error}")),
        },
        Err(error) => error_response("validation_error", &format!("Read failed: {error}")),
    };
    if let Ok(payload) = serde_json::to_vec(&response) {
        let _ = stream.write_all(&payload);
        let _ = stream.write_all(b"\n");
        let _ = stream.flush();
    }
}

fn dispatch(
    action: ControlAction,
    supervisor: &Arc<Mutex<Supervisor>>,
    runtime_executable: &std::path::Path,
    worker_commands: &WorkerCommands,
) -> ControlResponse {
    if let ControlAction::RunWorker {
        kind,
        payload,
        working_directory,
        timeout_seconds,
    } = action
    {
        return dispatch_worker(
            supervisor,
            worker_commands.resolve(kind),
            &payload,
            &working_directory,
            timeout_seconds,
        );
    }
    let Ok(mut supervisor) = supervisor.lock() else {
        return error_response("internal_error", "Supervisor state is unavailable.");
    };
    let result: Result<serde_json::Value, String> = match action {
        ControlAction::State => {
            serde_json::to_value(supervisor.snapshot()).map_err(|error| error.to_string())
        }
        ControlAction::Resources => {
            serde_json::to_value(supervisor.resources()).map_err(|error| error.to_string())
        }
        ControlAction::RuntimeConnection => {
            serde_json::to_value(supervisor.runtime_connection()).map_err(|error| error.to_string())
        }
        ControlAction::Start { profile } => supervisor
            .start_model(&profile, runtime_executable)
            .map_err(|error| error.to_string())
            .and_then(|value| serde_json::to_value(value).map_err(|error| error.to_string())),
        ControlAction::Sleep => supervisor
            .sleep_model()
            .map_err(|error| error.to_string())
            .and_then(|value| serde_json::to_value(value).map_err(|error| error.to_string())),
        ControlAction::Stop => supervisor
            .stop_q()
            .map_err(|error| error.to_string())
            .and_then(|value| serde_json::to_value(value).map_err(|error| error.to_string())),
        ControlAction::RunWorker { .. } => {
            Err("worker dispatch reached an invalid state".to_owned())
        }
        ControlAction::ResolveCredential { credential_ref } => resolve_credential(&credential_ref)
            .map_err(|error| error.to_string())
            .and_then(|secret| serde_json::to_value(secret).map_err(|error| error.to_string())),
    };
    match result {
        Ok(value) => ControlResponse {
            status: "ok",
            data: Some(value),
            error: None,
        },
        Err(error) => error_response("runtime_unavailable", &error.to_string()),
    }
}

fn dispatch_worker(
    supervisor: &Arc<Mutex<Supervisor>>,
    command: &WorkerCommand,
    payload: &str,
    working_directory: &str,
    timeout_seconds: u64,
) -> ControlResponse {
    let worker_id = {
        let Ok(mut locked) = supervisor.lock() else {
            return error_response("internal_error", "Supervisor state is unavailable.");
        };
        match locked.start_worker(
            command,
            payload,
            std::path::Path::new(working_directory),
            timeout_seconds,
        ) {
            Ok(worker_id) => worker_id,
            Err(error) => return error_response("runtime_unavailable", &error.to_string()),
        }
    };
    loop {
        thread::sleep(Duration::from_millis(20));
        let result = {
            let Ok(mut locked) = supervisor.lock() else {
                return error_response("internal_error", "Supervisor state is unavailable.");
            };
            locked.poll_worker(worker_id)
        };
        match result {
            Ok(Some(value)) => {
                return match serde_json::to_value(value) {
                    Ok(data) => ControlResponse {
                        status: "ok",
                        data: Some(data),
                        error: None,
                    },
                    Err(error) => error_response("internal_error", &error.to_string()),
                };
            }
            Ok(None) => {}
            Err(error) => return error_response("runtime_unavailable", &error.to_string()),
        }
    }
}

fn error_response(code: &'static str, message: &str) -> ControlResponse {
    ControlResponse {
        status: "error",
        data: None,
        error: Some(ControlError {
            code,
            message: message.to_owned(),
        }),
    }
}

fn constant_time_equal(left: &str, right: &str) -> bool {
    if left.len() != right.len() {
        return false;
    }
    left.as_bytes()
        .iter()
        .zip(right.as_bytes())
        .fold(0_u8, |difference, (a, b)| difference | (a ^ b))
        == 0
}

#[cfg(test)]
mod tests {
    use super::constant_time_equal;

    #[test]
    fn constant_time_comparison_requires_exact_value() {
        assert!(constant_time_equal("abc", "abc"));
        assert!(!constant_time_equal("abc", "abd"));
        assert!(!constant_time_equal("abc", "ab"));
    }
}
