use crate::managed_process::ManagedChild;
use rand::distr::{Alphanumeric, SampleString};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::ffi::OsString;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};
use sysinfo::{Pid, System};
use thiserror::Error;
use uuid::Uuid;

const START_TIMEOUT: Duration = Duration::from_secs(60);
const HEALTH_INTERVAL: Duration = Duration::from_millis(150);
const MAX_WORKER_INPUT_BYTES: usize = 8 * 1024 * 1024;
const MAX_WORKER_OUTPUT_BYTES: usize = 1024 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum QState {
    Off,
    Starting,
    Active,
    Sleeping,
    Sleep,
    Stopping,
    Error,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LifecycleAction {
    Start,
    MarkActive,
    Sleep,
    MarkSleeping,
    Stop,
    MarkOff,
    Fail,
}

#[derive(Debug, Clone, Serialize)]
pub struct LifecycleSnapshot {
    pub state: QState,
    pub model_profile_id: Option<String>,
    pub last_error: Option<String>,
}

#[derive(Debug, Error)]
pub enum SupervisorError {
    #[error("Invalid Q state transition from {from:?} using {action:?}.")]
    InvalidTransition {
        from: QState,
        action: LifecycleAction,
    },
    #[error("Model profile is invalid: {0}")]
    InvalidProfile(String),
    #[error("Model file is unavailable: {0}")]
    ModelUnavailable(String),
    #[error("Runtime process is unavailable: {0}")]
    RuntimeUnavailable(String),
    #[error("Runtime did not become healthy before timeout.")]
    StartTimeout,
    #[error("Worker request is invalid: {0}")]
    InvalidWorker(String),
    #[error("Worker process is unavailable: {0}")]
    WorkerUnavailable(String),
}

#[derive(Debug, Clone)]
pub struct Lifecycle {
    state: QState,
    model_profile_id: Option<String>,
    last_error: Option<String>,
}

impl Default for Lifecycle {
    fn default() -> Self {
        Self {
            state: QState::Off,
            model_profile_id: None,
            last_error: None,
        }
    }
}

impl Lifecycle {
    pub fn state(&self) -> QState {
        self.state
    }

    pub fn transition(&mut self, action: LifecycleAction) -> Result<QState, SupervisorError> {
        let next = match (self.state, action) {
            (QState::Off | QState::Sleep, LifecycleAction::Start) => QState::Starting,
            (QState::Starting, LifecycleAction::MarkActive) => QState::Active,
            (QState::Active, LifecycleAction::Sleep) => QState::Sleeping,
            (QState::Sleeping, LifecycleAction::MarkSleeping) => QState::Sleep,
            (
                QState::Active | QState::Sleep | QState::Starting | QState::Error,
                LifecycleAction::Stop,
            ) => QState::Stopping,
            (QState::Stopping, LifecycleAction::MarkOff) => QState::Off,
            (_, LifecycleAction::Fail) => QState::Error,
            _ => {
                return Err(SupervisorError::InvalidTransition {
                    from: self.state,
                    action,
                });
            }
        };
        self.state = next;
        if next == QState::Off {
            self.model_profile_id = None;
            self.last_error = None;
        }
        Ok(next)
    }

    pub fn set_profile(&mut self, profile_id: String) {
        self.model_profile_id = Some(profile_id);
    }

    pub fn set_error(&mut self, message: String) {
        self.last_error = Some(message);
        let _ = self.transition(LifecycleAction::Fail);
    }

    pub fn snapshot(&self) -> LifecycleSnapshot {
        LifecycleSnapshot {
            state: self.state,
            model_profile_id: self.model_profile_id.clone(),
            last_error: self.last_error.clone(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct ModelProfileWire {
    pub profile_id: String,
    pub name: String,
    pub model_path: String,
    pub context_length: u32,
    pub threads: u16,
    pub batch_size: u16,
    pub gpu_layers: u16,
    pub temperature: f32,
}

impl ModelProfileWire {
    fn validate(&self) -> Result<(), SupervisorError> {
        if self.profile_id.trim().is_empty() || self.name.trim().is_empty() {
            return Err(SupervisorError::InvalidProfile(
                "profile_id and name are required".to_owned(),
            ));
        }
        if !(1_024..=1_048_576).contains(&self.context_length) {
            return Err(SupervisorError::InvalidProfile(
                "context_length is outside the supported range".to_owned(),
            ));
        }
        if self.threads == 0 || self.threads > 512 || self.batch_size == 0 {
            return Err(SupervisorError::InvalidProfile(
                "threads and batch_size must be positive and bounded".to_owned(),
            ));
        }
        if !(0.0..=2.0).contains(&self.temperature) {
            return Err(SupervisorError::InvalidProfile(
                "temperature must be between 0 and 2".to_owned(),
            ));
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct RuntimeConnection {
    pub host: String,
    pub port: u16,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub api_key: Option<String>,
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct ResourceSnapshot {
    pub q_owned_ram_bytes: u64,
    pub q_owned_cpu_percent: f32,
    pub backend_ram_bytes: u64,
    pub model_ram_bytes: u64,
    pub worker_ram_bytes: u64,
    pub disk_cache_bytes: u64,
}

#[derive(Debug, Clone, Copy, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WorkerKind {
    Python,
    Sql,
    Package,
    R,
    Audio,
}

#[derive(Debug, Clone)]
pub struct WorkerCommand {
    pub program: PathBuf,
    pub fixed_args: Vec<OsString>,
}

#[derive(Debug, Clone, Serialize)]
pub struct WorkerResult {
    pub exit_code: Option<i32>,
    pub stdout: String,
    pub stderr: String,
    pub timed_out: bool,
}

struct WorkerEntry {
    child: ManagedChild,
    stdout: JoinHandle<std::io::Result<(Vec<u8>, bool)>>,
    stderr: JoinHandle<std::io::Result<(Vec<u8>, bool)>>,
    started: Instant,
    timeout: Duration,
}

pub struct Supervisor {
    lifecycle: Lifecycle,
    backend_pid: Option<u32>,
    model: Option<ManagedChild>,
    workers: HashMap<Uuid, WorkerEntry>,
    runtime_connection: Option<RuntimeConnection>,
    cache_root: PathBuf,
    workspace_root: PathBuf,
}

impl Supervisor {
    pub fn new(cache_root: PathBuf, workspace_root: PathBuf) -> Self {
        Self {
            lifecycle: Lifecycle::default(),
            backend_pid: None,
            model: None,
            workers: HashMap::new(),
            runtime_connection: None,
            cache_root,
            workspace_root,
        }
    }

    pub fn set_backend_pid(&mut self, pid: u32) {
        self.backend_pid = Some(pid);
    }

    pub fn snapshot(&self) -> LifecycleSnapshot {
        self.lifecycle.snapshot()
    }

    pub fn runtime_connection(&self) -> Option<RuntimeConnection> {
        self.runtime_connection.clone()
    }

    pub fn start_model(
        &mut self,
        profile: &ModelProfileWire,
        runtime_executable: &Path,
    ) -> Result<LifecycleSnapshot, SupervisorError> {
        profile.validate()?;
        self.lifecycle.transition(LifecycleAction::Start)?;
        self.lifecycle.set_profile(profile.profile_id.clone());

        let result = self.spawn_and_wait_for_model(profile, runtime_executable);
        match result {
            Ok(()) => {
                self.lifecycle.transition(LifecycleAction::MarkActive)?;
                Ok(self.lifecycle.snapshot())
            }
            Err(error) => {
                self.terminate_model();
                self.runtime_connection = None;
                self.lifecycle.set_error(error.to_string());
                Err(error)
            }
        }
    }

    fn spawn_and_wait_for_model(
        &mut self,
        profile: &ModelProfileWire,
        runtime_executable: &Path,
    ) -> Result<(), SupervisorError> {
        let runtime_path = runtime_executable.canonicalize().map_err(|error| {
            SupervisorError::RuntimeUnavailable(format!(
                "{} ({error})",
                runtime_executable.display()
            ))
        })?;
        let model_path = PathBuf::from(&profile.model_path)
            .canonicalize()
            .map_err(|error| {
                SupervisorError::ModelUnavailable(format!("{} ({error})", profile.model_path))
            })?;
        if !model_path.is_file()
            || model_path
                .extension()
                .and_then(|value| value.to_str())
                .is_none_or(|value| !value.eq_ignore_ascii_case("gguf"))
        {
            return Err(SupervisorError::ModelUnavailable(
                "The selected model must be an existing .gguf file.".to_owned(),
            ));
        }

        let port = allocate_loopback_port()?;
        let api_key = Alphanumeric.sample_string(&mut rand::rng(), 64);
        let args: Vec<OsString> = vec![
            "--model".into(),
            model_path.into_os_string(),
            "--host".into(),
            "127.0.0.1".into(),
            "--port".into(),
            port.to_string().into(),
            "--ctx-size".into(),
            profile.context_length.to_string().into(),
            "--threads".into(),
            profile.threads.to_string().into(),
            "--batch-size".into(),
            profile.batch_size.to_string().into(),
            "--n-gpu-layers".into(),
            profile.gpu_layers.to_string().into(),
            "--api-key".into(),
            api_key.clone().into(),
        ];
        let mut command = Command::new(runtime_path);
        command
            .args(args)
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null());
        let child = ManagedChild::spawn(command)
            .map_err(|error| SupervisorError::RuntimeUnavailable(error.to_string()))?;
        self.model = Some(child);
        self.runtime_connection = Some(RuntimeConnection {
            host: "127.0.0.1".to_owned(),
            port,
            api_key: Some(api_key),
        });

        let started = Instant::now();
        while started.elapsed() < START_TIMEOUT {
            if let Some(model) = self.model.as_mut() {
                if let Some(status) = model
                    .try_wait()
                    .map_err(|error| SupervisorError::RuntimeUnavailable(error.to_string()))?
                {
                    return Err(SupervisorError::RuntimeUnavailable(format!(
                        "llama.cpp exited with {status}"
                    )));
                }
            }
            if TcpStream::connect_timeout(
                &std::net::SocketAddr::from(([127, 0, 0, 1], port)),
                Duration::from_millis(100),
            )
            .is_ok()
            {
                return Ok(());
            }
            thread::sleep(HEALTH_INTERVAL);
        }
        Err(SupervisorError::StartTimeout)
    }

    pub fn sleep_model(&mut self) -> Result<LifecycleSnapshot, SupervisorError> {
        self.lifecycle.transition(LifecycleAction::Sleep)?;
        self.terminate_model();
        self.runtime_connection = None;
        self.lifecycle.transition(LifecycleAction::MarkSleeping)?;
        Ok(self.lifecycle.snapshot())
    }

    pub fn stop_q(&mut self) -> Result<LifecycleSnapshot, SupervisorError> {
        if self.lifecycle.state() == QState::Off {
            return Ok(self.lifecycle.snapshot());
        }
        self.lifecycle.transition(LifecycleAction::Stop)?;
        self.terminate_model();
        self.terminate_workers();
        self.runtime_connection = None;
        self.lifecycle.transition(LifecycleAction::MarkOff)?;
        Ok(self.lifecycle.snapshot())
    }

    fn terminate_model(&mut self) {
        if let Some(mut child) = self.model.take() {
            let _ = child.terminate_and_wait();
        }
    }

    fn terminate_workers(&mut self) {
        for (_, mut worker) in self.workers.drain() {
            let _ = worker.child.terminate_and_wait();
            let _ = worker.stdout.join();
            let _ = worker.stderr.join();
        }
    }

    pub fn start_worker(
        &mut self,
        command: &WorkerCommand,
        payload: &str,
        working_directory: &Path,
        timeout_seconds: u64,
    ) -> Result<Uuid, SupervisorError> {
        if payload.len() > MAX_WORKER_INPUT_BYTES {
            return Err(SupervisorError::InvalidWorker(
                "payload exceeds the worker input limit".to_owned(),
            ));
        }
        if !(1..=120).contains(&timeout_seconds) {
            return Err(SupervisorError::InvalidWorker(
                "timeout must be between 1 and 120 seconds".to_owned(),
            ));
        }
        let workspace = self.workspace_root.canonicalize().map_err(|error| {
            SupervisorError::WorkerUnavailable(format!("workspace is unavailable ({error})"))
        })?;
        let working_directory = working_directory.canonicalize().map_err(|error| {
            SupervisorError::WorkerUnavailable(format!(
                "working directory is unavailable ({error})"
            ))
        })?;
        if !working_directory.is_dir() || !working_directory.starts_with(&workspace) {
            return Err(SupervisorError::InvalidWorker(
                "working directory is outside the Experimental Q workspace".to_owned(),
            ));
        }
        let mut process = Command::new(&command.program);
        process
            .args(&command.fixed_args)
            .current_dir(working_directory)
            .env_clear()
            .env("PYTHONIOENCODING", "utf-8")
            .env("PYTHONUTF8", "1")
            .env("Q_WORKER_MEMORY_BYTES", (512_u64 * 1024 * 1024).to_string())
            .env("Q_WORKER_CPU_SECONDS", timeout_seconds.to_string())
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        copy_required_environment(&mut process);
        let mut child = ManagedChild::spawn(process)
            .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))?;
        let mut stdin = child.take_stdin().ok_or_else(|| {
            SupervisorError::WorkerUnavailable("worker stdin is unavailable".to_owned())
        })?;
        stdin
            .write_all(payload.as_bytes())
            .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))?;
        drop(stdin);
        let stdout = child.take_stdout().ok_or_else(|| {
            SupervisorError::WorkerUnavailable("worker stdout is unavailable".to_owned())
        })?;
        let stderr = child.take_stderr().ok_or_else(|| {
            SupervisorError::WorkerUnavailable("worker stderr is unavailable".to_owned())
        })?;
        let worker_id = Uuid::new_v4();
        self.workers.insert(
            worker_id,
            WorkerEntry {
                child,
                stdout: collect_output(stdout),
                stderr: collect_output(stderr),
                started: Instant::now(),
                timeout: Duration::from_secs(timeout_seconds),
            },
        );
        Ok(worker_id)
    }

    pub fn poll_worker(
        &mut self,
        worker_id: Uuid,
    ) -> Result<Option<WorkerResult>, SupervisorError> {
        let timed_out = self
            .workers
            .get(&worker_id)
            .is_some_and(|worker| worker.started.elapsed() >= worker.timeout);
        if timed_out {
            if let Some(worker) = self.workers.get_mut(&worker_id) {
                let _ = worker.child.terminate_and_wait();
            }
            let worker = self.workers.remove(&worker_id).ok_or_else(|| {
                SupervisorError::WorkerUnavailable("worker disappeared".to_owned())
            })?;
            return finish_worker(worker, None, true).map(Some);
        }
        let status = self
            .workers
            .get_mut(&worker_id)
            .ok_or_else(|| SupervisorError::WorkerUnavailable("worker not found".to_owned()))?
            .child
            .try_wait()
            .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))?;
        let Some(status) = status else {
            return Ok(None);
        };
        let worker = self
            .workers
            .remove(&worker_id)
            .ok_or_else(|| SupervisorError::WorkerUnavailable("worker disappeared".to_owned()))?;
        finish_worker(worker, status.code(), false).map(Some)
    }

    pub fn resources(&self) -> ResourceSnapshot {
        let mut system = System::new_all();
        system.refresh_all();
        let backend_ram = self
            .backend_pid
            .and_then(|pid| system.process(Pid::from_u32(pid)))
            .map_or(0, |process| process.memory());
        let (model_ram, model_cpu) = self
            .model
            .as_ref()
            .and_then(|child| system.process(Pid::from_u32(child.id())))
            .map_or((0, 0.0), |process| (process.memory(), process.cpu_usage()));
        let (worker_ram, worker_cpu) = self.workers.values().fold((0, 0.0), |total, worker| {
            system
                .process(Pid::from_u32(worker.child.id()))
                .map_or(total, |process| {
                    (total.0 + process.memory(), total.1 + process.cpu_usage())
                })
        });
        ResourceSnapshot {
            q_owned_ram_bytes: backend_ram + model_ram + worker_ram,
            q_owned_cpu_percent: model_cpu + worker_cpu,
            backend_ram_bytes: backend_ram,
            model_ram_bytes: model_ram,
            worker_ram_bytes: worker_ram,
            disk_cache_bytes: directory_size(&self.cache_root),
        }
    }
}

fn collect_output<R>(mut reader: R) -> JoinHandle<std::io::Result<(Vec<u8>, bool)>>
where
    R: Read + Send + 'static,
{
    thread::spawn(move || {
        let mut stored = Vec::new();
        let mut buffer = [0_u8; 16 * 1024];
        let mut exceeded = false;
        loop {
            let read = reader.read(&mut buffer)?;
            if read == 0 {
                break;
            }
            let remaining = MAX_WORKER_OUTPUT_BYTES.saturating_sub(stored.len());
            let copy = remaining.min(read);
            stored.extend_from_slice(&buffer[..copy]);
            exceeded |= copy < read;
        }
        Ok((stored, exceeded))
    })
}

fn finish_worker(
    mut worker: WorkerEntry,
    exit_code: Option<i32>,
    timed_out: bool,
) -> Result<WorkerResult, SupervisorError> {
    worker
        .child
        .wait()
        .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))?;
    let (stdout, stdout_exceeded) = worker
        .stdout
        .join()
        .map_err(|_| SupervisorError::WorkerUnavailable("stdout collector failed".to_owned()))?
        .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))?;
    let (stderr, stderr_exceeded) = worker
        .stderr
        .join()
        .map_err(|_| SupervisorError::WorkerUnavailable("stderr collector failed".to_owned()))?
        .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))?;
    if stdout_exceeded || stderr_exceeded {
        return Err(SupervisorError::WorkerUnavailable(
            "worker output exceeded its limit".to_owned(),
        ));
    }
    Ok(WorkerResult {
        exit_code,
        stdout: String::from_utf8_lossy(&stdout).into_owned(),
        stderr: String::from_utf8_lossy(&stderr).into_owned(),
        timed_out,
    })
}

fn copy_required_environment(command: &mut Command) {
    for key in [
        "PATH",
        "PATHEXT",
        "SYSTEMROOT",
        "WINDIR",
        "TEMP",
        "TMP",
        "USERPROFILE",
    ] {
        if let Some(value) = std::env::var_os(key) {
            command.env(key, value);
        }
    }
}

pub fn store_credential(reference: &str, secret: &str) -> Result<(), SupervisorError> {
    validate_credential_reference(reference)?;
    if secret.is_empty() || secret.len() > 65_536 {
        return Err(SupervisorError::InvalidWorker(
            "credential secret length is invalid".to_owned(),
        ));
    }
    platform_store_credential(reference, secret)
}

pub fn resolve_credential(reference: &str) -> Result<String, SupervisorError> {
    validate_credential_reference(reference)?;
    platform_resolve_credential(reference)
}

pub fn delete_credential(reference: &str) -> Result<(), SupervisorError> {
    validate_credential_reference(reference)?;
    platform_delete_credential(reference)
}

fn validate_credential_reference(reference: &str) -> Result<(), SupervisorError> {
    if reference.is_empty()
        || reference.len() > 200
        || !reference
            .bytes()
            .all(|value| value.is_ascii_alphanumeric() || matches!(value, b'-' | b'_'))
    {
        return Err(SupervisorError::InvalidWorker(
            "credential reference is invalid".to_owned(),
        ));
    }
    Ok(())
}

#[cfg(target_os = "windows")]
fn credential_entry(reference: &str) -> Result<keyring::Entry, SupervisorError> {
    keyring::Entry::new("ExperimentalQ", reference)
        .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))
}

#[cfg(target_os = "windows")]
fn platform_store_credential(reference: &str, secret: &str) -> Result<(), SupervisorError> {
    credential_entry(reference)?
        .set_password(secret)
        .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))
}

#[cfg(target_os = "windows")]
fn platform_resolve_credential(reference: &str) -> Result<String, SupervisorError> {
    credential_entry(reference)?
        .get_password()
        .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))
}

#[cfg(target_os = "windows")]
fn platform_delete_credential(reference: &str) -> Result<(), SupervisorError> {
    credential_entry(reference)?
        .delete_credential()
        .map_err(|error| SupervisorError::WorkerUnavailable(error.to_string()))
}

#[cfg(not(target_os = "windows"))]
fn platform_store_credential(_reference: &str, _secret: &str) -> Result<(), SupervisorError> {
    Err(SupervisorError::WorkerUnavailable(
        "Windows Credential Manager is unavailable on this platform".to_owned(),
    ))
}

#[cfg(not(target_os = "windows"))]
fn platform_resolve_credential(_reference: &str) -> Result<String, SupervisorError> {
    Err(SupervisorError::WorkerUnavailable(
        "Windows Credential Manager is unavailable on this platform".to_owned(),
    ))
}

#[cfg(not(target_os = "windows"))]
fn platform_delete_credential(_reference: &str) -> Result<(), SupervisorError> {
    Err(SupervisorError::WorkerUnavailable(
        "Windows Credential Manager is unavailable on this platform".to_owned(),
    ))
}

impl Drop for Supervisor {
    fn drop(&mut self) {
        self.terminate_model();
        self.terminate_workers();
    }
}

fn allocate_loopback_port() -> Result<u16, SupervisorError> {
    TcpListener::bind(("127.0.0.1", 0))
        .and_then(|listener| listener.local_addr())
        .map(|address| address.port())
        .map_err(|error| SupervisorError::RuntimeUnavailable(error.to_string()))
}

fn directory_size(root: &Path) -> u64 {
    let Ok(entries) = std::fs::read_dir(root) else {
        return 0;
    };
    entries
        .flatten()
        .map(|entry| {
            entry.metadata().map_or(0, |metadata| {
                if metadata.is_dir() {
                    directory_size(&entry.path())
                } else {
                    metadata.len()
                }
            })
        })
        .sum()
}

#[cfg(test)]
mod tests {
    use super::{Lifecycle, LifecycleAction, QState};

    #[test]
    fn lifecycle_supports_active_sleep_active_off() {
        let mut lifecycle = Lifecycle::default();
        assert_eq!(
            lifecycle.transition(LifecycleAction::Start).ok(),
            Some(QState::Starting)
        );
        assert_eq!(
            lifecycle.transition(LifecycleAction::MarkActive).ok(),
            Some(QState::Active)
        );
        assert_eq!(
            lifecycle.transition(LifecycleAction::Sleep).ok(),
            Some(QState::Sleeping)
        );
        assert_eq!(
            lifecycle.transition(LifecycleAction::MarkSleeping).ok(),
            Some(QState::Sleep)
        );
        assert_eq!(
            lifecycle.transition(LifecycleAction::Start).ok(),
            Some(QState::Starting)
        );
        assert_eq!(
            lifecycle.transition(LifecycleAction::MarkActive).ok(),
            Some(QState::Active)
        );
        assert_eq!(
            lifecycle.transition(LifecycleAction::Stop).ok(),
            Some(QState::Stopping)
        );
        assert_eq!(
            lifecycle.transition(LifecycleAction::MarkOff).ok(),
            Some(QState::Off)
        );
    }

    #[test]
    fn lifecycle_forbids_error_to_active() {
        let mut lifecycle = Lifecycle::default();
        assert_eq!(
            lifecycle.transition(LifecycleAction::Fail).ok(),
            Some(QState::Error)
        );
        assert!(lifecycle.transition(LifecycleAction::MarkActive).is_err());
        assert_eq!(
            lifecycle.transition(LifecycleAction::Stop).ok(),
            Some(QState::Stopping)
        );
        assert_eq!(
            lifecycle.transition(LifecycleAction::MarkOff).ok(),
            Some(QState::Off)
        );
    }
}
