use serde::{Deserialize, Serialize};
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ApplicationConfig {
    pub first_run_complete: bool,
    pub workspace: PathBuf,
    pub mode: String,
    pub llama_runtime: Option<PathBuf>,
    pub model_path: Option<PathBuf>,
    pub whisper_runtime: Option<PathBuf>,
    pub whisper_model: Option<PathBuf>,
}

impl ApplicationConfig {
    pub fn defaults(workspace: PathBuf) -> Self {
        Self {
            first_run_complete: false,
            workspace,
            mode: "local_only".to_owned(),
            llama_runtime: None,
            model_path: None,
            whisper_runtime: None,
            whisper_model: None,
        }
    }

    pub fn load(path: &Path, defaults: Self) -> Result<Self, String> {
        if !path.exists() {
            return Ok(defaults);
        }
        let value = fs::read_to_string(path)
            .map_err(|error| format!("Could not read application configuration: {error}"))?;
        let config: Self = serde_json::from_str(&value)
            .map_err(|error| format!("Application configuration is invalid: {error}"))?;
        config.validate()?;
        Ok(config)
    }

    pub fn save(&self, path: &Path) -> Result<(), String> {
        self.validate()?;
        let parent = path
            .parent()
            .ok_or_else(|| "Application configuration path has no parent.".to_owned())?;
        fs::create_dir_all(parent)
            .map_err(|error| format!("Could not create configuration directory: {error}"))?;
        let staging = path.with_extension("json.staging");
        let encoded = serde_json::to_vec_pretty(self)
            .map_err(|error| format!("Could not serialize application configuration: {error}"))?;
        fs::write(&staging, encoded)
            .map_err(|error| format!("Could not stage application configuration: {error}"))?;
        if path.exists() {
            fs::remove_file(path)
                .map_err(|error| format!("Could not replace application configuration: {error}"))?;
        }
        fs::rename(staging, path)
            .map_err(|error| format!("Could not commit application configuration: {error}"))
    }

    pub fn apply_packaged_defaults(&mut self, runtime_root: &Path) -> Result<(), String> {
        set_packaged_file(
            &mut self.llama_runtime,
            runtime_root.join("bin/llama_cpp/llama-server.exe"),
        );
        set_packaged_file(
            &mut self.model_path,
            runtime_root.join("models/experimental-q.gguf"),
        );
        set_packaged_file(
            &mut self.whisper_runtime,
            runtime_root.join("bin/whisper_cpp/whisper-cli.exe"),
        );
        set_packaged_file(
            &mut self.whisper_model,
            runtime_root.join("models/ggml-base.bin"),
        );
        self.validate()
    }

    fn validate(&self) -> Result<(), String> {
        validate_workspace(&self.workspace)?;
        if !matches!(self.mode.as_str(), "local_only" | "hybrid" | "connected") {
            return Err("Application mode is invalid.".to_owned());
        }
        validate_optional_file(&self.llama_runtime, &["exe"], "llama.cpp runtime")?;
        validate_optional_file(&self.model_path, &["gguf"], "GGUF model")?;
        validate_optional_file(&self.whisper_runtime, &["exe"], "whisper.cpp runtime")?;
        validate_optional_file(&self.whisper_model, &["bin", "gguf"], "whisper model")?;
        Ok(())
    }
}

fn set_packaged_file(current: &mut Option<PathBuf>, candidate: PathBuf) {
    if current.is_none() && candidate.is_file() {
        *current = Some(candidate);
    }
}

impl Default for ApplicationConfig {
    fn default() -> Self {
        Self::defaults(PathBuf::from("ExperimentalQ"))
    }
}

fn validate_workspace(path: &Path) -> Result<(), String> {
    if !path.is_absolute() || path.parent().is_none() {
        return Err("Workspace must be an absolute non-root path.".to_owned());
    }
    let normalized = path.to_string_lossy().replace('/', "\\").to_lowercase();
    if normalized == "c:\\"
        || normalized.starts_with("c:\\windows")
        || normalized.starts_with("c:\\program files")
        || normalized.starts_with("\\\\")
    {
        return Err("Workspace cannot use a protected, device, or UNC root.".to_owned());
    }
    Ok(())
}

fn validate_optional_file(
    value: &Option<PathBuf>,
    extensions: &[&str],
    label: &str,
) -> Result<(), String> {
    let Some(path) = value else {
        return Ok(());
    };
    if !path.is_absolute() || !path.is_file() {
        return Err(format!("Configured {label} does not exist."));
    }
    let extension = path
        .extension()
        .and_then(|item| item.to_str())
        .unwrap_or("");
    if !extensions
        .iter()
        .any(|allowed| extension.eq_ignore_ascii_case(allowed))
    {
        return Err(format!("Configured {label} has an invalid extension."));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::ApplicationConfig;
    use std::fs;
    use uuid::Uuid;

    #[test]
    fn packaged_defaults_use_existing_files() -> Result<(), Box<dyn std::error::Error>> {
        let root = std::env::temp_dir().join(format!("experimental-q-config-{}", Uuid::new_v4()));
        let workspace = root.join("workspace");
        let runtime = root.join("runtime");
        let llama = runtime.join("bin/llama_cpp/llama-server.exe");
        let model = runtime.join("models/experimental-q.gguf");
        fs::create_dir_all(runtime.join("bin/llama_cpp"))?;
        fs::create_dir_all(runtime.join("models"))?;
        fs::write(&llama, b"test")?;
        fs::write(&model, b"test")?;

        let mut config = ApplicationConfig::defaults(workspace);
        config
            .apply_packaged_defaults(&runtime)
            .map_err(std::io::Error::other)?;

        assert_eq!(config.llama_runtime.as_deref(), Some(llama.as_path()));
        assert_eq!(config.model_path.as_deref(), Some(model.as_path()));
        assert!(config.whisper_runtime.is_none());
        assert!(config.whisper_model.is_none());
        fs::remove_dir_all(root)?;
        Ok(())
    }
}
