This directory is populated by scripts/build_windows.ps1.

Release builds must contain only hash-verified runtime binaries, the packaged
backend/workers, configuration contracts, and the optional local whisper model.
No Q language model, credential, user memory, or user dataset belongs here.
