fn main() {
    // Cross-target lint hosts may not have a Windows resource compiler. CI and
    // release builds never set this variable and therefore run the full Tauri
    // build pipeline.
    if std::env::var_os("Q_SKIP_TAURI_BUILD").is_none() {
        tauri_build::build();
    }
}
