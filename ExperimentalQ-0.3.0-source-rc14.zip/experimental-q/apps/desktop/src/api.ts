import { invoke } from "@tauri-apps/api/core";

export type QState = "OFF" | "STARTING" | "ACTIVE" | "SLEEPING" | "SLEEP" | "STOPPING" | "ERROR";
export type AppMode = "local_only" | "hybrid" | "connected";

export interface BackendConnection { port: number; token: string }
export interface HealthResponse {
  status: "ok";
  service: "experimental-q-backend";
  api_version: "v1";
  q_state: QState;
  timestamp_utc: string;
}
export interface ResourceSnapshot {
  q_owned_ram_bytes: number;
  q_owned_cpu_percent: number;
  backend_ram_bytes: number;
  model_ram_bytes: number;
  worker_ram_bytes: number;
  disk_cache_bytes: number;
}
export interface SystemState {
  lifecycle: { state: QState; model_profile_id: string | null; last_error: string | null };
  resources: ResourceSnapshot;
  mode: AppMode;
  network_enabled: boolean;
}
export interface Project {
  project_id: string;
  name: string;
  description: string;
  root_path: string;
  created_at_utc: string;
  updated_at_utc: string;
}
export interface ModelProfile {
  profile_id: string;
  name: string;
  runtime: "llama_cpp";
  model_path: string;
  context_length: number;
  threads: number;
  batch_size: number;
  gpu_layers: number;
  temperature: number;
  tool_calling: boolean;
  vision: boolean;
}
export interface ChatSession { session_id: string; project_id: string | null; title: string }
export interface ChatAction {
  tool: string;
  reason: string;
  status: string;
  audit_id: string | null;
  provenance_id: string | null;
}
export interface PermissionChallenge {
  challenge_id: string;
  confirmation_secret: string;
  request_id: string;
  tool: string;
  action: string;
  resource: string | null;
  reason: string;
  destructive: boolean;
  allowed_scopes: string[];
  expires_at_utc: string;
}
export interface ToolResult {
  request_id: string;
  status: "ok" | "error" | "confirmation_required";
  data: unknown;
  error?: { code: string; message: string; details: Record<string, unknown>; correlation_id: string };
  audit_id: string | null;
  provenance_id: string | null;
}
export interface ChatTurnResponse {
  turn_id: string;
  session_id: string;
  status: "completed" | "confirmation_required";
  answer: string | null;
  actions: ChatAction[];
  pending_tool_result: ToolResult | null;
}
export interface Artifact {
  artifact_id: string;
  project_id: string | null;
  path: string;
  filename: string;
  artifact_type: string;
  source_operation: string;
  created_at_utc: string;
  provenance_id: string;
}
export interface FirstRunStatus {
  completed: boolean;
  workspace: string;
  mode: AppMode;
  llama_runtime: string | null;
  model_path: string | null;
  whisper_runtime: string | null;
  whisper_model: string | null;
}
export interface HardwareSnapshot {
  total_memory_bytes: number;
  available_memory_bytes: number;
  logical_cpus: number;
  recommended_threads: number;
  recommended_context_length: number;
}
export interface FileEntry {
  name: string;
  relative_path: string;
  kind: "file" | "directory";
  size_bytes: number | null;
  modified_at_utc: string;
}
export type NotebookCellType = "prompt" | "code" | "markdown" | "sql" | "r";
export interface NotebookCell {
  cell_id: string;
  position: number;
  cell_type: NotebookCellType;
  content: string;
  output: Record<string, unknown> | null;
  created_at_utc: string;
  updated_at_utc: string;
}
export interface Notebook {
  notebook_id: string;
  project_id: string;
  title: string;
  cells: NotebookCell[];
  created_at_utc: string;
  updated_at_utc: string;
}
export interface MemorySearchItem {
  record: {
    memory_id: string;
    scope: "user" | "project" | "knowledge";
    project_id: string | null;
    content: string;
    source: string;
    sensitivity: boolean;
  };
  score: number;
}

export class ApiError extends Error {
  readonly code: string;
  constructor(code: string, message: string) { super(message); this.code = code; }
}

export async function getBackendConnection(): Promise<BackendConnection> {
  return invoke<BackendConnection>("get_backend_connection");
}

async function api<T>(connection: BackendConnection, path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  headers.set("Authorization", `Bearer ${connection.token}`);
  if (init?.body && !(init.body instanceof Blob) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const response = await fetch(`http://127.0.0.1:${connection.port}/api/v1${path}`, { ...init, headers });
  if (response.status === 204) return undefined as T;
  const body: unknown = await response.json();
  if (response.status === 409 && (body as { status?: string }).status === "confirmation_required") {
    return body as T;
  }
  if (!response.ok) {
    const envelope = body as { error?: { code?: string; message?: string } };
    throw new ApiError(envelope.error?.code ?? "internal_error", envelope.error?.message ?? `HTTP ${response.status}`);
  }
  return body as T;
}

export const fetchHealth = (c: BackendConnection) => api<HealthResponse>(c, "/health");
export const fetchSystemState = (c: BackendConnection) => api<SystemState>(c, "/system/state");
export const listProjects = (c: BackendConnection) => api<Project[]>(c, "/projects");
export const createProject = (c: BackendConnection, name: string, description = "") =>
  api<Project>(c, "/projects", { method: "POST", body: JSON.stringify({ name, description }) });
export const authorizeRoot = (c: BackendConnection, projectId: string, path: string) =>
  api(c, `/projects/${projectId}/authorized-roots`, {
    method: "POST", body: JSON.stringify({ path, explicit_user_confirmation: true }),
  });
export const listProfiles = (c: BackendConnection) => api<ModelProfile[]>(c, "/models/profiles");
export const putProfile = (c: BackendConnection, profile: ModelProfile) =>
  api<ModelProfile>(c, "/models/profiles", { method: "POST", body: JSON.stringify(profile) });
export const startModel = (c: BackendConnection, profileId: string) =>
  api(c, "/model/start", { method: "POST", body: JSON.stringify({ profile_id: profileId }) });
export const sleepModel = (c: BackendConnection) => api(c, "/model/sleep", { method: "POST" });
export const stopModel = (c: BackendConnection) => api(c, "/model/stop", { method: "POST" });
export const createChatSession = (c: BackendConnection, projectId: string | null) =>
  api<ChatSession>(c, "/chat/sessions", {
    method: "POST", body: JSON.stringify({ project_id: projectId, title: "Conversación con Q" }),
  });
export const sendChatTurn = (c: BackendConnection, sessionId: string, projectId: string | null, message: string) =>
  api<ChatTurnResponse>(c, "/chat/turn", {
    method: "POST", body: JSON.stringify({ session_id: sessionId, project_id: projectId, message }),
  });
export const confirmChatPermission = (
  c: BackendConnection,
  challenge: PermissionChallenge,
  allow: boolean,
  grantScope?: string,
) => api<ChatTurnResponse>(c, "/chat/permissions/confirm", {
  method: "POST",
  body: JSON.stringify({
    challenge_id: challenge.challenge_id,
    confirmation_secret: challenge.confirmation_secret,
    allow,
    grant_scope: grantScope ?? null,
    grant_resource: null,
  }),
});
export const listArtifacts = (c: BackendConnection, projectId: string | null) =>
  api<Artifact[]>(c, `/artifacts${projectId ? `?project_id=${encodeURIComponent(projectId)}` : ""}`);
export const invokeTool = (
  c: BackendConnection,
  projectId: string | null,
  tool: string,
  args: Record<string, unknown>,
  reason: string,
) => api<ToolResult>(c, "/tools/invoke", {
  method: "POST",
  body: JSON.stringify({
    request_id: crypto.randomUUID(), tool, arguments: args, reason, project_id: projectId,
  }),
});
export const confirmToolPermission = (
  c: BackendConnection,
  challenge: PermissionChallenge,
  allow: boolean,
  grantScope?: string,
) => api<ToolResult | { cancelled: boolean }>(c, "/permissions/confirm", {
  method: "POST",
  body: JSON.stringify({
    challenge_id: challenge.challenge_id,
    confirmation_secret: challenge.confirmation_secret,
    allow,
    grant_scope: grantScope ?? null,
    grant_resource: null,
  }),
});
export const listFiles = async (c: BackendConnection, projectId: string): Promise<FileEntry[]> => {
  const result = await invokeTool(
    c, projectId, "files.list", { path: ".", recursive: true, max_entries: 1000 },
    "Escanear la raíz autorizada del proyecto",
  );
  if (result.status !== "ok") {
    throw new ApiError(result.error?.code ?? "internal_error", result.error?.message ?? "No se pudo listar.");
  }
  return (result.data as { entries: FileEntry[] }).entries;
};
export const indexKnowledge = (c: BackendConnection, projectId: string, source: string, content: string) =>
  api<{ chunk_count: number }>(c, "/knowledge/index", {
    method: "POST",
    body: JSON.stringify({ project_id: projectId, source, content, explicit_user_confirmation: true }),
  });
export async function transcribeAudio(c: BackendConnection, wav: Blob): Promise<string> {
  const response = await api<{ text: string }>(c, "/audio/transcribe?language=es", {
    method: "POST", body: wav, headers: { "Content-Type": "audio/wav" },
  });
  return response.text;
}

export const listNotebooks = (c: BackendConnection, projectId: string) =>
  api<Notebook[]>(c, `/notebooks?project_id=${encodeURIComponent(projectId)}`);
export const createNotebook = (c: BackendConnection, projectId: string, title: string) =>
  api<Notebook>(c, "/notebooks", {
    method: "POST", body: JSON.stringify({ project_id: projectId, title }),
  });
export const getNotebook = (c: BackendConnection, notebookId: string) =>
  api<Notebook>(c, `/notebooks/${notebookId}`);
export const addNotebookCell = (
  c: BackendConnection,
  notebookId: string,
  cellType: NotebookCellType,
  content: string,
) => api<NotebookCell>(c, `/notebooks/${notebookId}/cells`, {
  method: "POST", body: JSON.stringify({ cell_type: cellType, content }),
});
export const executeNotebookCell = (
  c: BackendConnection,
  cellId: string,
  sessionId: string,
  mode: AppMode,
) => api<{ cell_id: string; status: string; output: Record<string, unknown> }>(
  c,
  `/notebook-cells/${cellId}/execute`,
  { method: "POST", body: JSON.stringify({ session_id: sessionId, mode }) },
);
export const confirmNotebookCellPermission = (
  c: BackendConnection,
  cellId: string,
  challenge: PermissionChallenge,
  allow: boolean,
  grantScope?: string,
) => api<{ cell_id: string; status: string; output: Record<string, unknown> }>(
  c,
  `/notebook-cells/${cellId}/permissions/confirm`,
  {
    method: "POST",
    body: JSON.stringify({
      challenge_id: challenge.challenge_id,
      confirmation_secret: challenge.confirmation_secret,
      allow,
      grant_scope: grantScope ?? null,
      grant_resource: null,
    }),
  },
);

export const getFirstRunStatus = () => invoke<FirstRunStatus>("get_first_run_status");
export const getHardwareSnapshot = () => invoke<HardwareSnapshot>("get_hardware_snapshot");
export const completeFirstRun = (request: Omit<FirstRunStatus, "completed">) =>
  invoke<void>("complete_first_run", { request });
export const storeCredential = (secret: string) => invoke<string>("store_credential", { secret });
export const deleteCredential = (credentialRef: string) => invoke<void>("delete_credential", { credentialRef });
