import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  completeFirstRun,
  confirmChatPermission,
  confirmNotebookCellPermission,
  confirmToolPermission,
  addNotebookCell,
  authorizeRoot,
  createChatSession,
  createNotebook,
  createProject,
  executeNotebookCell,
  fetchSystemState,
  getBackendConnection,
  getFirstRunStatus,
  getHardwareSnapshot,
  getNotebook,
  indexKnowledge,
  invokeTool,
  listArtifacts,
  listFiles,
  listNotebooks,
  listProfiles,
  listProjects,
  putProfile,
  sendChatTurn,
  sleepModel,
  startModel,
  stopModel,
  type AppMode,
  type BackendConnection,
  type FirstRunStatus,
  type HardwareSnapshot,
  type MemorySearchItem,
  type ModelProfile,
  type NotebookCellType,
  type PermissionChallenge,
  type Project,
  type ToolResult,
} from "./api";
import { useLocalMicrophone } from "./microphone";

const navigation = [
  ["chat", "Chat"], ["projects", "Proyectos"], ["files", "Archivos"],
  ["data", "Datos"], ["knowledge", "Conocimiento"], ["notebook", "Notebook"],
  ["models", "Modelos"], ["tools", "Herramientas"], ["memory", "Memoria"],
  ["settings", "Ajustes"],
] as const;
type View = typeof navigation[number][0];
type Message = { id: string; role: "user" | "assistant" | "system"; content: string };

export function App() {
  const queryClient = useQueryClient();
  const [view, setView] = useState<View>("chat");
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [pending, setPending] = useState<PermissionChallenge | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const profileBootstrapStarted = useRef(false);
  const pendingSource = useRef<"chat" | "tool" | "notebook">("chat");
  const pendingNotebookCellId = useRef<string | null>(null);
  const afterToolConfirmation = useRef<((result: ToolResult) => Promise<void>) | null>(null);
  const afterNotebookConfirmation = useRef<(() => Promise<void>) | null>(null);

  const firstRun = useQuery({ queryKey: ["first-run"], queryFn: getFirstRunStatus, retry: false });
  const hardware = useQuery({ queryKey: ["hardware"], queryFn: getHardwareSnapshot, retry: false });
  const connection = useQuery({ queryKey: ["backend-connection"], queryFn: getBackendConnection, retry: 5 });
  const system = useQuery({
    queryKey: ["system", connection.data?.port],
    queryFn: () => fetchSystemState(connection.data!),
    enabled: Boolean(connection.data),
    refetchInterval: 2_000,
  });
  const projects = useQuery({
    queryKey: ["projects", connection.data?.port], queryFn: () => listProjects(connection.data!),
    enabled: Boolean(connection.data),
  });
  const profiles = useQuery({
    queryKey: ["profiles", connection.data?.port], queryFn: () => listProfiles(connection.data!),
    enabled: Boolean(connection.data),
  });
  const artifacts = useQuery({
    queryKey: ["artifacts", activeProjectId],
    queryFn: () => listArtifacts(connection.data!, activeProjectId),
    enabled: Boolean(connection.data),
    refetchInterval: 5_000,
  });
  const files = useQuery({
    queryKey: ["files", activeProjectId],
    queryFn: () => listFiles(connection.data!, activeProjectId!),
    enabled: Boolean(connection.data && activeProjectId && view === "files"),
  });

  useEffect(() => {
    if (!activeProjectId && projects.data?.[0]) setActiveProjectId(projects.data[0].project_id);
  }, [activeProjectId, projects.data]);
  useEffect(() => { setSessionId(null); setMessages([]); }, [activeProjectId]);
  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen((current) => !current);
      } else if (event.key === "Escape") setPaletteOpen(false);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  const appendTranscript = useCallback((text: string) => {
    setDraft((current) => `${current}${current ? " " : ""}${text}`);
  }, []);
  const microphone = useLocalMicrophone(connection.data, appendTranscript);

  const refresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["system"] }),
      queryClient.invalidateQueries({ queryKey: ["profiles"] }),
      queryClient.invalidateQueries({ queryKey: ["projects"] }),
      queryClient.invalidateQueries({ queryKey: ["artifacts"] }),
    ]);
  };

  useEffect(() => {
    const modelPath = firstRun.data?.model_path;
    if (
      profileBootstrapStarted.current || !firstRun.data?.completed || !modelPath
      || !connection.data || !profiles.data || profiles.data.length > 0
    ) return;
    profileBootstrapStarted.current = true;
    void putProfile(connection.data, {
      profile_id: "first-run-q",
      name: "Q local",
      runtime: "llama_cpp",
      model_path: modelPath,
      context_length: hardware.data?.recommended_context_length ?? 16_384,
      threads: hardware.data?.recommended_threads ?? Math.max(2, navigator.hardwareConcurrency || 8),
      batch_size: 512,
      gpu_layers: 0,
      temperature: 0.2,
      tool_calling: true,
      vision: false,
    }).then(refresh).catch((cause: unknown) => setNotice(messageOf(cause)));
  }, [connection.data, firstRun.data, hardware.data, profiles.data]);

  const runLifecycle = async (action: "start" | "sleep" | "stop") => {
    if (!connection.data) return;
    setBusy(true); setNotice(null);
    try {
      if (action === "start") {
        const profile = profiles.data?.[0];
        if (!profile) throw new Error("Añade primero un perfil GGUF en Modelos.");
        await startModel(connection.data, profile.profile_id);
      } else if (action === "sleep") await sleepModel(connection.data);
      else await stopModel(connection.data);
      await refresh();
    } catch (cause) { setNotice(messageOf(cause)); }
    finally { setBusy(false); }
  };

  const send = async () => {
    const text = draft.trim();
    if (!text || !connection.data || busy) return;
    setDraft(""); setBusy(true); setNotice(null);
    setMessages((current) => [...current, { id: crypto.randomUUID(), role: "user", content: text }]);
    try {
      let currentSession = sessionId;
      if (!currentSession) {
        const created = await createChatSession(connection.data, activeProjectId);
        currentSession = created.session_id;
        setSessionId(currentSession);
      }
      const response = await sendChatTurn(connection.data, currentSession, activeProjectId, text);
      if (response.answer) {
        setMessages((current) => [...current, { id: crypto.randomUUID(), role: "assistant", content: response.answer! }]);
      }
      const challenge = response.pending_tool_result?.data as PermissionChallenge | undefined;
      if (response.status === "confirmation_required" && challenge?.challenge_id) {
        pendingSource.current = "chat";
        setPending(challenge);
      }
    } catch (cause) { setNotice(messageOf(cause)); }
    finally { setBusy(false); }
  };

  const resolvePermission = async (allow: boolean, scope?: string) => {
    if (!pending || !connection.data) return;
    setBusy(true);
    try {
      if (pendingSource.current === "chat") {
        const response = await confirmChatPermission(connection.data, pending, allow, scope);
        setPending(null);
        if (response.answer) {
          setMessages((current) => [...current, { id: crypto.randomUUID(), role: "assistant", content: response.answer! }]);
        }
      } else if (pendingSource.current === "tool") {
        const result = await confirmToolPermission(connection.data, pending, allow, scope);
        setPending(null);
        const continuation = afterToolConfirmation.current;
        afterToolConfirmation.current = null;
        if (allow && "status" in result) {
          if (result.status === "ok") {
            if (continuation) await continuation(result);
            setNotice("Acción autorizada y ejecutada por su controlador.");
          } else {
            setNotice(result.error?.message ?? "El controlador devolvió un error tipado.");
          }
        } else if (!allow) {
          setNotice("Acción cancelada; no se ejecutó el controlador.");
        }
      } else {
        const cellId = pendingNotebookCellId.current;
        if (!cellId) throw new Error("No existe una continuación válida para esta celda.");
        const result = await confirmNotebookCellPermission(
          connection.data, cellId, pending, allow, scope,
        );
        setPending(null);
        pendingNotebookCellId.current = null;
        const continuation = afterNotebookConfirmation.current;
        afterNotebookConfirmation.current = null;
        if (continuation) await continuation();
        setNotice(
          result.status === "ok"
            ? "Celda autorizada, ejecutada una vez y persistida."
            : "La celda no se ejecutó o devolvió un error tipado.",
        );
      }
      await refresh();
    } catch (cause) { setNotice(messageOf(cause)); }
    finally { setBusy(false); }
  };

  const requestToolPermission = (
    challenge: PermissionChallenge,
    continuation?: (result: ToolResult) => Promise<void>,
  ) => {
    pendingSource.current = "tool";
    afterToolConfirmation.current = continuation ?? null;
    setPending(challenge);
  };

  const requestNotebookPermission = (
    challenge: PermissionChallenge,
    cellId: string,
    continuation?: () => Promise<void>,
  ) => {
    pendingSource.current = "notebook";
    pendingNotebookCellId.current = cellId;
    afterNotebookConfirmation.current = continuation ?? null;
    setPending(challenge);
  };

  if (firstRun.data && !firstRun.data.completed) {
    return <FirstRunWizard initial={firstRun.data} hardware={hardware.data} />;
  }

  const state = system.data?.lifecycle.state ?? "OFF";
  const activeProject = projects.data?.find((project) => project.project_id === activeProjectId) ?? null;
  const ramMb = Math.round((system.data?.resources.q_owned_ram_bytes ?? 0) / 1024 / 1024);
  const modeLabel = modeName(system.data?.mode ?? "local_only");

  return (
    <main className="app-shell">
      <aside className="sidebar" aria-label="Navegación principal">
        <div className="brand"><span className="brand-mark">Q</span><div><strong>Experimental Q</strong><small>SCIENTIFIC INTELLIGENCE</small></div></div>
        <nav>{navigation.map(([id, label]) => (
          <button className={`nav-item ${view === id ? "active" : ""}`} key={id} onClick={() => setView(id)} type="button">
            <span className="nav-dot" />{label}
          </button>
        ))}</nav>
        <section className="security-card"><span className="shield">◇</span><div><strong>{modeLabel}</strong><small>{system.data?.network_enabled ? "Red bajo política" : "Red externa bloqueada"}</small></div></section>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div><p className="eyebrow">Arquitectura 3.0 · entorno controlado</p><h1>{navigation.find(([id]) => id === view)?.[1]}</h1></div>
          <div className="lifecycle-controls" aria-label="Controles de Q">
            <button onClick={() => setPaletteOpen(true)} type="button">Ctrl K</button>
            <button onClick={() => void runLifecycle("start")} disabled={busy || state === "ACTIVE"} type="button">Iniciar Q</button>
            <button onClick={() => void runLifecycle("sleep")} disabled={busy || state !== "ACTIVE"} type="button">Suspender</button>
            <button onClick={() => void runLifecycle("stop")} disabled={busy || state === "OFF"} className="stop" type="button">Detener Q</button>
          </div>
        </header>
        {notice && <div className="notice" role="alert">{notice}<button onClick={() => setNotice(null)}>×</button></div>}

        {view === "chat" && <ChatView
          state={state} project={activeProject} messages={messages} draft={draft} busy={busy}
          recording={microphone.recording} transcribing={microphone.transcribing}
          setDraft={setDraft} send={send} toggleMic={() => void (microphone.recording ? microphone.stop() : microphone.start())}
          micError={microphone.error}
        />}
        {view === "projects" && <ProjectsView projects={projects.data ?? []} activeId={activeProjectId} select={setActiveProjectId}
          create={async (name) => { if (!connection.data) return; await createProject(connection.data, name); await refresh(); }}
          authorize={async (path) => { if (!connection.data || !activeProjectId) return; await authorizeRoot(connection.data, activeProjectId, path); setNotice("Carpeta autorizada para el proyecto activo."); }} />}
        {view === "files" && <FilesView project={activeProject} entries={files.data ?? []} loading={files.isPending} />}
        {view === "data" && <DataView connection={connection.data} project={activeProject} artifacts={artifacts.data ?? []} requestPermission={requestToolPermission} />}
        {view === "knowledge" && <KnowledgeView project={activeProject} index={async (source, content) => {
          if (!connection.data || !activeProjectId) return;
          const result = await indexKnowledge(connection.data, activeProjectId, source, content);
          setNotice(`${result.chunk_count} fragmentos indexados localmente.`);
        }} />}
        {view === "notebook" && <NotebookView connection={connection.data} project={activeProject} mode={system.data?.mode ?? "local_only"} requestPermission={requestNotebookPermission} />}
        {view === "models" && <ModelsView profiles={profiles.data ?? []} connectionReady={Boolean(connection.data)} save={async (profile) => {
          if (!connection.data) return; await putProfile(connection.data, profile); await refresh();
        }} />}
        {view === "tools" && <ToolsView />}
        {view === "memory" && <MemoryView connection={connection.data} project={activeProject} requestPermission={requestToolPermission} />}
        {view === "settings" && <SettingsView firstRun={firstRun.data} systemMode={system.data?.mode ?? "local_only"} />}
      </section>

      <aside className="artifact-rail" aria-label="Artefactos">
        <div className="rail-heading"><p className="eyebrow">Salidas verificadas</p><h2>Artefactos</h2></div>
        {(artifacts.data ?? []).slice(0, 8).map((artifact) => <article className="artifact" key={artifact.artifact_id}>
          <span>{artifact.artifact_type.toUpperCase()}</span><strong>{artifact.filename}</strong><small>{artifact.source_operation}</small>
          <small>{new Date(artifact.created_at_utc).toLocaleString()}</small><code title={artifact.provenance_id}>prov · {artifact.provenance_id.slice(0, 8)}</code>
        </article>)}
        {!artifacts.data?.length && <p className="muted">Las figuras y documentos generados aparecerán aquí con su procedencia.</p>}
      </aside>

      <footer className="statusbar">
        <span><b className={`state-dot ${state.toLowerCase()}`} /> Q {state}</span>
        <span>Modelo: {system.data?.lifecycle.model_profile_id ?? "no seleccionado"}</span>
        <span>RAM Q: {ramMb} MB</span><span>CPU Q: {(system.data?.resources.q_owned_cpu_percent ?? 0).toFixed(1)}%</span>
        <span>Red: {system.data?.network_enabled ? "bajo política" : "desactivada"}</span>
      </footer>

      {pending && <PermissionDialog challenge={pending} busy={busy} resolve={resolvePermission} />}
      {paletteOpen && <CommandPalette close={() => setPaletteOpen(false)} run={(command) => {
        setPaletteOpen(false);
        if (command === "start" || command === "sleep" || command === "stop") void runLifecycle(command);
        else setView(command);
      }} />}
    </main>
  );
}

function ChatView(props: {
  state: string; project: Project | null; messages: Message[]; draft: string; busy: boolean;
  recording: boolean; transcribing: boolean; micError: string | null;
  setDraft: (value: string) => void; send: () => Promise<void>; toggleMic: () => void;
}) {
  return <section className="chat-layout">
    <div className="conversation">
      {!props.messages.length && <div className="empty-chat"><div className="q-orbit"><span>Q</span></div>
        <p className="eyebrow">RAZONAMIENTO LOCAL · ACCIONES CONTROLADAS</p>
        <h2>{props.state === "ACTIVE" ? "¿Qué investigamos hoy?" : "Q está listo para iniciar."}</h2>
        <p>Selecciona un proyecto, inicia el modelo GGUF y conversa. Q puede razonar; cada acción pasa por un controlador, política y auditoría.</p>
      </div>}
      {props.messages.map((message) => <article className={`message ${message.role}`} key={message.id}>
        <span>{message.role === "user" ? "Tú" : "Q"}</span><p>{message.content}</p>
      </article>)}
      {props.busy && <div className="thinking"><i /><i /><i /> Q está verificando…</div>}
    </div>
    <div className="composer">
      <textarea aria-label="Mensaje para Q" value={props.draft} onChange={(event) => props.setDraft(event.target.value)}
        onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void props.send(); } }}
        placeholder={props.project ? `Pregunta dentro de ${props.project.name}` : "Pregunta a Q (sin proyecto activo)"} />
      <button className={`mic ${props.recording ? "recording" : ""}`} onClick={props.toggleMic} disabled={props.transcribing} title="Micrófono local" type="button">
        {props.transcribing ? "···" : props.recording ? "■" : "●"}
      </button>
      <button className="send" onClick={() => void props.send()} disabled={props.busy || !props.draft.trim()} type="button">Enviar</button>
    </div>
    {props.micError && <p className="inline-error">Micrófono: {props.micError}</p>}
  </section>;
}

function ProjectsView(props: { projects: Project[]; activeId: string | null; select: (id: string) => void; create: (name: string) => Promise<void>; authorize: (path: string) => Promise<void> }) {
  const [name, setName] = useState(""); const [root, setRoot] = useState("");
  return <Panel title="Espacios aislados" subtitle="Cada proyecto conserva archivos, memoria, conocimiento y procedencia independientes.">
    <form className="inline-form" onSubmit={(event) => { event.preventDefault(); if (name.trim()) void props.create(name.trim()).then(() => setName("")); }}>
      <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Nuevo proyecto" /><button>Crear proyecto</button>
    </form>
    <form className="inline-form" onSubmit={(event) => { event.preventDefault(); if (root.trim()) void props.authorize(root.trim()).then(() => setRoot("")); }}>
      <input value={root} onChange={(event) => setRoot(event.target.value)} placeholder="Carpeta local externa que autorizas explícitamente" />
      <button disabled={!props.activeId}>Autorizar carpeta</button>
    </form>
    <div className="card-grid">{props.projects.map((project) => <button type="button" onClick={() => props.select(project.project_id)}
      className={`project-card ${props.activeId === project.project_id ? "selected" : ""}`} key={project.project_id}>
      <span>PROYECTO</span><strong>{project.name}</strong><small>{project.root_path}</small>
    </button>)}</div>
  </Panel>;
}

function FilesView(props: { project: Project | null; entries: Awaited<ReturnType<typeof listFiles>>; loading: boolean }) {
  return <Panel title="Entorno escaneable autorizado" subtitle={props.project ? props.project.root_path : "Selecciona un proyecto"}>
    {props.loading ? <p className="muted">Escaneando la raíz autorizada…</p> : <div className="file-table">
      {props.entries.map((entry) => <div key={entry.relative_path}><span>{entry.kind === "directory" ? "◇" : "·"}</span><strong>{entry.relative_path}</strong><small>{entry.size_bytes == null ? "carpeta" : formatBytes(entry.size_bytes)}</small></div>)}
    </div>}
  </Panel>;
}

function DataView(props: {
  connection?: BackendConnection;
  project: Project | null;
  artifacts: Awaited<ReturnType<typeof listArtifacts>>;
  requestPermission: (
    challenge: PermissionChallenge,
    continuation?: (result: ToolResult) => Promise<void>,
  ) => void;
}) {
  const [path, setPath] = useState("Inputs/datos.csv");
  const [profile, setProfile] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const runProfile = async () => {
    if (!props.connection || !props.project) return;
    setError(null);
    const result = await invokeTool(props.connection, props.project.project_id, "spreadsheets.profile", { path, sample_rows: 20 }, "Perfilar el conjunto de datos seleccionado");
    if (result.status === "confirmation_required") {
      props.requestPermission(result.data as PermissionChallenge, async (confirmed) => {
        setProfile(confirmed.data as Record<string, unknown>);
      });
    } else if (result.status === "error") setError(result.error?.message ?? "El perfilado falló.");
    else setProfile(result.data as Record<string, unknown>);
  };
  const schema = profile && Array.isArray(profile.schema) ? profile.schema as Record<string, unknown>[] : [];
  return <Panel title="Laboratorio de datos" subtitle="CSV/XLSX/Parquet → perfil → análisis determinista → figura → procedencia.">
    <div className="pipeline"><span>Perfilado</span><b>→</b><span>Estadística</span><b>→</b><span>Visualización</span><b>→</b><span>Hash</span></div>
    <form className="inline-form" onSubmit={(event) => { event.preventDefault(); void runProfile(); }}><input value={path} onChange={(event) => setPath(event.target.value)} placeholder="Ruta autorizada CSV/XLSX/Parquet" /><button disabled={!props.project}>Perfilar</button></form>
    {error && <p className="inline-error">{error}</p>}
    {profile && <section className="data-profile"><strong>{String(profile.rows)} filas · {String(profile.columns)} columnas</strong><div className="file-table">{schema.map((column) => <div key={String(column.name)}><span>·</span><strong>{String(column.name)} · {String(column.dtype)}</strong><small>{String(column.missing)} ausentes</small></div>)}</div><pre>{JSON.stringify(profile.sample, null, 2)}</pre></section>}
    <h3>Resultados recientes</h3>{props.artifacts.filter((item) => ["png", "svg", "csv", "xlsx"].includes(item.artifact_type)).map((item) => <p key={item.artifact_id}>{item.filename} · {item.source_operation}</p>)}
  </Panel>;
}

function KnowledgeView(props: { project: Project | null; index: (source: string, content: string) => Promise<void> }) {
  const [source, setSource] = useState("nota-manual"); const [content, setContent] = useState("");
  return <Panel title="Conocimiento local" subtitle="El texto se fragmenta por estructura y se indexa en la colección Qdrant del proyecto.">
    <div className="stack-form"><input value={source} onChange={(e) => setSource(e.target.value)} aria-label="Fuente" />
      <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Pega texto científico para indexarlo…" />
      <button disabled={!props.project || !content.trim()} onClick={() => void props.index(source, content).then(() => setContent(""))}>Indexar con confirmación</button></div>
  </Panel>;
}

function NotebookView(props: {
  connection?: BackendConnection;
  project: Project | null;
  mode: AppMode;
  requestPermission: (
    challenge: PermissionChallenge,
    cellId: string,
    continuation?: () => Promise<void>,
  ) => void;
}) {
  const [activeId, setActiveId] = useState<string | null>(null);
  const [title, setTitle] = useState("Cuaderno científico");
  const [cellType, setCellType] = useState<NotebookCellType>("markdown");
  const [content, setContent] = useState("# Resultados");
  const executionSession = useRef<string>(crypto.randomUUID());
  const notebooks = useQuery({
    queryKey: ["notebooks", props.project?.project_id],
    queryFn: () => listNotebooks(props.connection!, props.project!.project_id),
    enabled: Boolean(props.connection && props.project),
  });
  useEffect(() => {
    if (!activeId && notebooks.data?.[0]) setActiveId(notebooks.data[0].notebook_id);
  }, [activeId, notebooks.data]);
  useEffect(() => {
    setActiveId(null);
    executionSession.current = crypto.randomUUID();
  }, [props.project?.project_id]);
  const notebook = useQuery({
    queryKey: ["notebook", activeId],
    queryFn: () => getNotebook(props.connection!, activeId!),
    enabled: Boolean(props.connection && activeId),
  });
  const refreshNotebook = async () => {
    await Promise.all([notebooks.refetch(), notebook.refetch()]);
  };
  const executeCell = async (cellId: string) => {
    if (!props.connection) return;
    const cell = notebook.data?.cells.find((item) => item.cell_id === cellId);
    if (cell?.cell_type === "prompt" && !executionSession.current.startsWith("chat:")) {
      const session = await createChatSession(props.connection, props.project?.project_id ?? null);
      executionSession.current = `chat:${session.session_id}`;
    }
    const sessionId = executionSession.current.replace(/^chat:/, "");
    const result = await executeNotebookCell(props.connection, cellId, sessionId, props.mode);
    const output = result.output as {
      status?: string;
      data?: unknown;
      pending_tool_result?: { status?: string; data?: unknown } | null;
    };
    const pendingResult = output.pending_tool_result ?? output;
    if (result.status === "confirmation_required" && pendingResult.status === "confirmation_required") {
      const challenge = pendingResult.data as PermissionChallenge;
      props.requestPermission(challenge, cellId, refreshNotebook);
    } else await refreshNotebook();
  };
  return <Panel title="Q Notebook" subtitle="Celdas prompt, Markdown, Python restringido, SQL de solo lectura y R estructurado.">
    <form className="inline-form" onSubmit={(event) => { event.preventDefault(); if (props.connection && props.project) void createNotebook(props.connection, props.project.project_id, title).then((created) => { setActiveId(created.notebook_id); return notebooks.refetch(); }); }}><input value={title} onChange={(event) => setTitle(event.target.value)} /><button disabled={!props.project}>Nuevo cuaderno</button></form>
    <div className="notebook-tabs">{(notebooks.data ?? []).map((item) => <button className={activeId === item.notebook_id ? "selected" : ""} onClick={() => setActiveId(item.notebook_id)} key={item.notebook_id}>{item.title}</button>)}</div>
    {activeId && <form className="stack-form cell-form" onSubmit={(event) => { event.preventDefault(); if (props.connection) void addNotebookCell(props.connection, activeId, cellType, content).then(() => { setContent(""); return refreshNotebook(); }); }}><select value={cellType} onChange={(event) => setCellType(event.target.value as NotebookCellType)}>{(["prompt", "markdown", "code", "sql", "r"] as NotebookCellType[]).map((value) => <option key={value}>{value}</option>)}</select><textarea value={content} onChange={(event) => setContent(event.target.value)} placeholder="Contenido de la celda" /><button>Añadir celda</button></form>}
    {(notebook.data?.cells ?? []).map((cell) => <div className="notebook-demo" key={cell.cell_id}><div className="cell-gutter">{String(cell.position + 1).padStart(2, "0")}</div><div><span>{cell.cell_type.toUpperCase()}</span><pre>{cell.content}</pre>{cell.output && <pre className="cell-output">{JSON.stringify(cell.output, null, 2)}</pre>}<button type="button" onClick={() => void executeCell(cell.cell_id)}>Ejecutar por controlador</button></div></div>)}
  </Panel>;
}

function ModelsView(props: { profiles: ModelProfile[]; connectionReady: boolean; save: (profile: ModelProfile) => Promise<void> }) {
  const [path, setPath] = useState(""); const [name, setName] = useState("Q local");
  return <Panel title="Núcleo reemplazable" subtitle="llama.cpp se ejecuta en loopback; el modelo permanece OFF hasta que lo inicies.">
    <div className="stack-form"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nombre del perfil" />
      <input value={path} onChange={(e) => setPath(e.target.value)} placeholder="C:\Modelos\q.gguf" />
      <button disabled={!props.connectionReady || !path.toLowerCase().endsWith(".gguf")} onClick={() => void props.save({
        profile_id: `q-${crypto.randomUUID().slice(0, 8)}`, name, runtime: "llama_cpp", model_path: path,
        context_length: 32768, threads: Math.max(2, navigator.hardwareConcurrency || 8), batch_size: 512,
        gpu_layers: 0, temperature: 0.2, tool_calling: true, vision: false,
      }).then(() => setPath(""))}>Guardar perfil GGUF</button></div>
    <div className="card-grid">{props.profiles.map((profile) => <article className="info-card" key={profile.profile_id}><span>LLAMA.CPP</span><strong>{profile.name}</strong><small>{profile.model_path}</small></article>)}</div>
  </Panel>;
}

function ToolsView() {
  const groups = ["Archivos · Documentos · PDF", "Datos · Python · R · SQL", "Visualización · Ciencia", "Memoria · Web · Investigación", "Git · Paquetes · Recursos"];
  return <Panel title="Controladores registrados" subtitle="Q no recibe shell, filesystem, red, credenciales ni procesos. Solo contratos validados.">
    <div className="tool-map">{groups.map((group, index) => <article key={group}><b>0{index + 1}</b><span>{group}</span><small>Esquema → política → permiso → auditoría</small></article>)}</div>
  </Panel>;
}

function MemoryView(props: {
  connection?: BackendConnection;
  project: Project | null;
  requestPermission: (
    challenge: PermissionChallenge,
    continuation?: (result: ToolResult) => Promise<void>,
  ) => void;
}) {
  const [scope, setScope] = useState<"user" | "project">("user");
  const [query, setQuery] = useState("biotecnología");
  const [content, setContent] = useState("");
  const [results, setResults] = useState<MemorySearchItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const search = async () => {
    if (!props.connection || (scope === "project" && !props.project)) return;
    const result = await invokeTool(props.connection, props.project?.project_id ?? null, "memory.search", { query, scope, limit: 12 }, "Buscar memoria local autorizada");
    if (result.status === "ok") setResults(result.data as MemorySearchItem[]);
    else setError(result.error?.message ?? "La búsqueda falló.");
  };
  const save = async () => {
    if (!props.connection || !content.trim()) return;
    const tool = scope === "user" ? "memory.save_user" : "memory.save_project";
    const result = await invokeTool(props.connection, props.project?.project_id ?? null, tool, { content: content.trim(), source: "desktop-explicit-save", sensitivity: false, explicit_user_request: true }, "Guardar esta memoria por solicitud explícita del usuario");
    if (result.status === "confirmation_required") {
      props.requestPermission(result.data as PermissionChallenge, async () => setContent(""));
    }
    else if (result.status === "error") setError(result.error?.message ?? "No se guardó la memoria.");
    else setContent("");
  };
  return <Panel title="Memoria personal y de proyecto" subtitle="Persistencia explícita, aislamiento por proyecto y recuperación local.">
    <div className="privacy-grid"><article><strong>Sesión</strong><p>Efímera; desaparece al cerrar.</p></article><article><strong>Proyecto</strong><p>Solo en el proyecto activo.</p></article><article><strong>Preferencias</strong><p>Guardar requiere tu confirmación.</p></article><article><strong>Sensible</strong><p>Se rechaza sin bóveda cifrada.</p></article></div>
    <div className="memory-controls"><select value={scope} onChange={(event) => setScope(event.target.value as "user" | "project")}><option value="user">Preferencias personales</option><option value="project" disabled={!props.project}>Proyecto activo</option></select><input value={query} onChange={(event) => setQuery(event.target.value)} /><button onClick={() => void search()}>Buscar localmente</button></div>
    {error && <p className="inline-error">{error}</p>}
    <div className="memory-results">{results.map((item) => <article key={item.record.memory_id}><span>{item.record.scope} · {(item.score * 100).toFixed(0)}%</span><p>{item.record.content}</p><small>{item.record.source}</small></article>)}</div>
    <div className="stack-form"><textarea value={content} onChange={(event) => setContent(event.target.value)} placeholder="Preferencia no sensible que deseas guardar" /><button disabled={!content.trim() || (scope === "project" && !props.project)} onClick={() => void save()}>Guardar con confirmación</button></div>
  </Panel>;
}

function SettingsView({ firstRun, systemMode }: { firstRun?: FirstRunStatus; systemMode: AppMode }) {
  return <Panel title="Seguridad y ejecución" subtitle="No hay telemetría, arranque automático ni actualizaciones silenciosas.">
    <dl className="settings-list"><div><dt>Modo</dt><dd>{modeName(systemMode)}</dd></div><div><dt>Workspace</dt><dd>{firstRun?.workspace ?? "ExperimentalQ"}</dd></div>
      <div><dt>llama.cpp</dt><dd>{firstRun?.llama_runtime ?? "Runtime incluido por el instalador"}</dd></div><div><dt>Micrófono</dt><dd>PCM local → whisper.cpp; audio efímero</dd></div>
      <div><dt>Inicio de Windows</dt><dd>Desactivado por diseño</dd></div></dl>
  </Panel>;
}

function Panel({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return <section className="panel"><p className="eyebrow">Experimental Q</p><h2>{title}</h2><p className="panel-subtitle">{subtitle}</p>{children}</section>;
}

function PermissionDialog({ challenge, busy, resolve }: { challenge: PermissionChallenge; busy: boolean; resolve: (allow: boolean, scope?: string) => Promise<void> }) {
  return <div className="modal-backdrop"><section className="permission-dialog" role="dialog" aria-modal="true" aria-labelledby="permission-title">
    <span className={challenge.destructive ? "risk destructive" : "risk"}>{challenge.destructive ? "ACCIÓN DESTRUCTIVA" : "CONFIRMACIÓN"}</span>
    <h2 id="permission-title">Q solicita autorización</h2><dl><div><dt>Herramienta</dt><dd>{challenge.tool}</dd></div><div><dt>Acción</dt><dd>{challenge.action}</dd></div>
      <div><dt>Recurso exacto</dt><dd>{challenge.resource ?? "Sin recurso externo"}</dd></div><div><dt>Propósito</dt><dd>{challenge.reason}</dd></div></dl>
    <div className="dialog-actions"><button disabled={busy} onClick={() => void resolve(false)}>Cancelar</button>
      {challenge.allowed_scopes.map((scope) => <button disabled={busy} onClick={() => void resolve(true, scope)} key={scope}>Permitir para {scope}</button>)}
      <button className="primary" disabled={busy} onClick={() => void resolve(true)}>Permitir una vez</button></div>
  </section></div>;
}

function CommandPalette(props: { close: () => void; run: (command: View | "start" | "sleep" | "stop") => void }) {
  const commands: Array<[string, View | "start" | "sleep" | "stop"]> = [
    ["Nuevo proyecto", "projects"], ["Abrir conjunto de datos", "data"],
    ["Abrir base de conocimiento", "knowledge"], ["Iniciar Q", "start"],
    ["Suspender Q", "sleep"], ["Detener Q", "stop"],
    ["Ejecutar análisis", "data"], ["Abrir Notebook", "notebook"], ["Ajustes", "settings"],
  ];
  return <div className="modal-backdrop" onMouseDown={props.close}><section className="command-palette" role="dialog" aria-modal="true" aria-label="Paleta de comandos" onMouseDown={(event) => event.stopPropagation()}><p className="eyebrow">COMANDOS · CTRL K</p>{commands.map(([label, command]) => <button type="button" onClick={() => props.run(command)} key={`${label}-${command}`}>{label}<span>↵</span></button>)}</section></div>;
}

function FirstRunWizard({ initial, hardware }: { initial: FirstRunStatus; hardware?: HardwareSnapshot }) {
  const [step, setStep] = useState(0); const [saving, setSaving] = useState(false); const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<Omit<FirstRunStatus, "completed">>({
    workspace: initial.workspace, mode: initial.mode, llama_runtime: initial.llama_runtime,
    model_path: initial.model_path, whisper_runtime: initial.whisper_runtime, whisper_model: initial.whisper_model,
  });
  const steps = useMemo(() => ["Workspace", "Modo", "Modelo Q", "Micrófono", "Finalizar"], []);
  const update = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value || null }));
  return <main className="wizard"><section><div className="brand wizard-brand"><span className="brand-mark">Q</span><div><strong>Experimental Q</strong><small>PRIMER INICIO SEGURO</small></div></div>
    <div className="steps">{steps.map((label, index) => <span className={index <= step ? "done" : ""} key={label}>{index + 1}<small>{label}</small></span>)}</div>
    {step === 0 && <WizardPage title="Elige tu espacio de trabajo" text="Q solo podrá explorar esta raíz y las carpetas que autorices después."><input value={form.workspace} onChange={(e) => update("workspace", e.target.value)} /></WizardPage>}
    {step === 1 && <WizardPage title="Selecciona el modo" text="Local Only es el valor seguro y bloquea toda red externa."><div className="mode-options">{(["local_only", "hybrid", "connected"] as AppMode[]).map((mode) => <button className={form.mode === mode ? "selected" : ""} onClick={() => setForm((v) => ({ ...v, mode }))} key={mode}>{modeName(mode)}</button>)}</div></WizardPage>}
    {step === 2 && <WizardPage title="Conecta el núcleo GGUF" text="El instalador incluye un GGUF local verificado. Puedes sustituirlo por otro; Q arrancará siempre OFF.">
      <div className="card-grid"><article className="info-card"><span>CPU DETECTADA</span><strong>{hardware?.logical_cpus ?? "…"} hilos</strong><small>Recomendación: {hardware?.recommended_threads ?? "…"} para Q</small></article>
        <article className="info-card"><span>RAM DETECTADA</span><strong>{hardware ? formatBytes(hardware.total_memory_bytes) : "…"}</strong><small>Contexto recomendado: {hardware?.recommended_context_length ?? "…"}</small></article></div>
      <input placeholder="Runtime incluido; ruta opcional a llama-server.exe" value={form.llama_runtime ?? ""} onChange={(e) => update("llama_runtime", e.target.value)} /><input placeholder="GGUF incluido; ruta opcional a otro modelo" value={form.model_path ?? ""} onChange={(e) => update("model_path", e.target.value)} />
    </WizardPage>}
    {step === 3 && <WizardPage title="Voz completamente local" text="El audio se convierte a WAV y se transcribe con whisper.cpp; el archivo temporal se elimina."><input placeholder="Ruta a whisper-cli.exe" value={form.whisper_runtime ?? ""} onChange={(e) => update("whisper_runtime", e.target.value)} /><input placeholder="Ruta al modelo ggml-base.bin" value={form.whisper_model ?? ""} onChange={(e) => update("whisper_model", e.target.value)} /></WizardPage>}
    {step === 4 && <WizardPage title="Configuración preparada" text="La aplicación se reiniciará. Q seguirá OFF y no se añadirá al inicio de Windows."><div className="summary"><p><b>Workspace</b>{form.workspace}</p><p><b>Modo</b>{modeName(form.mode)}</p><p><b>Modelo</b>{form.model_path ?? "Pendiente"}</p></div></WizardPage>}
    {error && <p className="inline-error">{error}</p>}<div className="wizard-actions"><button disabled={step === 0 || saving} onClick={() => setStep((value) => value - 1)}>Atrás</button>
      {step < steps.length - 1 ? <button className="primary" onClick={() => setStep((value) => value + 1)}>Continuar</button> : <button className="primary" disabled={saving} onClick={() => { setSaving(true); void completeFirstRun(form).catch((cause) => { setError(messageOf(cause)); setSaving(false); }); }}>Guardar y reiniciar</button>}</div>
  </section></main>;
}

function WizardPage({ title, text, children }: { title: string; text: string; children: React.ReactNode }) { return <div className="wizard-page"><p className="eyebrow">CONFIGURACIÓN GUIADA</p><h1>{title}</h1><p>{text}</p><div className="stack-form">{children}</div></div>; }
function messageOf(value: unknown) { return value instanceof Error ? value.message : "La operación falló con un error tipado."; }
function modeName(mode: AppMode) { return mode === "local_only" ? "Local Only" : mode === "hybrid" ? "Hybrid" : "Connected"; }
function formatBytes(value: number) { if (value < 1024) return `${value} B`; if (value < 1048576) return `${(value / 1024).toFixed(1)} KB`; return `${(value / 1048576).toFixed(1)} MB`; }
