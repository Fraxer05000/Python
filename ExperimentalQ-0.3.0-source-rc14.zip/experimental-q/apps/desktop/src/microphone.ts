import { useCallback, useRef, useState } from "react";
import type { BackendConnection } from "./api";
import { transcribeAudio } from "./api";

interface RecorderState {
  stream: MediaStream;
  context: AudioContext;
  source: MediaStreamAudioSourceNode;
  processor: ScriptProcessorNode;
  silentGain: GainNode;
  chunks: Float32Array[];
}

export function useLocalMicrophone(
  connection: BackendConnection | undefined,
  onText: (text: string) => void,
) {
  const recorder = useRef<RecorderState | null>(null);
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const start = useCallback(async () => {
    setError(null);
    if (!connection) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      const context = new AudioContext();
      const source = context.createMediaStreamSource(stream);
      const processor = context.createScriptProcessor(4096, 1, 1);
      const silentGain = context.createGain();
      silentGain.gain.value = 0;
      const chunks: Float32Array[] = [];
      processor.onaudioprocess = (event) => {
        chunks.push(new Float32Array(event.inputBuffer.getChannelData(0)));
      };
      source.connect(processor);
      processor.connect(silentGain);
      silentGain.connect(context.destination);
      recorder.current = { stream, context, source, processor, silentGain, chunks };
      setRecording(true);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No se pudo abrir el micrófono.");
    }
  }, [connection]);

  const stop = useCallback(async () => {
    const active = recorder.current;
    if (!active || !connection) return;
    recorder.current = null;
    setRecording(false);
    active.processor.disconnect();
    active.source.disconnect();
    active.silentGain.disconnect();
    active.stream.getTracks().forEach((track) => track.stop());
    const sourceRate = active.context.sampleRate;
    await active.context.close();
    try {
      setTranscribing(true);
      const merged = merge(active.chunks);
      const samples = resample(merged, sourceRate, 16_000);
      const text = await transcribeAudio(connection, encodeWav(samples, 16_000));
      if (text) onText(text);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "La transcripción local falló.");
    } finally {
      setTranscribing(false);
    }
  }, [connection, onText]);

  return { recording, transcribing, error, start, stop };
}

function merge(chunks: Float32Array[]): Float32Array {
  const length = chunks.reduce((total, chunk) => total + chunk.length, 0);
  const output = new Float32Array(length);
  let offset = 0;
  for (const chunk of chunks) { output.set(chunk, offset); offset += chunk.length; }
  return output;
}

function resample(input: Float32Array, sourceRate: number, targetRate: number): Float32Array {
  if (sourceRate === targetRate) return input;
  const ratio = sourceRate / targetRate;
  const output = new Float32Array(Math.max(1, Math.floor(input.length / ratio)));
  for (let index = 0; index < output.length; index += 1) {
    const start = Math.floor(index * ratio);
    const end = Math.min(input.length, Math.floor((index + 1) * ratio));
    let sum = 0;
    for (let source = start; source < end; source += 1) sum += input[source];
    output[index] = sum / Math.max(1, end - start);
  }
  return output;
}

function encodeWav(samples: Float32Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);
  writeText(view, 0, "RIFF");
  view.setUint32(4, 36 + samples.length * 2, true);
  writeText(view, 8, "WAVE");
  writeText(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeText(view, 36, "data");
  view.setUint32(40, samples.length * 2, true);
  for (let index = 0; index < samples.length; index += 1) {
    const sample = Math.max(-1, Math.min(1, samples[index]));
    view.setInt16(44 + index * 2, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
  }
  return new Blob([buffer], { type: "audio/wav" });
}

function writeText(view: DataView, offset: number, value: string) {
  for (let index = 0; index < value.length; index += 1) view.setUint8(offset + index, value.charCodeAt(index));
}
