import { render, screen } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { expect, test, vi } from "vitest";
import { App } from "./App";

vi.mock("./api", () => ({
  fetchArtifacts: vi.fn().mockResolvedValue([]),
  getBackendConnection: vi.fn().mockRejectedValue(new Error("sidecar not started in component test")),
  getFirstRunStatus: vi.fn().mockResolvedValue({ completed: true, config: null }),
  getHardwareSnapshot: vi.fn().mockResolvedValue({
    total_memory_bytes: 16_000_000_000,
    available_memory_bytes: 8_000_000_000,
    logical_cpus: 8,
    recommended_threads: 7,
    recommended_context_length: 16384,
  }),
  fetchHealth: vi.fn(),
  fetchSystemState: vi.fn().mockResolvedValue({ state: "OFF", model_loaded: false }),
  listModelProfiles: vi.fn().mockResolvedValue([]),
  listProjects: vi.fn().mockResolvedValue([]),
}));

test("renders Q as OFF and Local Only", () => {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  render(<QueryClientProvider client={client}><App /></QueryClientProvider>);
  expect(screen.getAllByText(/Q OFF/i).length).toBeGreaterThan(0);
  expect(screen.getAllByText(/Local Only/i).length).toBeGreaterThan(0);
  expect(screen.getByText(/Red externa bloqueada/i)).toBeInTheDocument();
});
