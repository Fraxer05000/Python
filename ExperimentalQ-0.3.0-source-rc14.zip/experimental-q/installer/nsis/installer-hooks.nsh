!include "FileFunc.nsh"
!include "LogicLib.nsh"

!define Q_MINIMUM_WINDOWS_BUILD 19041
!define Q_MINIMUM_FREE_SPACE_MB 6144

!macro NSIS_HOOK_PREINSTALL
  ReadRegStr $0 HKLM "SOFTWARE\Microsoft\Windows NT\CurrentVersion" "CurrentBuildNumber"
  ${If} $0 == ""
    MessageBox MB_ICONSTOP|MB_OK "No se pudo verificar la versión de Windows. Experimental Q requiere Windows 10 2004 (build 19041) o posterior."
    Abort
  ${EndIf}
  IntCmp $0 ${Q_MINIMUM_WINDOWS_BUILD} q_version_ok q_version_unsupported q_version_ok
  q_version_unsupported:
    MessageBox MB_ICONSTOP|MB_OK "Experimental Q requiere Windows 10 2004 (build 19041) o posterior."
    Abort
  q_version_ok:

  ${GetRoot} "$INSTDIR" $1
  ${DriveSpace} "$1" "/D=F /S=M" $2
  IntCmp $2 ${Q_MINIMUM_FREE_SPACE_MB} q_disk_ok q_disk_low q_disk_ok
  q_disk_low:
    MessageBox MB_ICONSTOP|MB_OK "Se requieren al menos 6 GB libres para instalar Experimental Q y WebView2 sin conexión."
    Abort
  q_disk_ok:
!macroend

!macro NSIS_HOOK_PREUNINSTALL
  MessageBox MB_ICONQUESTION|MB_YESNO|MB_DEFBUTTON2 "¿Eliminar también la caché interna del shell de Experimental Q? Los proyectos, modelos y la carpeta de trabajo se conservarán." IDNO q_keep_shell_cache
    RMDir /r "$LOCALAPPDATA\ec.edu.unemi.experimental-q\Cache"
  q_keep_shell_cache:
!macroend

