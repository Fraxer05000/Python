from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[2]
LOCK_PATH = ROOT / "installer" / "runtime-sources.lock.json"


def test_runtime_sources_are_fully_pinned_and_allowlisted() -> None:
    document = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    assert document["format_version"] == 1
    assert document["target"] == "windows-x86_64"

    runtimes = document["native_runtimes"]
    assert set(runtimes) == {"llama_cpp", "whisper_cpp"}
    assert runtimes["llama_cpp"]["source_repository"] == (
        "https://github.com/ggml-org/llama.cpp.git"
    )
    assert runtimes["whisper_cpp"]["source_repository"] == (
        "https://github.com/ggml-org/whisper.cpp.git"
    )
    for runtime in runtimes.values():
        assert len(runtime["commit_sha"]) == 40
        assert all(character in "0123456789abcdef" for character in runtime["commit_sha"])
        assert runtime["required_executable"].endswith(".exe")

    models = document["models"]
    assert set(models) == {"q", "whisper"}
    assert models["q"]["installed_name"] == "experimental-q.gguf"
    assert models["q"]["license"] == "Apache-2.0"
    for model in models.values():
        uri = urlparse(model["source_url"])
        assert uri.scheme == "https"
        assert uri.hostname == "huggingface.co"
        assert len(model["sha256"]) == 64
        assert all(character in "0123456789abcdef" for character in model["sha256"])


def test_packaging_scripts_do_not_embed_credentials_or_enable_startup() -> None:
    paths = (
        ROOT / "scripts" / "prepare_windows_dependencies.ps1",
        ROOT / "scripts" / "build_windows.ps1",
        ROOT / "scripts" / "smoke_test_windows_installers.ps1",
        ROOT / ".github" / "workflows" / "release-windows.yml",
    )
    combined = "\n".join(path.read_text(encoding="utf-8") for path in paths).lower()
    assert "set-itemproperty" not in combined
    assert "new-itemproperty" not in combined
    assert "schtasks" not in combined
    assert "password=" not in combined
    assert "api_key=" not in combined


def test_native_build_stdout_cannot_pollute_runtime_manifest() -> None:
    script = (ROOT / "scripts" / "prepare_windows_dependencies.ps1").read_text(
        encoding="utf-8"
    )
    assert "Invoke-Checked cmake $Options | Out-Host" in script
    assert '"--parallel", "2") | Out-Host' in script
