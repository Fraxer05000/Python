from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import cast
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from httpx import Response


def _project(client: TestClient) -> dict[str, str]:
    response = client.post("/api/v1/projects", json={"name": "Boundary test"})
    assert response.status_code == 201
    return cast(dict[str, str], response.json())


def _invoke(
    client: TestClient,
    project_id: str,
    tool: str,
    arguments: dict[str, object],
) -> Response:
    return client.post(
        "/api/v1/tools/invoke",
        json={
            "request_id": str(uuid4()),
            "tool": tool,
            "arguments": arguments,
            "reason": "Prueba de seguridad",
            "project_id": project_id,
        },
    )


def test_read_inside_project_and_reject_traversal(client: TestClient) -> None:
    project = _project(client)
    root = Path(project["root_path"])
    target = root / "Inputs" / "hello.txt"
    target.write_text("hola", encoding="utf-8")

    allowed = _invoke(client, project["project_id"], "files.read", {"path": "Inputs/hello.txt"})
    assert allowed.json()["status"] == "ok"
    assert allowed.json()["data"]["content"] == "hola"

    denied = _invoke(
        client,
        project["project_id"],
        "files.read",
        {"path": "../../Windows/System32"},
    )
    assert denied.json()["status"] == "error"
    assert denied.json()["error"]["code"] == "sandbox_violation"


@pytest.mark.skipif(os.name == "nt", reason="Windows junction test runs in Windows CI")
def test_symlink_escape_is_denied(client: TestClient, tmp_path: Path) -> None:
    project = _project(client)
    root = Path(project["root_path"])
    outside = tmp_path / "outside.txt"
    outside.write_text("secret", encoding="utf-8")
    (root / "Inputs" / "escape.txt").symlink_to(outside)

    response = _invoke(
        client,
        project["project_id"],
        "files.read",
        {"path": "Inputs/escape.txt"},
    )
    assert response.json()["status"] == "error"
    assert response.json()["error"]["code"] == "sandbox_violation"


@pytest.mark.skipif(os.name == "nt", reason="Windows junction test runs in Windows CI")
def test_delete_internal_symlink_does_not_delete_its_target(client: TestClient) -> None:
    project = _project(client)
    root = Path(project["root_path"])
    target = root / "Inputs" / "target.txt"
    link = root / "Inputs" / "link.txt"
    target.write_text("preserve", encoding="utf-8")
    link.symlink_to(target)

    pending = _invoke(client, project["project_id"], "files.delete", {"path": "Inputs/link.txt"})
    challenge = pending.json()["data"]
    completed = client.post(
        "/api/v1/permissions/confirm",
        json={
            "challenge_id": challenge["challenge_id"],
            "confirmation_secret": challenge["confirmation_secret"],
            "allow": True,
        },
    )
    assert completed.json()["status"] == "ok"
    assert not link.exists()
    assert target.read_text(encoding="utf-8") == "preserve"


def test_delete_requires_one_time_confirmation(client: TestClient) -> None:
    project = _project(client)
    target = Path(project["root_path"]) / "Inputs" / "delete-me.txt"
    target.write_text("data", encoding="utf-8")
    pending_response = _invoke(
        client,
        project["project_id"],
        "files.delete",
        {"path": "Inputs/delete-me.txt"},
    )
    assert pending_response.status_code == 409
    pending = pending_response.json()
    assert pending["status"] == "confirmation_required"
    assert target.exists()

    challenge = pending["data"]
    confirmed = client.post(
        "/api/v1/permissions/confirm",
        json={
            "challenge_id": challenge["challenge_id"],
            "confirmation_secret": challenge["confirmation_secret"],
            "allow": True,
        },
    )
    assert confirmed.json()["status"] == "ok"
    assert not target.exists()

    reused = client.post(
        "/api/v1/permissions/confirm",
        json={
            "challenge_id": challenge["challenge_id"],
            "confirmation_secret": challenge["confirmation_secret"],
            "allow": True,
        },
    )
    assert reused.status_code == 403


def test_raw_shell_tool_does_not_exist(client: TestClient) -> None:
    project = _project(client)
    response = _invoke(
        client,
        project["project_id"],
        "shell.run",
        {"command": "whoami"},
    )
    assert response.json()["status"] == "error"
    assert response.json()["error"]["code"] == "validation_error"


def test_write_update_and_external_root_require_correct_scope(client: TestClient) -> None:
    project = _project(client)
    project_id = project["project_id"]
    created = _invoke(
        client,
        project_id,
        "files.write_new",
        {"path": "Outputs/result.txt", "content": "version 1"},
    )
    assert created.status_code == 200
    assert created.json()["status"] == "ok"

    overwrite = _invoke(
        client,
        project_id,
        "files.update",
        {"path": "Outputs/result.txt", "content": "version 2"},
    )
    assert overwrite.status_code == 409
    assert Path(project["root_path"], "Outputs", "result.txt").read_text() == "version 1"

    challenge = overwrite.json()["data"]
    completed = client.post(
        "/api/v1/permissions/confirm",
        json={
            "challenge_id": challenge["challenge_id"],
            "confirmation_secret": challenge["confirmation_secret"],
            "allow": True,
        },
    )
    assert completed.json()["status"] == "ok"
    assert Path(project["root_path"], "Outputs", "result.txt").read_text() == "version 2"

    with tempfile.TemporaryDirectory(prefix="q-authorized-") as external_value:
        external = Path(external_value).resolve()
        target = external / "external.txt"
        target.write_text("external authorized content", encoding="utf-8")
        authorized = client.post(
            f"/api/v1/projects/{project_id}/authorized-roots",
            json={"path": str(external), "explicit_user_confirmation": True},
        )
        assert authorized.status_code == 201
        pending = _invoke(
            client,
            project_id,
            "files.read",
            {"path": str(target)},
        )
        assert pending.status_code == 409
        assert pending.json()["status"] == "confirmation_required"
        external_challenge = pending.json()["data"]
        granted = client.post(
            "/api/v1/permissions/confirm",
            json={
                "challenge_id": external_challenge["challenge_id"],
                "confirmation_secret": external_challenge["confirmation_secret"],
                "allow": True,
                "grant_scope": "folder",
            },
        )
        assert granted.json()["status"] == "ok"
        grants = client.get("/api/v1/permissions/grants").json()
        assert len(grants) == 1
        assert grants[0]["scope"] == "folder"
        assert grants[0]["resource"] == str(external)
        unconfirmed_revoke = client.delete(
            f"/api/v1/permissions/grants/{grants[0]['grant_id']}"
        )
        assert unconfirmed_revoke.status_code == 409
        revoked = client.delete(
            f"/api/v1/permissions/grants/{grants[0]['grant_id']}",
            params={"explicit_user_confirmation": True},
        )
        assert revoked.status_code == 200
        assert client.get("/api/v1/permissions/grants").json() == []
