from __future__ import annotations

import json
import logging
from uuid import uuid4

from fastapi.testclient import TestClient
from q_backend.logging_config import JsonFormatter


def test_local_only_web_request_is_denied_before_network(client: TestClient) -> None:
    response = client.post(
        "/api/v1/tools/invoke",
        json={
            "request_id": str(uuid4()),
            "tool": "web.search",
            "arguments": {"query": "Experimental Q"},
            "reason": "Comprobar el bloqueo de red",
            "project_id": None,
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "error"
    assert body["error"]["code"] == "network_disabled"


def test_structured_logs_redact_sensitive_keys_and_known_values() -> None:
    secret = "runtime-secret-value-123456"  # noqa: S105 - synthetic redaction fixture
    record = logging.LogRecord(
        name="q.test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg=f"request carried {secret}",
        args=(),
        exc_info=None,
    )
    record.context = {
        "confirmation_secret": "one-time-secret",
        "nested": {"access_token": secret, "safe": "visible"},
    }
    encoded = JsonFormatter((secret,)).format(record)
    payload = json.loads(encoded)
    assert secret not in encoded
    assert "one-time-secret" not in encoded
    assert payload["context"]["confirmation_secret"] == "[REDACTED]"  # noqa: S105
    assert payload["context"]["nested"]["access_token"] == "[REDACTED]"  # noqa: S105
    assert payload["context"]["nested"]["safe"] == "visible"
