from __future__ import annotations

import importlib
import json
import subprocess
import sys
from pathlib import Path

import pytest
from q_backend.controllers.sql import _validate_read_only_sql
from q_backend.errors import QError, QErrorCode

ROOT = Path(__file__).resolve().parents[2]


def _run_worker(
    path: Path,
    payload: dict[str, object],
    cwd: Path,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(  # noqa: S603 - fixed test interpreter and repository entry point
        [sys.executable, str(path)],
        input=json.dumps(payload),
        text=True,
        capture_output=True,
        cwd=cwd,
        check=False,
        timeout=10,
    )


def test_python_worker_allows_bounded_computation_and_denies_import(tmp_path: Path) -> None:
    worker = ROOT / "runtimes" / "python_worker" / "main.py"
    allowed = _run_worker(worker, {"code": "result = sum(range(4))"}, tmp_path)
    assert allowed.returncode == 0
    assert json.loads(allowed.stdout)["result"] == 6

    denied = _run_worker(worker, {"code": "import os\nresult = os.getcwd()"}, tmp_path)
    assert denied.returncode == 2
    assert json.loads(denied.stdout)["status"] == "error"


def test_python_worker_defers_resource_limits_to_windows_controller(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    worker_module = importlib.import_module("runtimes.python_worker.main")
    monkeypatch.setattr(worker_module.sys, "platform", "win32")
    worker_module._limits()


def test_sql_worker_and_parser_reject_mutation(tmp_path: Path) -> None:
    worker = ROOT / "runtimes" / "sql_worker" / "main.py"
    database = tmp_path / "data.sqlite3"
    selected = _run_worker(
        worker,
        {
            "engine": "sqlite",
            "database_path": str(database),
            "query": "SELECT 1 AS value",
            "parameters": [],
        },
        tmp_path,
    )
    assert selected.returncode == 0
    assert json.loads(selected.stdout)["rows"] == [[1]]

    try:
        _validate_read_only_sql("DELETE FROM samples", "sqlite")
    except QError as error:
        assert error.code is QErrorCode.SANDBOX_VIOLATION
    else:
        raise AssertionError("mutating SQL was accepted")
