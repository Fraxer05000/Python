from __future__ import annotations

import json
from pathlib import Path
from typing import cast

import yaml
from fastapi import FastAPI
from fastapi.testclient import TestClient
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
ARCHITECTURE = ROOT / "docs" / "architecture-v3"


def test_machine_readable_registry_and_policy_are_canonical_copies() -> None:
    architecture_registry = json.loads(
        (ARCHITECTURE / "06_TOOL_REGISTRY.json").read_text(encoding="utf-8")
    )
    runtime_registry = json.loads(
        (ROOT / "config" / "tool_registry.json").read_text(encoding="utf-8")
    )
    assert runtime_registry == architecture_registry

    architecture_policy = yaml.safe_load(
        (ARCHITECTURE / "07_PERMISSION_POLICY.yaml").read_text(encoding="utf-8")
    )
    runtime_policy = yaml.safe_load(
        (ROOT / "config" / "permission_policy.yaml").read_text(encoding="utf-8")
    )
    assert runtime_policy == architecture_policy


def test_local_wire_schemas_and_architecture_models_are_valid() -> None:
    for path in sorted((ROOT / "schemas").glob("*.schema.json")):
        Draft202012Validator.check_schema(json.loads(path.read_text(encoding="utf-8")))
    architecture_models = json.loads(
        (ARCHITECTURE / "08_DATA_MODELS.json").read_text(encoding="utf-8")
    )
    Draft202012Validator.check_schema(architecture_models)


def test_canonical_api_paths_and_methods_are_implemented(client: TestClient) -> None:
    contract = yaml.safe_load(
        (ARCHITECTURE / "05_API_CONTRACTS.yaml").read_text(encoding="utf-8")
    )
    implemented = cast(FastAPI, client.app).openapi()["paths"]
    for relative_path, operations in contract["paths"].items():
        actual = implemented[f"/api/v1{relative_path}"]
        for method in operations:
            assert method in actual


def test_no_raw_shell_surface_is_registered_or_present() -> None:
    registry = json.loads((ROOT / "config" / "tool_registry.json").read_text(encoding="utf-8"))
    registered = {tool["name"] for tool in registry["tools"]}
    assert not any(name.startswith(("shell.", "process.", "registry.")) for name in registered)

    production_files = [
        *sorted((ROOT / "apps" / "backend" / "q_backend").rglob("*.py")),
        *sorted((ROOT / "runtimes").rglob("*.py")),
    ]
    combined = "\n".join(path.read_text(encoding="utf-8") for path in production_files)
    assert "shell=True" not in combined
    assert "os.system(" not in combined
