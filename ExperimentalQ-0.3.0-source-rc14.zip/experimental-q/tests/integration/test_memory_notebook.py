from __future__ import annotations

from uuid import uuid4

from fastapi.testclient import TestClient


def _invoke(
    client: TestClient,
    tool: str,
    arguments: dict[str, object],
    project_id: str | None = None,
) -> dict[str, object]:
    response = client.post(
        "/api/v1/tools/invoke",
        json={
            "request_id": str(uuid4()),
            "tool": tool,
            "arguments": arguments,
            "reason": "Prueba de memoria local",
            "project_id": project_id,
        },
    )
    assert response.status_code in {200, 409}
    body: dict[str, object] = response.json()
    return body


def test_personal_seed_is_local_and_sensitive_memory_is_rejected(client: TestClient) -> None:
    results = _invoke(
        client,
        "memory.search",
        {"query": "celdas de combustible microbianas", "scope": "user", "limit": 10},
    )
    assert results["status"] == "ok"
    data = results["data"]
    assert isinstance(data, list)
    assert any("combustible microbianas" in item["record"]["content"] for item in data)

    pending = _invoke(
        client,
        "memory.save_user",
        {
            "content": "dato sensible que no debe persistirse",
            "source": "acceptance-test",
            "sensitivity": True,
            "explicit_user_request": True,
        },
    )
    assert pending["status"] == "confirmation_required"
    challenge = pending["data"]
    assert isinstance(challenge, dict)
    confirmed = client.post(
        "/api/v1/permissions/confirm",
        json={
            "challenge_id": challenge["challenge_id"],
            "confirmation_secret": challenge["confirmation_secret"],
            "allow": True,
        },
    )
    assert confirmed.status_code == 200
    assert confirmed.json()["status"] == "error"
    assert confirmed.json()["error"]["code"] == "runtime_unavailable"


def test_notebook_markdown_persists_and_code_uses_tool_manager(client: TestClient) -> None:
    project = client.post("/api/v1/projects", json={"name": "Notebook"}).json()
    project_id = project["project_id"]
    notebook = client.post(
        "/api/v1/notebooks",
        json={"project_id": project_id, "title": "Ensayo local"},
    ).json()
    markdown = client.post(
        f"/api/v1/notebooks/{notebook['notebook_id']}/cells",
        json={"cell_type": "markdown", "content": "# Resultados"},
    ).json()
    executed = client.post(
        f"/api/v1/notebook-cells/{markdown['cell_id']}/execute",
        json={"session_id": str(uuid4()), "mode": "local_only"},
    ).json()
    assert executed["status"] == "ok"
    assert executed["output"] == {"rendered": "# Resultados"}

    code = client.post(
        f"/api/v1/notebooks/{notebook['notebook_id']}/cells",
        json={"cell_type": "code", "content": "result = 2 + 2"},
    ).json()
    gated = client.post(
        f"/api/v1/notebook-cells/{code['cell_id']}/execute",
        json={"session_id": str(uuid4()), "mode": "local_only"},
    ).json()
    assert gated["status"] == "confirmation_required"
    assert gated["output"]["status"] == "confirmation_required"
    challenge = gated["output"]["data"]
    confirmed = client.post(
        f"/api/v1/notebook-cells/{code['cell_id']}/permissions/confirm",
        json={
            "challenge_id": challenge["challenge_id"],
            "confirmation_secret": challenge["confirmation_secret"],
            "allow": True,
        },
    )
    assert confirmed.status_code == 200
    assert confirmed.json()["status"] == "error"
    assert confirmed.json()["output"]["error"]["code"] == "runtime_unavailable"

    persisted = client.get(f"/api/v1/notebooks/{notebook['notebook_id']}").json()
    persisted_code = next(cell for cell in persisted["cells"] if cell["cell_id"] == code["cell_id"])
    assert persisted_code["output"]["status"] == "error"

    replay = client.post(
        f"/api/v1/notebook-cells/{code['cell_id']}/permissions/confirm",
        json={
            "challenge_id": challenge["challenge_id"],
            "confirmation_secret": challenge["confirmation_secret"],
            "allow": True,
        },
    )
    assert replay.status_code in {403, 404}
