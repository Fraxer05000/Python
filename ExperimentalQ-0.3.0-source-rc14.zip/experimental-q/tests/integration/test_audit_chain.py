from __future__ import annotations

import hashlib
import json
from pathlib import Path

from fastapi.testclient import TestClient
from q_backend.config import Settings


def test_audit_log_is_hash_chained_and_omits_file_content(
    client: TestClient,
    settings: Settings,
) -> None:
    project = client.post("/api/v1/projects", json={"name": "Audit"}).json()
    sensitive_content = "content-that-must-not-enter-audit"
    target = Path(project["root_path"], "Inputs", "source.txt")
    target.write_text(sensitive_content, encoding="utf-8")
    response = client.post(
        "/api/v1/tools/invoke",
        json={
            "request_id": "69c9b833-1741-4dee-92b5-ed43403d10d3",
            "tool": "files.read",
            "arguments": {"path": "Inputs/source.txt"},
            "reason": "Verificar auditoría",
            "project_id": project["project_id"],
        },
    )
    assert response.json()["status"] == "ok"

    lines = settings.audit_log_path.read_text(encoding="utf-8").splitlines()
    events = [json.loads(line) for line in lines]
    assert len(events) >= 2
    previous = ""
    for event in events:
        assert event["previous_hash"] == previous
        event_hash = event.pop("event_hash")
        canonical = json.dumps(event, sort_keys=True, separators=(",", ":"))
        assert event_hash == hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        previous = event_hash
    assert sensitive_content not in settings.audit_log_path.read_text(encoding="utf-8")
