from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from q_backend.config import Settings
from q_backend.main import create_app
from starlette.websockets import WebSocketDisconnect

TOKEN = "test-session-token-that-is-long-enough"  # noqa: S105 - test fixture only


def test_health_requires_token(tmp_path: Path) -> None:
    settings = Settings(
        environment="testing",
        bind_host="127.0.0.1",
        port=0,
        session_token=TOKEN,
        workspace=tmp_path,
        allowed_origins=("tauri://localhost",),
    )
    with TestClient(create_app(settings)) as client:
        response = client.get("/api/v1/health")
    assert response.status_code == 401
    assert response.json()["error"]["code"] == "permission_denied"


def test_authenticated_health_reports_q_off(tmp_path: Path) -> None:
    settings = Settings(
        environment="testing",
        bind_host="127.0.0.1",
        port=0,
        session_token=TOKEN,
        workspace=tmp_path,
        allowed_origins=("tauri://localhost",),
    )
    with TestClient(create_app(settings)) as client:
        response = client.get(
            "/api/v1/health",
            headers={"Authorization": f"Bearer {TOKEN}"},
        )
    assert response.status_code == 200
    assert response.json()["q_state"] == "OFF"


def test_non_loopback_bind_is_rejected() -> None:
    os.environ["Q_ENV"] = "testing"
    os.environ["Q_SESSION_TOKEN"] = TOKEN
    os.environ["Q_BACKEND_HOST"] = "0.0.0.0"  # noqa: S104 - intentional denial test
    try:
        try:
            Settings.from_environment()
        except Exception as error:
            assert getattr(error, "code", None) == "permission_denied"
        else:
            raise AssertionError("Non-loopback bind was accepted")
    finally:
        os.environ.pop("Q_BACKEND_HOST", None)
        os.environ.pop("Q_SESSION_TOKEN", None)
        os.environ.pop("Q_ENV", None)


def test_event_stream_requires_token_and_publishes_local_snapshot(tmp_path: Path) -> None:
    settings = Settings(
        environment="testing",
        bind_host="127.0.0.1",
        port=0,
        session_token=TOKEN,
        workspace=tmp_path,
        allowed_origins=("tauri://localhost",),
    )
    with TestClient(create_app(settings)) as client:
        with pytest.raises(WebSocketDisconnect) as rejected:
            with client.websocket_connect("/api/v1/events/ws"):
                pass
        assert rejected.value.code == 4401
        with client.websocket_connect(
            "/api/v1/events/ws",
            subprotocols=["q-auth", TOKEN],
        ) as socket:
            event = socket.receive_json()
    assert event["event"] == "system.snapshot"
    assert event["data"]["lifecycle"]["state"] == "OFF"
