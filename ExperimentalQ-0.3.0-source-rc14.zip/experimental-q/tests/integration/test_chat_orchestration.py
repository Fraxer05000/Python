from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path
from typing import cast
from uuid import uuid4

from fastapi import FastAPI
from fastapi.testclient import TestClient
from q_backend.container import AppContainer
from q_backend.models.runtime import (
    InferenceChunk,
    InferenceRequest,
    InferenceResponse,
    RuntimeHealth,
    ToolCall,
)
from q_backend.runtimes.base import ModelRuntimeAdapter


class ReadThenAnswerRuntime:
    def __init__(self, project_id: str) -> None:
        self._project_id = project_id
        self.calls = 0

    async def generate(self, request: InferenceRequest) -> InferenceResponse:
        self.calls += 1
        if self.calls == 1:
            return InferenceResponse(
                request_id=request.request_id,
                content=None,
                tool_calls=[
                    ToolCall(
                        id="read-call",
                        name="q_tool_request",
                        arguments={
                            "request_id": str(uuid4()),
                            "tool": "files.read",
                            "arguments": {"path": "Inputs/question.txt"},
                            "reason": "Leer el archivo solicitado",
                            "project_id": self._project_id,
                        },
                    )
                ],
            )
        assert any(
            message.role == "tool" and "contenido verificado" in (message.content or "")
            for message in request.messages
        )
        return InferenceResponse(
            request_id=request.request_id,
            content="El archivo contiene contenido verificado.",
            finish_reason="stop",
        )

    async def load(self, profile: object) -> None:
        del profile

    async def unload(self) -> None:
        return None

    async def health(self) -> RuntimeHealth:
        raise NotImplementedError

    def stream(self, request: InferenceRequest) -> AsyncIterator[InferenceChunk]:
        del request
        raise NotImplementedError

    async def cancel(self, request_id: str) -> None:
        del request_id

    async def close(self) -> None:
        return None


def test_chat_reads_only_through_registered_tool_manager(client: TestClient) -> None:
    project = client.post("/api/v1/projects", json={"name": "Chat"}).json()
    project_id = str(project["project_id"])
    Path(project["root_path"], "Inputs", "question.txt").write_text(
        "contenido verificado",
        encoding="utf-8",
    )
    app = cast(FastAPI, client.app)
    container = cast(AppContainer, app.state.container)
    runtime = ReadThenAnswerRuntime(project_id)
    container.chat._runtime = cast(ModelRuntimeAdapter, runtime)  # noqa: SLF001
    session = client.post(
        "/api/v1/chat/sessions",
        json={"project_id": project_id, "title": "Lectura"},
    ).json()
    turn = client.post(
        "/api/v1/chat/turn",
        json={
            "session_id": session["session_id"],
            "project_id": project_id,
            "message": "¿Qué contiene question.txt?",
        },
    )
    assert turn.status_code == 200
    body = turn.json()
    assert body["status"] == "completed"
    assert body["actions"][0]["tool"] == "files.read"
    assert body["actions"][0]["audit_id"]
    assert runtime.calls == 2
