from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient
from q_backend.config import Settings


def _invoke(
    client: TestClient,
    project_id: str,
    tool: str,
    arguments: dict[str, object],
) -> dict[str, object]:
    response = client.post(
        "/api/v1/tools/invoke",
        json={
            "request_id": str(uuid4()),
            "tool": tool,
            "arguments": arguments,
            "reason": "Prueba científica reproducible",
            "project_id": project_id,
        },
    )
    assert response.status_code == 200
    body: dict[str, object] = response.json()
    return body


def test_csv_analysis_figure_and_provenance(
    client: TestClient,
    settings: Settings,
) -> None:
    project = client.post("/api/v1/projects", json={"name": "Pipeline"}).json()
    project_id = str(project["project_id"])
    root = Path(project["root_path"])
    source = root / "Inputs" / "measurements.csv"
    source.write_text("time,value\n0,1\n1,3\n2,5\n", encoding="utf-8")

    profile = _invoke(
        client,
        project_id,
        "spreadsheets.profile",
        {"path": "Inputs/measurements.csv", "sample_rows": 3},
    )
    assert profile["status"] == "ok"
    profile_data = profile["data"]
    assert isinstance(profile_data, dict)
    assert profile_data["rows"] == 3
    assert profile["provenance_id"]

    arguments = {
        "operation": "bootstrap_mean_ci",
        "x": [1, 3, 5],
        "seed": 42,
        "resamples": 500,
    }
    first = _invoke(client, project_id, "scientific.analyze", arguments)
    second = _invoke(client, project_id, "scientific.analyze", arguments)
    assert first["data"] == second["data"]

    figure = _invoke(
        client,
        project_id,
        "visualization.create",
        {
            "chart_type": "line",
            "x": [0, 1, 2],
            "y": [1, 3, 5],
            "title": "Serie reproducible",
            "output_path": "Outputs/series.png",
            "dpi": 100,
        },
    )
    assert figure["status"] == "ok"
    figure_data = figure["data"]
    assert isinstance(figure_data, dict)
    output = Path(str(figure_data["path"]))
    assert output.is_file()
    assert figure_data["sha256"] == hashlib.sha256(output.read_bytes()).hexdigest()

    artifacts = client.get(f"/api/v1/artifacts?project_id={project_id}").json()
    assert any(item["path"] == str(output) for item in artifacts)
    with sqlite3.connect(settings.database_path) as database:
        environment_json = database.execute(
            "SELECT environment_json FROM provenance_records WHERE provenance_id = ?",
            (figure["provenance_id"],),
        ).fetchone()[0]
    environment = json.loads(environment_json)
    assert environment["python"]
    assert "numpy" in environment["packages"]
