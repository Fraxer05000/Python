from pathlib import Path

from fastapi.testclient import TestClient


def test_project_crud_creates_isolated_workspace(client: TestClient) -> None:
    created = client.post(
        "/api/v1/projects",
        json={"name": "Ensayo MFC", "description": "Datos experimentales"},
    )
    assert created.status_code == 201
    project = created.json()
    root = Path(project["root_path"])
    assert (root / "Inputs").is_dir()
    assert (root / "Outputs").is_dir()

    listed = client.get("/api/v1/projects")
    assert [item["project_id"] for item in listed.json()] == [project["project_id"]]

    updated = client.patch(
        f"/api/v1/projects/{project['project_id']}",
        json={"name": "Ensayo MFC actualizado"},
    )
    assert updated.json()["name"] == "Ensayo MFC actualizado"

    denied = client.request(
        "DELETE",
        f"/api/v1/projects/{project['project_id']}",
        json={"remove_project_files": False, "explicit_user_confirmation": False},
    )
    assert denied.status_code == 409

    deleted = client.request(
        "DELETE",
        f"/api/v1/projects/{project['project_id']}",
        json={"remove_project_files": False, "explicit_user_confirmation": True},
    )
    assert deleted.status_code == 204
    assert root.exists()
