from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from q_backend.config import Settings
from q_backend.main import create_app

TOKEN = "test-session-token-that-is-long-enough"  # noqa: S105 - test fixture only


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(
        environment="testing",
        bind_host="127.0.0.1",
        port=0,
        session_token=TOKEN,
        workspace=tmp_path,
        allowed_origins=("tauri://localhost",),
    )


@pytest.fixture
def client(settings: Settings) -> Iterator[TestClient]:
    with TestClient(create_app(settings)) as test_client:
        test_client.headers["Authorization"] = f"Bearer {TOKEN}"
        yield test_client
