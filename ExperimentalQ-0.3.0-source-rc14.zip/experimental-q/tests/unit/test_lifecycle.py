from q_backend.models.lifecycle import QState


def test_state_set_is_exact_architecture_contract() -> None:
    assert {state.value for state in QState} == {
        "OFF",
        "STARTING",
        "ACTIVE",
        "SLEEPING",
        "SLEEP",
        "STOPPING",
        "ERROR",
    }
