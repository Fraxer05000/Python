from __future__ import annotations

import json
from pathlib import Path
from typing import cast

import pytest
from q_backend.controllers.audio import AudioController
from q_backend.models.runtime import WorkerResult
from q_backend.supervisor.client import SupervisorClient


class RecordingSupervisor:
    def __init__(self) -> None:
        self.audio_path: Path | None = None

    async def run_worker(
        self,
        kind: str,
        payload: str,
        working_directory: str,
        timeout_seconds: int,
    ) -> WorkerResult:
        assert kind == "audio"
        assert timeout_seconds == 120
        body = json.loads(payload)
        self.audio_path = Path(body["audio_path"])
        assert self.audio_path.is_file()
        assert self.audio_path.parent == Path(working_directory)
        return WorkerResult(
            exit_code=0,
            stdout='{"status":"ok","text":"hola Q","duration_ms":12}',
        )


@pytest.mark.asyncio
async def test_microphone_audio_is_deleted_after_local_transcription(tmp_path: Path) -> None:
    supervisor = RecordingSupervisor()
    controller = AudioController(cast(SupervisorClient, supervisor), tmp_path)
    wav = b"RIFF" + bytes(4) + b"WAVE" + bytes(32)
    response = await controller.transcribe(wav, "es")
    assert response.text == "hola Q"
    assert supervisor.audio_path is not None
    assert not supervisor.audio_path.exists()
