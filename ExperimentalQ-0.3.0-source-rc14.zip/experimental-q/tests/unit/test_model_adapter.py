from __future__ import annotations

from typing import cast

import httpx
import pytest
from q_backend.models.lifecycle import LifecycleSnapshot, QState, ResourceSnapshot
from q_backend.models.runtime import InferenceRequest, RuntimeConnection
from q_backend.runtimes.llama_cpp import LlamaCppAdapter
from q_backend.supervisor.client import SupervisorClient


class ActiveSupervisor:
    async def state(self) -> LifecycleSnapshot:
        return LifecycleSnapshot(state=QState.ACTIVE)

    async def resources(self) -> ResourceSnapshot:
        raise NotImplementedError

    async def runtime_connection(self) -> RuntimeConnection:
        return RuntimeConnection(host="127.0.0.1", port=19991, api_key="ephemeral")

    async def start(self, profile: object) -> LifecycleSnapshot:
        del profile
        return LifecycleSnapshot(state=QState.ACTIVE)

    async def sleep(self) -> LifecycleSnapshot:
        return LifecycleSnapshot(state=QState.SLEEP)

    async def stop(self) -> LifecycleSnapshot:
        return LifecycleSnapshot(state=QState.OFF)


@pytest.mark.asyncio
async def test_llama_adapter_parses_structured_tool_call() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.host == "127.0.0.1"
        assert request.headers["authorization"] == "Bearer ephemeral"
        return httpx.Response(
            200,
            json={
                "choices": [
                    {
                        "message": {
                            "content": None,
                            "tool_calls": [
                                {
                                    "id": "call-1",
                                    "function": {
                                        "name": "q_tool_request",
                                        "arguments": '{"request_id":"x"}',
                                    },
                                }
                            ],
                        },
                        "finish_reason": "tool_calls",
                    }
                ]
            },
        )

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    adapter = LlamaCppAdapter(cast(SupervisorClient, ActiveSupervisor()), client=client)
    response = await adapter.generate(InferenceRequest(request_id="turn", messages=[]))
    assert response.tool_calls[0].name == "q_tool_request"
    assert response.tool_calls[0].arguments == {"request_id": "x"}
    await client.aclose()
