# Coding Standards

## Python
- Python >=3.12
- type hints on public functions
- Pydantic models for wire data
- dataclasses/internal models where appropriate
- async only for I/O/concurrency boundaries
- no global mutable service singleton without lifecycle owner
- dependency injection for controllers/services
- pathlib for paths
- explicit exceptions derived from QError

## Rust
- stable Rust
- `Result<T, E>`
- no `unwrap()` in production paths unless invariant is formally justified
- structured tracing
- process handles owned by supervisor
- platform-specific Windows code behind modules

## TypeScript
- strict mode
- discriminated unions for state
- generated types from API/schema when practical
- no direct filesystem Node APIs in frontend
- all privileged operations through Tauri commands/backend

## API
- `/api/v1`
- snake_case JSON
- ISO 8601 UTC timestamps
- request correlation id
- structured error object:
```json
{
  "code": "permission_denied",
  "message": "User-friendly message",
  "details": {},
  "correlation_id": "..."
}
```

## Logs
- structured
- redact secrets
- avoid full document contents by default
- development stack traces separated from user-facing errors

## Git
- conventional commits recommended
- one architectural concern per commit when feasible
