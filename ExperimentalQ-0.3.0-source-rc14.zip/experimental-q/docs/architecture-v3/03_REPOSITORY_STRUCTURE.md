# Canonical Repository Structure

```text
experimental-q/
├─ README.md
├─ LICENSE
├─ pyproject.toml
├─ package.json
├─ Cargo.toml
├─ pnpm-workspace.yaml
├─ .editorconfig
├─ .gitignore
├─ .github/
│  └─ workflows/
├─ apps/
│  ├─ desktop/
│  │  ├─ src/                    # React/TypeScript
│  │  └─ src-tauri/              # Rust/Tauri
│  └─ backend/
│     └─ q_backend/
│        ├─ main.py
│        ├─ api/
│        │  └─ v1/
│        ├─ orchestrator/
│        ├─ tools/
│        ├─ policy/
│        ├─ permissions/
│        ├─ controllers/
│        ├─ memory/
│        ├─ models/
│        ├─ storage/
│        ├─ audit/
│        ├─ provenance/
│        └─ events/
├─ packages/
│  ├─ protocol/                  # JSON schemas / shared TS types
│  ├─ ui/
│  └─ config/
├─ runtimes/
│  ├─ model/
│  │  ├─ adapters/
│  │  └─ llama_cpp/
│  ├─ python_worker/
│  └─ r_worker/
├─ schemas/
│  ├─ tool_request.schema.json
│  ├─ tool_result.schema.json
│  ├─ audit_event.schema.json
│  └─ provenance.schema.json
├─ config/
│  ├─ default.yaml
│  └─ tool_registry.json
├─ tests/
│  ├─ unit/
│  ├─ integration/
│  ├─ security/
│  └─ e2e/
├─ scripts/
├─ docs/
└─ installer/
```

## Rules
- UI cannot import backend internals.
- Controllers cannot import UI.
- Orchestrator calls tools through `ToolManager`, never controllers directly.
- Controllers may use shared storage/services.
- Model adapters implement a common interface.
- Tool schemas are versioned.
- All API endpoints live under `/api/v1`.
