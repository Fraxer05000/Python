# Module Contracts

## 1. Supervisor
Interface:
- `start_backend()`
- `stop_backend()`
- `start_model(profile_id)`
- `sleep_model()`
- `stop_model()`
- `restart_model()`
- `get_process_health()`
- `get_resource_snapshot()`

Must guarantee cleanup of child processes.

## 2. ModelRuntimeAdapter
```python
class ModelRuntimeAdapter(Protocol):
    async def load(self, profile: ModelProfile) -> None: ...
    async def unload(self) -> None: ...
    async def health(self) -> RuntimeHealth: ...
    async def generate(self, request: InferenceRequest) -> InferenceResponse: ...
    async def stream(self, request: InferenceRequest) -> AsyncIterator[InferenceChunk]: ...
```

## 3. ToolManager
Responsibilities:
- resolve tool;
- validate request;
- evaluate policy;
- obtain confirmation;
- invoke controller;
- normalize result;
- emit audit/provenance.

Never expose raw controller objects to Q.

## 4. PolicyEngine
Input:
- user/session;
- project;
- tool;
- normalized arguments;
- application mode;
- persistent grants.

Output:
- `ALLOW`
- `DENY`
- `CONFIRM`

plus reason code.

## 5. PermissionManager
Responsibilities:
- issue one-time confirmation challenge;
- persist optional scoped grants;
- revoke grants;
- verify challenge response.

Persistent grants must have:
- scope;
- resource;
- expiration or explicit permanence;
- user-created timestamp.

## 6. FileController
Allowed methods:
- list
- stat
- read_text
- read_bytes
- write_new
- update
- copy
- move
- rename
- delete
- mkdir
- unzip
- zip

All paths:
1. normalize;
2. resolve symlinks;
3. verify authorized root;
4. evaluate operation-specific permission.

## 7. DocumentController
Supported first milestone:
- DOCX create/read/edit;
- Markdown/TXT;
- LaTeX text generation;
- export metadata.

PDF conversion may use a dedicated renderer but must not rely on interactive Office automation.

## 8. SpreadsheetController
Must expose data operations, not arbitrary Python strings:
- workbook_info
- read_range
- write_range
- add_sheet
- rename_sheet
- apply_format
- formula
- export_csv
- import_csv
- profile_dataset

## 9. PythonController
Two modes:
- structured scientific operations;
- advanced sandbox code execution.

Advanced code execution is P2 and must be explicitly enabled.

Default sandbox:
- isolated working directory;
- execution timeout;
- environment allowlist;
- no network unless separately granted;
- no parent filesystem traversal.

## 10. SQLController
- SQLite project DB
- DuckDB analytical DB
- external DB connections only via configured connector
- read-only by default
- mutation requires elevated permission

## 11. WebController
Disabled in Local Only mode.
Must:
- validate scheme;
- block localhost/private network by default;
- enforce domain policy;
- cap response size;
- sanitize downloaded filenames;
- scan download path policy.

## 12. MemoryController
APIs:
- session.put/get/clear
- user.preference.put/get/delete
- project.memory.put/search/delete
- knowledge.index/search/remove

Sensitive facts require explicit user request before persistent save.

## 13. AuditController
Append-only semantics at application level.
Each sensitive event includes:
- actor;
- action;
- resource;
- policy decision;
- result;
- timestamp;
- correlation id.

## 14. ProvenanceController
Scientific artifacts record:
- source dataset(s);
- source file hashes;
- transformation/tool;
- code/script hash if applicable;
- parameters;
- environment;
- output hash;
- timestamp.
