# Installer and Application Lifecycle

## Installer
Target: one-click Windows installer with guided first launch.

## Installer responsibilities
- verify supported Windows version;
- check free disk space;
- install desktop application;
- install backend sidecar;
- install model runtime sidecar;
- create default workspace;
- create config;
- optionally configure model path;
- never enable startup automatically.

## First run
Wizard:
1. Choose workspace root.
2. Select Local Only / Hybrid / Connected; default Local Only.
3. Detect available RAM/CPU.
4. Add or select Q model file.
5. Benchmark optional runtime parameters.
6. Save model profile.
7. Start application with Q OFF.

## Application launch
Default:
- desktop starts;
- backend starts lightweight;
- Q model remains OFF until user starts it.

## Stop Q
- cancel inference;
- reject new inference;
- terminate model;
- terminate scientific workers;
- release model mmap;
- cleanup temp execution dirs where policy permits;
- publish resource snapshot.

## Exit application
- stop Q;
- stop backend;
- terminate children;
- flush SQLite;
- close audit stream.

## Uninstall
Offer user choice:
- remove application only;
- optionally remove cache;
- do not delete projects/datasets by default.
