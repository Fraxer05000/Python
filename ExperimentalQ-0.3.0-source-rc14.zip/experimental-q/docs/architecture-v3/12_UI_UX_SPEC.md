# UI/UX Specification

## Visual direction
Scientific/technological.
Use:
- deep blue;
- cyan/ice blue accents;
- white;
- metallic silver;
- graphite.

Avoid pastel visual language.

## Main navigation
- Chat
- Projects
- Files
- Data
- Knowledge
- Notebook
- Models
- Tools
- Memory
- Settings

## Global status bar
Always show:
- Q state: ACTIVE / SLEEP / OFF / ERROR
- model profile
- Q-owned RAM
- CPU
- active mode: Local Only / Hybrid / Connected
- network enabled/disabled

## Critical controls
Top-level controls:
- Start Q
- Sleep Q
- Stop Q

Stop Q must be visually distinct and must trigger real runtime unload.

## Permission dialog
Display:
- exact action;
- controller/tool;
- target resource;
- why Q requested it;
- whether action is destructive;
- grant scope options where allowed.

Buttons:
- Cancel
- Allow once
- Allow for project/folder/domain (only if policy permits)

## Artifacts panel
Show generated outputs:
- filename;
- type;
- source operation;
- timestamp;
- open;
- reveal in folder;
- provenance.

## Data viewer
- virtualized table;
- sort/filter;
- missing-value indicators;
- schema/profile view;
- export;
- no silent mutation.

## Accessibility
- keyboard navigation;
- high contrast compliance;
- reduced motion setting;
- clear focus states.

## Command palette
`Ctrl+K`
Commands:
- New Project
- Open Dataset
- Open Knowledge Base
- Start Q
- Sleep Q
- Stop Q
- Run Analysis
- Open Notebook
- Settings
