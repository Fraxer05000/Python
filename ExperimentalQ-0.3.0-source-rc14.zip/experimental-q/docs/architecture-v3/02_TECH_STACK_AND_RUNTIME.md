# Technology Stack and Runtime Decisions

## 1. Desktop
**Tauri 2 + Rust**

Reasons:
- lower idle RAM than Electron;
- native Windows packaging;
- secure command surface;
- strong lifecycle control for sidecars;
- suited to model start/stop supervision.

## 2. Frontend
- React 19-compatible architecture
- TypeScript strict
- Vite
- TanStack Query for backend state
- Zustand for local UI state
- Monaco Editor for code/notebook views
- AG Grid Community or TanStack Table for data viewer
- ECharts or Plotly only for interactive UI previews; scientific exported plots come from Python/R

## 3. Backend
- Python 3.12
- FastAPI
- Uvicorn
- Pydantic v2
- SQLAlchemy 2.x for metadata
- Alembic migrations
- structlog or stdlib structured JSON logging

## 4. Storage
### SQLite
Use for:
- projects;
- sessions;
- settings;
- tool metadata;
- permission grants;
- audit index;
- provenance metadata;
- connector configuration references.

### DuckDB
Use for:
- analytical queries;
- CSV/Parquet exploration;
- temporary relational transformations.

### Qdrant local mode
Use behind `VectorStore` interface for:
- embeddings;
- semantic document retrieval;
- project knowledge bases.

Do not couple business logic directly to Qdrant.

## 5. Model runtime
Initial adapter: **llama.cpp server**.

The interface must permit future adapters:
- Ollama
- ONNX Runtime
- Transformers
- remote provider
- custom Q runtime

The app must not assume Q uses a fixed quantization or context length.

## 6. Scientific Python baseline
- numpy
- pandas
- scipy
- statsmodels
- scikit-learn
- matplotlib
- openpyxl
- sympy
- networkx
- pyarrow
- duckdb
- joblib

Optional domain bundles should be installable later.

## 7. R
Optional and disabled until configured.
The R controller must invoke an isolated worker with:
- JSON request stdin or local socket;
- JSON response stdout/socket;
- no raw shell commands from Q.

## 8. Security
- OS credential vault: Windows Credential Manager via Rust/native adapter
- path normalization before file access
- allowlisted workspace roots
- explicit confirmation tokens
- no arbitrary `eval`
- no model-authored shell strings

## 9. Packaging
- Tauri bundler
- backend shipped as a sidecar executable (PyInstaller or Nuitka; benchmark before final selection)
- llama.cpp runtime shipped as sidecar
- default model optionally distributed separately to keep installer size manageable
- installer creates workspace but does not configure autostart

## 10. Configuration precedence
1. hard security invariants;
2. `config/default.yaml`;
3. machine settings;
4. user settings;
5. project settings;
6. runtime temporary overrides.

A lower level cannot disable a hard invariant.
