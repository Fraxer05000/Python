# Model Runtime Specification

## 1. Adapter pattern
The application must never call llama.cpp-specific code outside the runtime adapter.

## 2. Model profile
A profile contains:
- display name;
- runtime type;
- model file path;
- context length;
- thread count;
- batch size;
- GPU layers;
- temperature defaults;
- tool calling capability flag;
- vision capability flag.

## 3. Lifecycle state machine
```text
OFF -> STARTING -> ACTIVE
ACTIVE -> SLEEPING -> SLEEP
SLEEP -> STARTING -> ACTIVE
ACTIVE -> STOPPING -> OFF
SLEEP -> STOPPING -> OFF
ANY -> ERROR
ERROR -> STOPPING -> OFF
```

## 4. ACTIVE
- model process exists;
- health probe passes;
- inference endpoint accepts requests.

## 5. SLEEP
- model process terminated/unloaded;
- desktop may stay open;
- backend may stay open;
- model memory mapping released;
- no model inference accepted.

## 6. OFF
- backend workers shut down;
- model runtime shut down;
- temporary execution workers shut down;
- active jobs cancelled with explicit status.

## 7. Resource accounting
Supervisor exposes:
- Q-owned RAM;
- Q-owned CPU;
- model process RAM;
- backend RAM;
- worker RAM;
- disk cache size.

Do not claim system-wide RAM was freed; report Q process values.

## 8. Cancellation
Streaming inference requires cancellation token propagated:
UI -> backend -> runtime adapter.

## 9. Context
The runtime receives already-built context. It does not retrieve memory or files directly.
