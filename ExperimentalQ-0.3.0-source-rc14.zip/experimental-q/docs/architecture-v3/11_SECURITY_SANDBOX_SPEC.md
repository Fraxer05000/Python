# Security and Sandbox Specification

## Threat model
Treat model-generated tool requests as untrusted input.

## Filesystem
- canonicalize path;
- reject traversal;
- resolve symlinks;
- verify allowed roots;
- prevent device paths and UNC paths unless explicitly configured;
- prevent writes to protected Windows locations.

## Python sandbox
Milestone 1 may use process isolation rather than full virtualization, but must implement:
- dedicated working directory;
- sanitized environment;
- timeout;
- stdout/stderr capture;
- process tree termination on cancel;
- file root policy;
- network disabled at controller level where feasible.

For high-assurance deployment, leave an interface for Windows Sandbox/containerized execution.

## Network
- default deny in Local Only;
- HTTPS only initially;
- DNS resolution followed by IP policy check;
- block loopback/link-local/private ranges by default;
- cap size and timeout;
- do not automatically execute downloaded content.

## Credentials
- stored in Windows Credential Manager;
- backend receives credential reference;
- controller resolves secret only at call time;
- redact secret values from logs;
- never include secrets in Q prompts.

## Audit
Audit:
- permission confirmations;
- destructive files operations;
- package installation;
- arbitrary code execution;
- external network calls;
- connector writes;
- git commit/push;
- memory persistence;
- model lifecycle.

## Update mechanism
Do not implement silent self-update in first release.
Future updater must use signed packages.
