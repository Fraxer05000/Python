# Testing and Acceptance Criteria

## Test layers
- Rust unit tests
- Python unit tests
- API integration tests
- controller security tests
- frontend component tests
- Playwright end-to-end tests
- packaging smoke tests

## Mandatory security tests
1. Model attempts `../../Windows/System32` -> denied.
2. Symlink/junction escapes workspace -> denied.
3. Model requests raw shell command -> schema/tool not found.
4. Local Only web request -> `network_disabled`.
5. Delete file without confirmation -> not executed.
6. Secret value appears in logs -> test fails.
7. Unauthorized local backend request without token -> 401.
8. Local backend binds non-loopback interface -> test fails.

## Lifecycle tests
1. Launch app -> Q is OFF.
2. Start Q -> ACTIVE.
3. Sleep Q -> model process gone; state SLEEP.
4. Start from SLEEP -> ACTIVE.
5. Stop Q -> model and workers stopped.
6. Exit -> no orphan Q processes.
7. Windows restart -> Q does not auto-launch unless user later explicitly enables a future optional feature.

## Files tests
- read within workspace;
- write new;
- overwrite confirmation;
- outside workspace confirmation;
- destructive batch confirmation.

## Scientific reproducibility tests
- deterministic seeded analysis when algorithm supports it;
- provenance includes source file hash;
- exported artifact hash recorded;
- environment versions captured.

## Performance targets for initial hardware
These are engineering targets, not guarantees:
- desktop idle with Q OFF: minimize to practical level;
- backend startup: responsive enough for interactive desktop use;
- Q SLEEP: model process RAM approximately zero;
- large table viewer uses virtualization;
- tool operations stream progress for tasks >2 s.

## Release gate
No Alpha build if:
- raw shell path exists;
- policy layer can be bypassed;
- model fails to unload;
- secret storage is plaintext;
- Local Only still emits external network traffic.
