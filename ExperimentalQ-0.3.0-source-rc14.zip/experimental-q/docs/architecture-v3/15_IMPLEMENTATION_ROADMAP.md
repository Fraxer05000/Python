# Implementation Roadmap

Each milestone must compile, run, and pass its tests before the next milestone.

## M0 — Repository bootstrap
Deliver:
- monorepo;
- Tauri desktop;
- React shell;
- FastAPI sidecar;
- authenticated localhost health endpoint;
- CI.

Acceptance:
- desktop launches;
- backend health visible;
- no model.

## M1 — Supervisor and lifecycle
Deliver:
- Rust process manager;
- sidecar start/stop;
- event bus;
- Q state machine;
- resource snapshot.

Acceptance:
- child cleanup guaranteed;
- state persisted only where appropriate.

## M2 — Model runtime adapter
Deliver:
- `ModelRuntimeAdapter`;
- llama.cpp adapter;
- model profiles;
- start/stream/cancel/sleep/stop.

Acceptance:
- Q reaches ACTIVE;
- streaming works;
- sleep unloads model.

## M3 — Tool protocol core
Deliver:
- ToolRequest/ToolResult models;
- Tool Registry;
- schema validation;
- Tool Manager;
- typed errors.

Acceptance:
- fake test controller invoked through Tool Manager only.

## M4 — Policy and permissions
Deliver:
- PolicyEngine;
- PermissionManager;
- confirmation UI;
- persistent scoped grants;
- audit.

Acceptance:
- destructive action cannot bypass confirmation.

## M5 — Projects and workspace
Deliver:
- project CRUD;
- workspace roots;
- path policy;
- FileController.

Acceptance:
- traversal and junction tests pass.

## M6 — Chat orchestration
Deliver:
- sessions;
- context builder;
- Q inference;
- structured tool calling loop;
- tool result return to Q.

Acceptance:
- user asks to read a file; Q invokes registered tool and answers.

## M7 — Scientific data core
Deliver:
- SpreadsheetController;
- DuckDB;
- structured Python scientific operations;
- data profiler;
- VisualizationController.

Acceptance:
- CSV/XLSX -> profile -> analysis -> figure -> provenance.

## M8 — Documents/PDF
Deliver:
- DOCX/Markdown controller;
- PDF read/create controller;
- artifact panel.

## M9 — Memory and knowledge
Deliver:
- session memory;
- project memory;
- user preference memory;
- Qdrant adapter;
- ingestion and retrieval.

## M10 — Research/web
Deliver:
- Local Only enforcement;
- WebController;
- ResearchController;
- domain policy;
- downloads.

## M11 — Advanced runtimes
Deliver:
- arbitrary Python sandbox;
- optional R worker;
- SQL external connectors;
- packages controller.

## M12 — Git/connectors
Deliver:
- Git controller;
- credential references;
- selected connectors.

## M13 — Notebook
Deliver:
- Q Notebook;
- prompt/code/markdown/SQL/R cells;
- artifact integration.

## M14 — Installer
Deliver:
- signed-capable packaging layout;
- one-click installer;
- first-run wizard;
- uninstall behavior.

## M15 — Hardening
Deliver:
- security audit;
- performance profiling;
- crash recovery;
- accessibility;
- migration tests.

## Rule for GPT-5.6 Sol
Implement one milestone at a time. Do not jump to later milestones unless a minimal interface stub is required by a current dependency.
