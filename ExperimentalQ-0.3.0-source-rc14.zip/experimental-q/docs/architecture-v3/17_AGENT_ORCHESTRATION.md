# Agent and Orchestration Specification

## Initial release
Do not implement autonomous multi-agent behavior before the single-orchestrator tool loop is stable.

## Agent abstraction
Future agents are role profiles over the same:
- model runtime;
- context builder;
- tool manager;
- policy engine.

No agent receives broader permissions automatically.

## Planned agents
- Research Agent
- Statistics Agent
- Coding Agent
- Literature Agent
- Document Agent
- Data Agent
- Reviewer Agent

## Delegation object
```json
{
  "task_id": "uuid",
  "agent_role": "statistics",
  "objective": "Validate the model assumptions",
  "inputs": ["artifact:dataset_clean"],
  "allowed_tools": ["scientific.analyze", "python.run_structured"],
  "budget": {
    "max_tool_calls": 12,
    "max_iterations": 6
  }
}
```

## Verification
Agent outputs are proposals.
The parent orchestrator:
1. validates tool/provenance output;
2. checks contradictions;
3. optionally invokes Reviewer Agent;
4. constructs user response.

## Safety
Agents never delegate permissions.
A child agent cannot call a tool excluded by the delegation object.
