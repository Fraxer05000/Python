# Memory and RAG Specification

## Memory classes
1. Session memory — ephemeral.
2. Project memory — persistent within a project.
3. User preferences — persistent only for useful non-sensitive preferences or explicit saves.
4. Knowledge base — indexed documents.
5. Retrieval cache — disposable.

## Persistence rule
Persistent user memory cannot be silently inferred and stored.

## Project memory record
Required fields:
- id;
- project_id;
- content;
- source;
- created_at;
- updated_at;
- sensitivity flag;
- embedding reference;
- deletion state.

## RAG ingestion
```text
File
 -> parser
 -> canonical text
 -> structural chunks
 -> metadata
 -> embedding
 -> vector store
 -> retrieval
 -> reranking
 -> context builder
```

## Chunking
Prefer structure-aware chunking:
- headings;
- paragraphs;
- table blocks;
- figure captions;
- code blocks.

Do not chunk solely by fixed token count when structural information exists.

## Retrieval
Initial strategy:
- lexical metadata filters;
- vector search;
- optional reranking;
- maximum context budget;
- source attribution.

## Isolation
Queries default to current project collection.
Cross-project retrieval requires explicit user scope.

## Deletion
Deleting source from knowledge base must remove:
- index metadata;
- vector entries;
- cached chunks.
Audit the action.
