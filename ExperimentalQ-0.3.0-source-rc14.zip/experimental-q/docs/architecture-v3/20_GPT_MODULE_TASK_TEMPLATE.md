# GPT-5.6 Sol Module Task Template

Use this template for every coding milestone.

## Task
Implement: `<MODULE_OR_MILESTONE>`

## Required specification files
- `<list exact Architecture 3.0 files>`

## Scope
Implement only:
- ...
- ...

Do not implement:
- ...
- ...

## Required public interfaces
```text
...
```

## Required files
```text
...
```

## Required tests
1. ...
2. ...
3. ...

## Security requirements
- All resource actions go through Tool Manager.
- Enforce permission policy.
- No raw shell from model.
- No plaintext secrets.
- No external network unless explicitly in scope.

## Acceptance criteria
- ...
- ...
- ...

## Required response
Return:
1. files created/changed;
2. complete code;
3. tests;
4. run commands;
5. acceptance results;
6. unresolved limitations.

Do not redesign architecture.
