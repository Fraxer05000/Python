# Experimental Q 0.3.0 — implementation file manifest

This is the exact material file set created or modified for the M1–M14 source
implementation. Empty Python package markers and generated build output are not
listed. Architecture files under `docs/architecture-v3/` are preserved inputs,
not implementation changes.

## Workspace, build, and release

```text
.github/workflows/ci.yml
.github/workflows/release-windows.yml
.editorconfig
.gitignore
Cargo.lock
Cargo.toml
LICENSE
README.md
SECURITY.md
package.json
pnpm-lock.yaml
pnpm-workspace.yaml
pyproject.toml
scripts/build_windows.ps1
scripts/prepare_windows_dependencies.ps1
scripts/smoke_test_windows_installers.ps1
scripts/verify_packaging.py
THIRD_PARTY_NOTICES.md
installer/README.md
installer/licenses/Apache-2.0.txt
installer/licenses/MIT-ggml-runtimes.txt
installer/nsis/installer-hooks.nsh
installer/runtime-manifest.example.json
installer/runtime-sources.lock.json
```

## Rust/Tauri supervisor and desktop packaging

```text
apps/desktop/package.json
apps/desktop/index.html
apps/desktop/tsconfig.json
apps/desktop/tsconfig.node.json
apps/desktop/vite.config.ts
apps/desktop/public/experimental-q-mark.svg
apps/desktop/src-tauri/Cargo.toml
apps/desktop/src-tauri/build.rs
apps/desktop/src-tauri/capabilities/default.json
apps/desktop/src-tauri/icons/icon.ico
apps/desktop/src-tauri/icons/icon.png
apps/desktop/src-tauri/resources/README.txt
apps/desktop/src-tauri/src/app_config.rs
apps/desktop/src-tauri/src/control_server.rs
apps/desktop/src-tauri/src/lib.rs
apps/desktop/src-tauri/src/main.rs
apps/desktop/src-tauri/src/managed_process.rs
apps/desktop/src-tauri/src/supervisor.rs
apps/desktop/src-tauri/tauri.conf.json
```

## React/TypeScript interface

```text
apps/desktop/src/App.test.tsx
apps/desktop/src/App.tsx
apps/desktop/src/api.ts
apps/desktop/src/main.tsx
apps/desktop/src/microphone.ts
apps/desktop/src/styles.css
apps/desktop/src/test/setup.ts
apps/desktop/src/vite-env.d.ts
```

## FastAPI composition, API, storage, and domain services

```text
apps/backend/q_backend/api/v1/events.py
apps/backend/q_backend/api/v1/router.py
apps/backend/q_backend/artifacts/service.py
apps/backend/q_backend/audit/service.py
apps/backend/q_backend/config.py
apps/backend/q_backend/connectors/service.py
apps/backend/q_backend/container.py
apps/backend/q_backend/errors.py
apps/backend/q_backend/logging_config.py
apps/backend/q_backend/main.py
apps/backend/q_backend/memory/service.py
apps/backend/q_backend/memory/vector_store.py
apps/backend/q_backend/notebook/service.py
apps/backend/q_backend/orchestrator/context.py
apps/backend/q_backend/orchestrator/service.py
apps/backend/q_backend/permissions/manager.py
apps/backend/q_backend/policy/engine.py
apps/backend/q_backend/projects/service.py
apps/backend/q_backend/provenance/service.py
apps/backend/q_backend/runtimes/base.py
apps/backend/q_backend/runtimes/llama_cpp.py
apps/backend/q_backend/services/model.py
apps/backend/q_backend/storage/database.py
apps/backend/q_backend/supervisor/client.py
apps/backend/q_backend/tools/manager.py
apps/backend/q_backend/tools/registry.py
```

## Typed backend models

```text
apps/backend/q_backend/models/artifact.py
apps/backend/q_backend/models/audio.py
apps/backend/q_backend/models/chat.py
apps/backend/q_backend/models/connector.py
apps/backend/q_backend/models/lifecycle.py
apps/backend/q_backend/models/memory.py
apps/backend/q_backend/models/notebook.py
apps/backend/q_backend/models/permissions.py
apps/backend/q_backend/models/project.py
apps/backend/q_backend/models/protocol.py
apps/backend/q_backend/models/runtime.py
apps/backend/q_backend/models/tool.py
```

## Registered controllers

```text
apps/backend/q_backend/controllers/audio.py
apps/backend/q_backend/controllers/base.py
apps/backend/q_backend/controllers/document.py
apps/backend/q_backend/controllers/file.py
apps/backend/q_backend/controllers/git.py
apps/backend/q_backend/controllers/memory.py
apps/backend/q_backend/controllers/package.py
apps/backend/q_backend/controllers/path_policy.py
apps/backend/q_backend/controllers/pdf.py
apps/backend/q_backend/controllers/python_sandbox.py
apps/backend/q_backend/controllers/python_scientific.py
apps/backend/q_backend/controllers/r.py
apps/backend/q_backend/controllers/research.py
apps/backend/q_backend/controllers/scientific.py
apps/backend/q_backend/controllers/spreadsheet.py
apps/backend/q_backend/controllers/sql.py
apps/backend/q_backend/controllers/system_resource.py
apps/backend/q_backend/controllers/visualization.py
apps/backend/q_backend/controllers/web.py
```

## Fixed workers, contracts, and configuration

```text
runtimes/audio_worker/main.py
runtimes/package_worker/main.py
runtimes/python_worker/main.py
runtimes/r_worker/worker.R
runtimes/sql_worker/main.py
config/default.yaml
config/model_profiles.example.json
config/package_allowlist.json
config/permission_policy.yaml
config/personal_context.seed.json
config/tool_registry.json
schemas/audit_event.schema.json
schemas/provenance.schema.json
schemas/tool_request.schema.json
schemas/tool_result.schema.json
```

## Tests and delivery reports

```text
tests/conftest.py
tests/integration/test_audit_chain.py
tests/integration/test_chat_orchestration.py
tests/integration/test_health.py
tests/integration/test_memory_notebook.py
tests/integration/test_projects.py
tests/integration/test_scientific_pipeline.py
tests/packaging/test_windows_layout.py
tests/packaging/test_runtime_lock.py
tests/security/test_architecture_contracts.py
tests/security/test_filesystem_boundaries.py
tests/security/test_policy_and_secrets.py
tests/security/test_workers.py
tests/unit/test_audio_controller.py
tests/unit/test_lifecycle.py
tests/unit/test_model_adapter.py
docs/COMPATIBILITY_REPORT.md
docs/IMPLEMENTATION_MANIFEST.md
docs/M0_ACCEPTANCE_REPORT.md
docs/M1_M14_ACCEPTANCE_REPORT.md
```
