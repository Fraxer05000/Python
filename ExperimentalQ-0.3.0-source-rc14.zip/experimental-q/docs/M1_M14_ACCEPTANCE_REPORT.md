# M1–M14 implementation report

## Milestone

Architecture 3.0 milestones M1 through M14, version 0.3.0.

## Implementation

- M1: Rust supervisor, authenticated loopback control plane, exact lifecycle,
  child cleanup, worker bounds, event snapshots, and Q-owned resource metrics.
- M2: replaceable runtime protocol and llama.cpp adapter with profiles,
  load/generate/stream/cancel/sleep/stop.
- M3: strict `ToolRequest`/`ToolResult`, canonical model function,
  machine-readable registry, JSON Schema validation, and typed failures.
- M4: policy engine, one-use confirmation secrets stored only as hashes,
  server-derived scoped grants, revocation, permission UI, chained audit, and
  provenance.
- M5: project CRUD, authorized roots, path containment, protected-root/UNC,
  traversal and symlink/junction defenses, and bounded file actions.
- M6: persistent sessions and messages, context builder, local memory retrieval,
  single-action tool loop, confirmation continuation, and final answer.
- M7: spreadsheet profiling/editing, structured deterministic science, DuckDB,
  figures, environment/hash provenance, and artifact tracking.
- M8: DOCX/Markdown/TXT/LaTeX and PDF read/create controllers.
- M9: session/project/user/knowledge memory with local Qdrant and explicit,
  non-sensitive personal preference seed.
- M10: mode-gated HTTPS search/fetch/research with domain grants, SSRF controls,
  bounded responses, redirect validation, and safe downloads.
- M11: fixed Rust-owned Python, SQL, package, audio and optional R workers; no
  model-defined executable or command line.
- M12: Dulwich Git controller, HTTPS connector metadata, native opaque
  credential references, and no secret exposure to Q.
- M13: persistent prompt/Markdown/Python/SQL/R cells; permission continuations
  execute once and persist the typed output.
- M14: local microphone pipeline, bundled hash-pinned Q and Whisper models,
  first-run hardware/profile wizard, PyInstaller sidecars, NSIS/MSI Tauri
  layout, offline WebView2, uninstall safety, runtime hash manifests, signing
  hook, native inference smoke tests, and Windows install/uninstall workflow.

## Tests

The repository contains Rust unit tests, Python unit/integration/security tests,
a frontend component test, and packaging smoke tests. See
`COMPATIBILITY_REPORT.md` for the latest executed matrix and the Windows-only
acceptance gates that remain.

## Known limitations

- The bundled 1.5B Q4 model favors broad CPU/RAM compatibility and a manageable
  installer size; it is not equivalent in reasoning quality to a large model.
- Authenticode remains unavailable unless the release repository supplies a
  real code-signing PFX through protected GitHub secrets.
- Physical microphone capture and a multi-device Windows 10/11 hardware matrix
  remain separate from the deterministic WAV transcription and installer smoke
  gates executed by the release workflow.
- R support is optional and depends on an external R installation.
- M15 security audit, profiling, crash recovery, accessibility, and migrations
  are intentionally not claimed as part of M1–M14.

## Next dependency

Run the pinned `windows-2022` release workflow, retain its manifest and smoke
report, then add a trusted Authenticode certificate and the M15 multi-device
hardening matrix before any broadly distributed signed release.
