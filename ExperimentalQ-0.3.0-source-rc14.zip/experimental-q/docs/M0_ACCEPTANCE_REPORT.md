# Experimental Q — M0 acceptance report (historical)

> Superseded by `M1_M14_ACCEPTANCE_REPORT.md` and
> `COMPATIBILITY_REPORT.md`; retained only as the original bootstrap record.

**Milestone:** M0 — Repository bootstrap  
**Assessment date:** 2026-08-19 UTC  
**Status:** Implemented; final Windows launch acceptance pending

## Implemented scope

- Canonical monorepo bootstrap.
- React 19/Vite scientific desktop shell with Q visibly `OFF`.
- Tauri 2 shell with a minimal privileged surface.
- Fixed-command backend sidecar launch; no model-authored command text.
- Random loopback backend port and 64-character per-launch token.
- FastAPI `/api/v1/health` endpoint with mandatory bearer authentication.
- Loopback-only bind invariant and restricted CORS origins.
- Structured JSON logging with sensitive-key redaction.
- CI jobs for Python, TypeScript/React, Rust, and Windows.
- No model runtime, tools, controllers, memory, microphone, or installer yet.

## Executed checks

| Check | Result | Evidence |
| --- | --- | --- |
| Python syntax compilation | Pass | `python -m compileall` |
| Ruff | Pass | No findings |
| Mypy strict | Pass | 10 source files, no issues |
| Pytest | Pass | 3/3 tests |
| TypeScript strict | Pass | `tsc -b` |
| React component tests | Pass | 1/1 test |
| Vite production build | Pass | 79 modules transformed |
| Rust formatting | Pass | `cargo fmt --check` |
| Rust Clippy, Windows target | Pass | `x86_64-pc-windows-gnu`, warnings denied |
| Full Windows link and desktop launch | Not executed | Current host is Linux and lacks a Windows linker/runtime |
| Windows NSIS/MSI package smoke test | Not executed | Belongs to M14 and requires a Windows build runner |

The Rust cross-target check used `Q_SKIP_TAURI_BUILD=1` only to omit Windows
resource linking on the Linux host. The Windows CI definition does not set this
variable and therefore executes the complete Tauri build script.

## Acceptance interpretation

The M0 source is internally validated, but the milestone is not declared
complete because the Architecture 3.0 acceptance statement requires the actual
desktop to launch. The project must therefore not advance to M1 in a release
branch until a Windows runner confirms:

1. `q-backend.exe` is present as the packaged sidecar;
2. Tauri launches it and displays authenticated backend health;
3. application exit leaves no backend child process;
4. Q remains `OFF` and no model process exists;
5. no Windows startup entry is created.

## Next dependency

A Windows 11 build runner with Rust 1.88+, Visual Studio Build Tools, WebView2,
Python 3.12, Node.js 22, and pnpm 10. Once the five checks above pass, M1 may
begin without changing the M0 public interface.
