"""Restricted Python execution worker."""
