"""Verified wheel extraction worker."""
