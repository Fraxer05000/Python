"""Installs only hash-approved wheel archives by safe extraction; never executes setup code."""

from __future__ import annotations

import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path, PurePosixPath

_MAX_EXPANDED_BYTES = 1024 * 1024 * 1024


def main() -> int:
    try:
        request = json.load(sys.stdin)
        wheel = Path(str(request["wheel_path"])).resolve(strict=True)
        destination = Path(str(request["destination"])).resolve(strict=True)
        expected = str(request["sha256"])
        if wheel.suffix.lower() != ".whl" or _hash(wheel) != expected:
            raise ValueError("wheel hash mismatch")
        target = destination / expected
        if target.exists():
            return _emit({"status": "ok", "path": str(target), "already_installed": True})
        staging = destination / f".{expected}.staging"
        staging.mkdir(exist_ok=False)
        try:
            with zipfile.ZipFile(wheel) as archive:
                total = 0
                for member in archive.infolist():
                    parts = PurePosixPath(member.filename).parts
                    if not parts or member.is_dir():
                        continue
                    if member.filename.startswith(("/", "\\")) or ".." in parts:
                        raise ValueError("unsafe archive path")
                    total += member.file_size
                    if total > _MAX_EXPANDED_BYTES:
                        raise ValueError("wheel exceeds expanded size limit")
                    output = staging.joinpath(*parts)
                    output.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(member) as source, output.open("wb") as sink:
                        shutil.copyfileobj(source, sink, length=1024 * 1024)
            staging.rename(target)
        except Exception:
            shutil.rmtree(staging, ignore_errors=True)
            raise
        return _emit({"status": "ok", "path": str(target), "already_installed": False})
    except Exception as exc:  # noqa: BLE001 - fixed worker boundary
        return _emit({"status": "error", "error": type(exc).__name__})


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _emit(value: dict[str, object]) -> int:
    sys.stdout.write(json.dumps(value, separators=(",", ":")))
    return 0 if value.get("status") == "ok" else 2


if __name__ == "__main__":
    raise SystemExit(main())
