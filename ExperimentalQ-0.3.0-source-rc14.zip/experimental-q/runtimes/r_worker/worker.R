suppressPackageStartupMessages(library(jsonlite))

request <- fromJSON(file("stdin"))
operation <- request$operation
x <- as.numeric(request$x)

if (operation == "descriptive_statistics") {
  result <- list(
    count = length(x),
    mean = mean(x),
    standard_deviation = sd(x),
    minimum = min(x),
    median = median(x),
    maximum = max(x)
  )
} else if (operation == "correlation") {
  y <- as.numeric(request$y)
  test <- cor.test(x, y, method = "pearson")
  result <- list(correlation = unname(test$estimate), p_value = test$p.value)
} else {
  stop("unsupported_operation")
}

cat(toJSON(list(status = "ok", result = result), auto_unbox = TRUE, na = "null"))
