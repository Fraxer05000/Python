"""Fixed whisper.cpp wrapper. Executable and model paths are supervisor-owned arguments."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--whisper", required=True)
    parser.add_argument("--model", required=True)
    options = parser.parse_args()
    transcript_path: Path | None = None
    try:
        request = json.load(sys.stdin)
        audio = Path(str(request["audio_path"])).resolve(strict=True)
        working = Path.cwd().resolve(strict=True)
        audio.relative_to(working)
        whisper = Path(options.whisper).resolve(strict=True)
        model = Path(options.model).resolve(strict=True)
        if audio.suffix.lower() != ".wav" or model.suffix.lower() not in {".bin", ".gguf"}:
            raise ValueError("invalid audio or model path")
        output_base = working / f"transcript-{audio.stem}"
        started = time.monotonic()
        completed = subprocess.run(  # noqa: S603 - fixed executable and fixed argument vector
            [
                str(whisper),
                "-m",
                str(model),
                "-f",
                str(audio),
                "-l",
                str(request.get("language", "es")),
                "-oj",
                "-of",
                str(output_base),
            ],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            timeout=115,
            check=False,
            env={"PATH": ""},
        )
        transcript_path = output_base.with_suffix(".json")
        if completed.returncode != 0 or not transcript_path.is_file():
            raise RuntimeError("whisper_failed")
        document = json.loads(transcript_path.read_text(encoding="utf-8"))
        text = _extract_text(document)
        return _emit(
            {
                "status": "ok",
                "text": text,
                "duration_ms": int((time.monotonic() - started) * 1000),
            }
        )
    except Exception as exc:  # noqa: BLE001 - fixed worker boundary
        return _emit({"status": "error", "error": type(exc).__name__})
    finally:
        if transcript_path is not None:
            transcript_path.unlink(missing_ok=True)


def _extract_text(document: object) -> str:
    if isinstance(document, dict):
        transcription = document.get("transcription")
        if isinstance(transcription, list):
            values: list[str] = []
            for segment in transcription:
                if isinstance(segment, dict) and isinstance(segment.get("text"), str):
                    values.append(segment["text"].strip())
            return " ".join(value for value in values if value)
        if isinstance(document.get("text"), str):
            return str(document["text"]).strip()
    raise ValueError("invalid whisper output")


def _emit(value: dict[str, object]) -> int:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, separators=(",", ":")))
    return 0 if value.get("status") == "ok" else 2


if __name__ == "__main__":
    raise SystemExit(main())
