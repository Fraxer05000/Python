"""Local audio transcription worker."""
