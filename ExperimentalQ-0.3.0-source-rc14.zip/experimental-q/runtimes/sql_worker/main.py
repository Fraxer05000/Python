"""Fixed read-only SQLite/DuckDB query worker."""

from __future__ import annotations

import json
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any

import duckdb

_MAX_INPUT = 2_000_000
_MAX_ROWS = 1000


def main() -> int:
    try:
        request = json.loads(sys.stdin.buffer.read(_MAX_INPUT + 1))
        engine = str(request["engine"])
        database = Path(str(request["database_path"]))
        query = str(request["query"])
        parameters = request.get("parameters", [])
        if not isinstance(parameters, list):
            raise ValueError("parameters must be a list")
        database.parent.mkdir(parents=True, exist_ok=True)
        if engine == "sqlite":
            columns, rows, truncated = _sqlite(database, query, parameters)
        elif engine == "duckdb":
            columns, rows, truncated = _duckdb(database, query, parameters)
        else:
            raise ValueError("unsupported engine")
        return _emit(
            {
                "status": "ok",
                "columns": columns,
                "rows": rows,
                "truncated": truncated,
            }
        )
    except Exception as exc:  # noqa: BLE001 - fixed worker boundary
        return _emit({"status": "error", "error": type(exc).__name__})


def _sqlite(
    path: Path,
    query: str,
    parameters: list[object],
) -> tuple[list[str], list[list[object]], bool]:
    deadline = time.monotonic() + 60
    connection = sqlite3.connect(path)
    connection.set_authorizer(_sqlite_authorizer)
    connection.set_progress_handler(lambda: 1 if time.monotonic() > deadline else 0, 10000)
    try:
        cursor = connection.execute(query, parameters)
        columns = [str(item[0]) for item in cursor.description or []]
        raw = cursor.fetchmany(_MAX_ROWS + 1)
        return columns, [list(row) for row in raw[:_MAX_ROWS]], len(raw) > _MAX_ROWS
    finally:
        connection.close()


def _sqlite_authorizer(
    action: int,
    _arg1: str | None,
    _arg2: str | None,
    _db: str | None,
    _source: str | None,
) -> int:
    allowed = {
        sqlite3.SQLITE_SELECT,
        sqlite3.SQLITE_READ,
        sqlite3.SQLITE_FUNCTION,
        sqlite3.SQLITE_RECURSIVE,
    }
    return sqlite3.SQLITE_OK if action in allowed else sqlite3.SQLITE_DENY


def _duckdb(
    path: Path,
    query: str,
    parameters: list[object],
) -> tuple[list[str], list[list[Any]], bool]:
    connection = duckdb.connect(str(path))
    try:
        connection.execute("SET enable_external_access=false")
        connection.execute("SET memory_limit='512MB'")
        connection.execute("SET threads=2")
        cursor = connection.execute(query, parameters)
        columns = [str(item[0]) for item in cursor.description or []]
        raw = cursor.fetchmany(_MAX_ROWS + 1)
        return columns, [list(row) for row in raw[:_MAX_ROWS]], len(raw) > _MAX_ROWS
    finally:
        connection.close()


def _emit(value: dict[str, object]) -> int:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":")))
    sys.stdout.flush()
    return 0 if value.get("status") == "ok" else 2


if __name__ == "__main__":
    raise SystemExit(main())
