"""Read-only SQL execution worker."""
