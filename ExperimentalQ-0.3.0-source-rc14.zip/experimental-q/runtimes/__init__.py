"""Supervisor-owned worker entry points."""
